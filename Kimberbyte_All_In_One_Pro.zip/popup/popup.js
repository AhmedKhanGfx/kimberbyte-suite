document.addEventListener("DOMContentLoaded", () => {
  // Update Smart Memory Counter in Popup
  const memEl = document.getElementById("popupMemStats");
  if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
    chrome.storage.local.get(["kb_outreach_history_db"], (res) => {
      const mem = res?.kb_outreach_history_db;
      const numCount = Object.keys(mem?.numbers || {}).length;
      const emailCount = Object.keys(mem?.emails || {}).length;
      const total = numCount + emailCount;
      if (memEl) {
        memEl.textContent = `${total} leads remembered (${numCount} WA / ${emailCount} Email)`;
      }
    });
  }

  // Launch WhatsApp Web
  const btnWA = document.getElementById("btnLaunchWhatsApp");
  if (btnWA) {
    btnWA.addEventListener("click", () => {
      openOrFocusUrl("https://web.whatsapp.com", "*://web.whatsapp.com/*");
    });
  }

  // Launch Hostinger Webmail
  const btnHostinger = document.getElementById("btnLaunchHostinger");
  if (btnHostinger) {
    btnHostinger.addEventListener("click", () => {
      openOrFocusUrl("https://mail.hostinger.com", "*://*.hostinger.com/*mail*");
    });
  }

  // Launch Multi-Mail Pro Dashboard
  const btnMM = document.getElementById("btnLaunchMultiMail");
  if (btnMM) {
    btnMM.addEventListener("click", () => {
      if (typeof chrome !== "undefined" && chrome.tabs) {
        const dashUrl = chrome.runtime.getURL("dashboard/dashboard.html");
        chrome.tabs.create({ url: dashUrl });
        window.close();
      } else {
        window.open("../dashboard/dashboard.html", "_blank");
      }
    });
  }

  function openOrFocusUrl(targetUrl, queryPattern) {
    if (typeof chrome !== "undefined" && chrome.tabs) {
      chrome.tabs.query({ url: queryPattern }, (tabs) => {
        if (tabs && tabs.length > 0) {
          chrome.tabs.update(tabs[0].id, { active: true });
          if (tabs[0].windowId) chrome.windows.update(tabs[0].windowId, { focused: true });
        } else {
          chrome.tabs.create({ url: targetUrl });
        }
        window.close();
      });
    } else {
      window.open(targetUrl, "_blank");
    }
  }
});
