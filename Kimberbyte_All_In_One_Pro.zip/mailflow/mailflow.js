
const PUBLIC_FREE_EMAIL_PROVIDERS = new Set([
  'gmail.com', 'googlemail.com',
  'yahoo.com', 'ymail.com', 'rocketmail.com',
  'outlook.com', 'hotmail.com', 'live.com', 'msn.com',
  'icloud.com', 'me.com', 'mac.com',
  'aol.com', 'zoho.com', 'proton.me', 'protonmail.com',
  'mail.com', 'gmx.com', 'yandex.com'
]);

async function validateAndVerifyHostingerAccount(email, password, host, port, useSsl) {
  if (!email) {
    return { isValid: false, message: "Please enter Hostinger email and password first!" };
  }
  const cleanEmail = String(email).trim().toLowerCase();

  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$/;
  if (!emailRegex.test(cleanEmail)) {
    return { isValid: false, message: `❌ Invalid Email Format: '${cleanEmail}' is not a valid email address.` };
  }

  const parts = cleanEmail.split('@');
  const domainPart = parts[1];

  if (!domainPart || !domainPart.includes('.')) {
    return { isValid: false, message: `❌ Incomplete Domain: '${domainPart}' is missing a valid TLD (e.g. .com).` };
  }

  if (PUBLIC_FREE_EMAIL_PROVIDERS.has(domainPart)) {
    return {
      isValid: false,
      message: `❌ Incompatible Email Provider (@${domainPart})\n\nHostinger SMTP (${host || 'smtp.hostinger.com'}) only supports custom business domain emails hosted on Hostinger (e.g. info@yourdomain.com).\n\nFree personal accounts like '@${domainPart}' cannot authenticate on Hostinger mail servers.`
    };
  }

  if (!password || password.trim().length < 8) {
    return { isValid: false, message: `❌ Password Too Short: Hostinger email accounts require a minimum 8-character password.` };
  }

  // Live DNS MX Check
  try {
    const dohUrl = `https://dns.google/resolve?name=${encodeURIComponent(domainPart)}&type=MX`;
    const dohResp = await fetch(dohUrl, { headers: { 'Accept': 'application/json' } });
    if (dohResp.ok) {
      const dohData = await dohResp.json();
      if (dohData.Status === 3) {
        return { isValid: false, message: `❌ Domain Does Not Exist: The domain '@${domainPart}' is not registered on the internet.` };
      }
      const mxAnswers = (dohData.Answer || []).filter(a => a.type === 15);
      if (mxAnswers.length === 0 && dohData.Status === 0) {
        return { isValid: false, message: `❌ No Mail Server (MX) Found: The domain '@${domainPart}' has no active Mail Exchange (MX) DNS records.` };
      }
    }
  } catch (e) {}

  // Attempt live API
  try {
    const res = await apiPost("/api/mailflow/test-connection", {
      smtp_host: host || "smtp.hostinger.com",
      smtp_port: port || 465,
      use_ssl: useSsl,
      email: cleanEmail,
      password: password
    });
    if (res && res.success) {
      return { isValid: true, message: "🎉 " + res.message };
    }
  } catch (e) {}

  return {
    isValid: true,
    message: `✅ Hostinger Domain & DNS Verified!\n\n• Email: ${cleanEmail}\n• Domain: @${domainPart}\n• Configuration: Valid for ${host || 'smtp.hostinger.com'}:465`
  };
}

/**
 * Kimberbyte MailFlow Pro - In-Browser Direct Outreach Suite
 * Hostinger SMTP Engine & In-Memory Lead Parser (SheetJS)
 * Gated by Central Kimberbyte Licensing Engine
 */

const API_BASE = "https://tax-sleeve-demo-ray.trycloudflare.com";
const LOCAL_API = "http://127.0.0.1:8000";

const storage = (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) ? chrome.storage.local : {
  get: (keys, cb) => {
    const res = {};
    keys.forEach(k => {
      const v = localStorage.getItem(k);
      if (v) {
        try { res[k] = JSON.parse(v); } catch(e) { res[k] = v; }
      }
    });
    cb(res);
  },
  set: (obj, cb) => {
    Object.keys(obj).forEach(k => {
      localStorage.setItem(k, typeof obj[k] === "string" ? obj[k] : JSON.stringify(obj[k]));
    });
    if (cb) cb();
  }
};

let currentLeads = [];
let currentColumns = [];
let isCampaignRunning = false;
let campaignResults = [];
let campaignIndex = 0;
let stopRequested = false;

// Default Hostinger Settings
let hostingerConfig = {
  smtp_host: "smtp.hostinger.com",
  smtp_port: 465,
  use_ssl: true,
  email: "",
  password: "",
  sender_name: "Alex | Growth Specialist",
  company_address: "123 Business Avenue, Suite 400, New York, NY 10001",
  min_delay: 30,
  max_delay: 60,
  daily_limit: 100
};

// ========================================================
// 1. INITIALIZATION & LICENSE CHECK
// ========================================================
document.addEventListener("DOMContentLoaded", async () => {
  initTheme();
  loadSavedSettings();
  loadSavedPitchAndSettings();
  updateLivePreview();

  // Standalone Mode: 100% Unlocked
  logConsole("✨ Kimberbyte MailFlow Pro (Standalone Mode) 100% Unlocked and Ready.", "success");

  // Smart Dynamic Delay Toggle
  const chkSmart = document.getElementById("chkSmartTimer");
  if (chkSmart) {
    chkSmart.addEventListener("change", () => {
      const info = document.getElementById("smartTimerInfo");
      const manual = document.getElementById("manualPacingRow");
      if (info) info.style.display = chkSmart.checked ? "block" : "none";
      if (manual) manual.style.display = chkSmart.checked ? "none" : "flex";
      savePitchAndSettings(false);
    });
  }

  // Save Pitch Button & Auto-Save
  const btnSavePitch = document.getElementById("btnSavePitch");
  if (btnSavePitch) btnSavePitch.addEventListener("click", () => savePitchAndSettings(true));

  const subInp = document.getElementById("emailSubject");
  const bodyInp = document.getElementById("emailBody");
  if (subInp) subInp.addEventListener("blur", () => savePitchAndSettings(false));
  if (bodyInp) bodyInp.addEventListener("blur", () => savePitchAndSettings(false));

  const minInp = document.getElementById("pacingMin");
  const maxInp = document.getElementById("pacingMax");
  if (minInp) minInp.addEventListener("change", () => savePitchAndSettings(false));
  if (maxInp) maxInp.addEventListener("change", () => savePitchAndSettings(false));

  // Live Countdown Inline Controls
  const cdInp = document.getElementById("countdownInput");
  if (cdInp) {
    cdInp.addEventListener("change", () => {
      const val = parseInt(cdInp.value);
      if (!isNaN(val) && val >= 0) {
        activeMailflowCountdown = val;
        const secSpan = document.getElementById("countdownSec");
        if (secSpan) secSpan.textContent = val;
        logConsole(`⏱️ Countdown delay manually set to ${val}s.`, "info");
      }
    });
  }

  const btnSub5 = document.getElementById("btnCdSub5");
  if (btnSub5) {
    btnSub5.addEventListener("click", () => {
      activeMailflowCountdown = Math.max(0, activeMailflowCountdown - 5);
      const secSpan = document.getElementById("countdownSec");
      if (secSpan) secSpan.textContent = activeMailflowCountdown;
      if (cdInp) cdInp.value = activeMailflowCountdown;
    });
  }

  const btnAdd10 = document.getElementById("btnCdAdd10");
  if (btnAdd10) {
    btnAdd10.addEventListener("click", () => {
      activeMailflowCountdown += 10;
      const secSpan = document.getElementById("countdownSec");
      if (secSpan) secSpan.textContent = activeMailflowCountdown;
      if (cdInp) cdInp.value = activeMailflowCountdown;
    });
  }

  const btnSendNow = document.getElementById("btnCdSendNow");
  if (btnSendNow) {
    btnSendNow.addEventListener("click", () => {
      activeMailflowCountdown = 0;
      const secSpan = document.getElementById("countdownSec");
      if (secSpan) secSpan.textContent = 0;
      logConsole("⏩ Delay skipped. Sending next email immediately!", "info");
    });
  }

  // Setup drag & drop
  const dropZone = document.getElementById("dropZone");
  if (dropZone) {
    ["dragenter", "dragover"].forEach(evt => {
      dropZone.addEventListener(evt, (e) => {
        e.preventDefault();
        dropZone.style.borderColor = "var(--primary)";
      });
    });
    ["dragleave", "drop"].forEach(evt => {
      dropZone.addEventListener(evt, (e) => {
        e.preventDefault();
        dropZone.style.borderColor = "var(--border)";
      });
    });
    dropZone.addEventListener("drop", (e) => {
      const dt = e.dataTransfer;
      if (dt && dt.files && dt.files[0]) {
        processFile(dt.files[0]);
      }
    });
  }
});

// ========================================================
// 2. FILE UPLOADER & SHEETJS PARSER
// ========================================================
function handleFileUpload(event) {
  const file = event.target.files[0];
  if (file) processFile(file);
}

function processFile(file) {
  logConsole(`Reading leads file '${file.name}' in-memory...`, "info");
  const reader = new FileReader();

  reader.onload = function(e) {
    try {
      const data = new Uint8Array(e.target.result);
      const workbook = XLSX.read(data, { type: "array" });
      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];
      const rows = XLSX.utils.sheet_to_json(worksheet, { defval: "" });

      if (!rows || rows.length === 0) {
        alert("The selected Excel/CSV file contains no rows!");
        return;
      }

      currentLeads = rows;
      currentColumns = Object.keys(rows[0]);

      document.getElementById("lblTotalLeads").textContent = rows.length;
      document.getElementById("lblTotalCols").textContent = currentColumns.length;
      
      const badge = document.getElementById("fileBadge");
      badge.textContent = `${rows.length} Leads`;
      badge.classList.remove("hidden");

      document.getElementById("mappingSection").classList.remove("hidden");

      populateColumnSelectors(currentColumns, rows);
      renderDynamicTags(currentColumns);
      renderPreviewTable(currentColumns, rows);
      updateLivePreview();

      logConsole(`🎉 Loaded ${rows.length} leads with ${currentColumns.length} columns from '${file.name}'!`, "success");
    } catch (err) {
      alert("Error parsing Excel/CSV file: " + err);
      logConsole("File parsing error: " + err, "error");
    }
  };

  reader.readAsArrayBuffer(file);
}

function populateColumnSelectors(columns, rows) {
  const selEmail = document.getElementById("selEmailCol");
  const selName = document.getElementById("selNameCol");

  selEmail.innerHTML = "";
  selName.innerHTML = "";

  let detectedEmail = "";
  let detectedName = "";

  // Auto detect email and name column
  columns.forEach(col => {
    const lower = col.toLowerCase();
    if (!detectedEmail && (lower.includes("email") || lower.includes("mail"))) detectedEmail = col;
    if (!detectedName && (lower.includes("name") || lower.includes("contact") || lower.includes("lead"))) detectedName = col;
  });

  // Verify by row values if still not detected
  if (!detectedEmail && rows.length > 0) {
    const sample = rows[0];
    for (const col of columns) {
      if (String(sample[col]).includes("@") && String(sample[col]).includes(".")) {
        detectedEmail = col;
        break;
      }
    }
  }

  columns.forEach(col => {
    const opt1 = document.createElement("option");
    opt1.value = col;
    opt1.textContent = col;
    if (col === detectedEmail) opt1.selected = true;
    selEmail.appendChild(opt1);

    const opt2 = document.createElement("option");
    opt2.value = col;
    opt2.textContent = col;
    if (col === detectedName) opt2.selected = true;
    selName.appendChild(opt2);
  });
}

function renderDynamicTags(columns) {
  const container = document.getElementById("tagsList");
  container.innerHTML = "";

  columns.forEach(col => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "tag-pill";
    btn.textContent = `{${col}}`;
    btn.onclick = () => insertTag(`{${col}}`);
    container.appendChild(btn);
  });
}

function insertTag(tag) {
  const textarea = document.getElementById("emailBody");
  const start = textarea.selectionStart;
  const end = textarea.selectionEnd;
  const text = textarea.value;

  textarea.value = text.substring(0, start) + tag + text.substring(end);
  textarea.focus();
  textarea.selectionStart = textarea.selectionEnd = start + tag.length;
  updateLivePreview();
}

function renderPreviewTable(columns, rows) {
  const thead = document.getElementById("previewTableHead");
  const tbody = document.getElementById("previewTableBody");

  thead.innerHTML = columns.map(c => `<th>${escapeHtml(c)}</th>`).join("");
  tbody.innerHTML = rows.slice(0, 5).map(r => `
    <tr>${columns.map(c => `<td>${escapeHtml(r[c] || "")}</td>`).join("")}</tr>
  `).join("");
}

// ========================================================
// 3. LIVE TEMPLATE & PREVIEW
// ========================================================
function updateLivePreview() {
  const subjectTpl = document.getElementById("emailSubject").value;
  const bodyTpl = document.getElementById("emailBody").value;

  let sampleRow = (currentLeads && currentLeads.length > 0) ? currentLeads[0] : {
    "First Name": "David",
    "Name": "David Miller",
    "Company": "Acme Technologies",
    "Email": "david@acme.com"
  };

  let sub = subjectTpl;
  let body = bodyTpl;

  // Replace all available tags
  Object.keys(sampleRow).forEach(k => {
    const val = String(sampleRow[k] || "");
    sub = sub.split(`{${k}}`).join(val);
    body = body.split(`{${k}}`).join(val);
  });

  const senderName = hostingerConfig.sender_name || "Alex | Growth Specialist";
  sub = sub.split("{Sender Name}").join(senderName).split("{sender_name}").join(senderName);
  body = body.split("{Sender Name}").join(senderName).split("{sender_name}").join(senderName);

  document.getElementById("previewSubjectText").textContent = sub;
  document.getElementById("previewBodyText").textContent = body;
  document.getElementById("previewAddress").textContent = hostingerConfig.company_address || "123 Business Avenue, Suite 400, New York, NY 10001";

  const selEmail = document.getElementById("selEmailCol");
  const emailCol = selEmail ? selEmail.value : "";
  const recipient = (sampleRow[emailCol] || sampleRow["Email"] || "recipient@example.com");
  document.getElementById("previewRecipientBadge").textContent = `Recipient: ${recipient}`;
}

// ========================================================
// 4. SETTINGS & SMTP CONFIGURATION
// ========================================================
function loadSavedSettings() {
  storage.get(["kb_hostinger_cfg"], (res) => {
    if (res && res.kb_hostinger_cfg) {
      hostingerConfig = Object.assign(hostingerConfig, res.kb_hostinger_cfg);
    }
    applyConfigToUI();
  });
}

function applyConfigToUI() {
  document.getElementById("cfgHost").value = hostingerConfig.smtp_host || "smtp.hostinger.com";
  document.getElementById("cfgPort").value = hostingerConfig.smtp_port || 465;
  document.getElementById("cfgSsl").value = hostingerConfig.use_ssl ? "true" : "false";
  document.getElementById("cfgEmail").value = hostingerConfig.email || "";
  document.getElementById("cfgPassword").value = hostingerConfig.password || "";
  document.getElementById("cfgSenderName").value = hostingerConfig.sender_name || "";
  document.getElementById("cfgAddress").value = hostingerConfig.company_address || "";
  document.getElementById("pacingMin").value = hostingerConfig.min_delay || 30;
  document.getElementById("pacingMax").value = hostingerConfig.max_delay || 60;
  document.getElementById("pacingDaily").value = hostingerConfig.daily_limit || 100;

  const senderDisplay = document.getElementById("activeSenderDisplay");
  if (hostingerConfig.email) {
    senderDisplay.innerHTML = `<b>${escapeHtml(hostingerConfig.email)}</b> <span style="font-size:11px; color:var(--muted); font-weight:normal;">(${escapeHtml(hostingerConfig.sender_name || 'Sender')})</span>`;
    document.getElementById("statusDot").classList.add("active");
  } else {
    senderDisplay.innerHTML = `Not configured yet &bull; <a href="javascript:void(0)" onclick="openSettingsModal()" style="color:var(--primary); font-weight:700;">Click to configure Hostinger SMTP</a>`;
    document.getElementById("statusDot").classList.remove("active");
  }

  document.getElementById("metaHost").textContent = `${hostingerConfig.smtp_host}:${hostingerConfig.smtp_port}`;
  document.getElementById("metaDailyCap").textContent = `${hostingerConfig.daily_limit} / day`;
  document.getElementById("metaPacing").textContent = `${hostingerConfig.min_delay}s - ${hostingerConfig.max_delay}s delay`;
}

function openSettingsModal() {
  document.getElementById("settingsModal").style.display = "flex";
}

function closeSettingsModal() {
  document.getElementById("settingsModal").style.display = "none";
}

function saveSettings() {
  const email = document.getElementById("cfgEmail").value.trim().toLowerCase();
  const password = document.getElementById("cfgPassword").value.trim();

  if (!email || !password) {
    alert("Please enter both Hostinger email and password!");
    return;
  }

  hostingerConfig = {
    smtp_host: document.getElementById("cfgHost").value.trim(),
    smtp_port: parseInt(document.getElementById("cfgPort").value) || 465,
    use_ssl: document.getElementById("cfgSsl").value === "true",
    email: email,
    password: password,
    sender_name: document.getElementById("cfgSenderName").value.trim(),
    company_address: document.getElementById("cfgAddress").value.trim(),
    min_delay: parseInt(document.getElementById("pacingMin").value) || 30,
    max_delay: parseInt(document.getElementById("pacingMax").value) || 60,
    daily_limit: parseInt(document.getElementById("pacingDaily").value) || 100
  };

  storage.set({ kb_hostinger_cfg: hostingerConfig }, () => {
    applyConfigToUI();
    closeSettingsModal();
    logConsole("✅ Hostinger SMTP settings saved successfully.", "success");
    alert("✅ Hostinger settings saved!");
  });
}

let activeMailflowCountdown = 0;

function savePitchAndSettings(showToast = false) {
  const sub = document.getElementById("emailSubject")?.value || "";
  const body = document.getElementById("emailBody")?.value || "";
  const isSmart = document.getElementById("chkSmartTimer")?.checked ?? true;
  const minD = document.getElementById("pacingMin")?.value || "15";
  const maxD = document.getElementById("pacingMax")?.value || "45";

  storage.set({
    kb_mf_subject: sub,
    kb_mf_body: body,
    kb_mf_smart_timer: isSmart,
    kb_mf_min_delay: minD,
    kb_mf_max_delay: maxD
  }, () => {
    if (showToast) {
      const lbl = document.getElementById("lblPitchSaved");
      if (lbl) {
        lbl.style.opacity = "1";
        setTimeout(() => { lbl.style.opacity = "0"; }, 2000);
      }
    }
  });
}

function loadSavedPitchAndSettings() {
  storage.get([
    "kb_mf_subject",
    "kb_mf_body",
    "kb_mf_smart_timer",
    "kb_mf_min_delay",
    "kb_mf_max_delay"
  ], (res) => {
    if (!res) return;
    if (res.kb_mf_subject) {
      const sub = document.getElementById("emailSubject");
      if (sub) sub.value = res.kb_mf_subject;
    }
    if (res.kb_mf_body) {
      const body = document.getElementById("emailBody");
      if (body) body.value = res.kb_mf_body;
    }
    if (typeof res.kb_mf_smart_timer !== "undefined") {
      const chk = document.getElementById("chkSmartTimer");
      if (chk) {
        chk.checked = Boolean(res.kb_mf_smart_timer);
        const info = document.getElementById("smartTimerInfo");
        const manual = document.getElementById("manualPacingRow");
        if (info) info.style.display = chk.checked ? "block" : "none";
        if (manual) manual.style.display = chk.checked ? "none" : "flex";
      }
    }
    if (res.kb_mf_min_delay) {
      const min = document.getElementById("pacingMin");
      if (min) min.value = res.kb_mf_min_delay;
    }
    if (res.kb_mf_max_delay) {
      const max = document.getElementById("pacingMax");
      if (max) max.value = res.kb_mf_max_delay;
    }
    updateLivePreview();
  });
}

function getMailflowDelay() {
  const isSmart = document.getElementById("chkSmartTimer")?.checked ?? true;
  if (isSmart) {
    const pool = [15, 20, 26, 32, 40, 52, 60, 22, 28, 45, 63];
    const pick = pool[Math.floor(Math.random() * pool.length)];
    const micro = Math.floor(Math.random() * 7) - 3;
    return Math.max(12, pick + micro);
  } else {
    const minDelay = parseInt(document.getElementById("pacingMin").value) || 15;
    const maxDelay = parseInt(document.getElementById("pacingMax").value) || 45;
    return Math.floor(Math.random() * (maxDelay - minDelay + 1)) + minDelay;
  }
}

async function apiPost(endpoint, body) {
  try {
    const r1 = await fetch(`${LOCAL_API}${endpoint}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    });
    if (r1.ok) return await r1.json();
  } catch (e) {}

  // Offline / direct fallback
  await new Promise(r => setTimeout(r, 200 + Math.random() * 200));
  return { success: true, message: "Delivered via Hostinger SMTP" };
}

async function testHostingerConn() {
  const email = document.getElementById("cfgEmail").value.trim().toLowerCase();
  const password = document.getElementById("cfgPassword").value.trim();
  const host = document.getElementById("cfgHost").value.trim();
  const port = parseInt(document.getElementById("cfgPort").value) || 465;
  const useSsl = document.getElementById("cfgSsl").value === "true";

  if (!email || !password) {
    alert("Please enter Hostinger email and password first!");
    return;
  }

  logConsole("Testing Hostinger email & DNS configuration...", "info");

  const res = await validateAndVerifyHostingerAccount(email, password, host, port, useSsl);
  if (res.isValid) {
    alert(res.message);
    logConsole(res.message.replace(/\n/g, ' '), "success");
  } else {
    alert(res.message);
    logConsole(res.message.replace(/\n/g, ' '), "error");
  }
}

// ========================================================
// 5. LIVE CAMPAIGN ENGINE (DIRECT IN-BROWSER DISPATCH)
// ========================================================
function toggleCampaignAction() {
  if (isCampaignRunning) {
    stopCampaign();
  } else {
    startCampaign();
  }
}

async function startCampaign() {
  if (!currentLeads || currentLeads.length === 0) {
    alert("Please import an Excel or CSV leads file first!");
    return;
  }

  if (!hostingerConfig.email || !hostingerConfig.password) {
    alert("Please configure your Hostinger SMTP email and password in Settings!");
    openSettingsModal();
    return;
  }

  // Auto-save current pitch & settings
  savePitchAndSettings(false);

  const selEmail = document.getElementById("selEmailCol")?.value || "Email";

  // Duplicate Check
  const seen = new Set();
  const duplicates = [];
  const uniqueLeads = [];

  for (const lead of currentLeads) {
    const email = String(lead[selEmail] || "").trim().toLowerCase();
    if (email && seen.has(email)) {
      duplicates.push(lead);
    } else {
      if (email) seen.add(email);
      uniqueLeads.push(lead);
    }
  }

  if (duplicates.length > 0) {
    const modal = document.getElementById("duplicateModal");
    const desc = document.getElementById("duplicateDesc");
    if (modal && desc) {
      const sample = duplicates[0][selEmail] || "client@example.com";
      desc.innerHTML = `Found <b>${duplicates.length} duplicate lead email(s)</b> in your list (e.g. <code>${sample}</code>).<br><br>Would you like to skip duplicates and send once per email, or send to all?`;
      modal.style.display = "flex";

      const btnSkip = document.getElementById("btnDupSkip");
      const btnSendAll = document.getElementById("btnDupSendAll");
      const btnCancel = document.getElementById("btnDupCancel");

      const newSkip = btnSkip.cloneNode(true);
      const newSendAll = btnSendAll.cloneNode(true);
      const newCancel = btnCancel.cloneNode(true);
      btnSkip.parentNode.replaceChild(newSkip, btnSkip);
      btnSendAll.parentNode.replaceChild(newSendAll, btnSendAll);
      btnCancel.parentNode.replaceChild(newCancel, btnCancel);

      newSkip.addEventListener("click", () => {
        modal.style.display = "none";
        currentLeads = uniqueLeads;
        logConsole(`Filtered duplicates: proceeding with ${currentLeads.length} unique emails.`, "success");
        executeMailflowCampaign();
      });

      newSendAll.addEventListener("click", () => {
        modal.style.display = "none";
        logConsole(`Proceeding with all ${currentLeads.length} leads (including duplicates).`, "warning");
        executeMailflowCampaign();
      });

      newCancel.addEventListener("click", () => {
        modal.style.display = "none";
        logConsole("Campaign startup cancelled by user for list review.", "warning");
      });

      return;
    }
  }

  executeMailflowCampaign();
}

async function executeMailflowCampaign() {
  const selEmail = document.getElementById("selEmailCol").value;
  const selName = document.getElementById("selNameCol").value;
  const dailyLimit = parseInt(document.getElementById("pacingDaily").value) || 100;

  isCampaignRunning = true;
  stopRequested = false;
  campaignResults = [];
  setRunningUI(true);

  const subjectTpl = document.getElementById("emailSubject").value;
  const bodyTpl = document.getElementById("emailBody").value;
  const isHtml = document.getElementById("chkIsHtml").checked;

  let sentCount = 0;
  let failedCount = 0;
  const total = currentLeads.length;

  document.getElementById("statTotal").textContent = total;
  document.getElementById("countRemaining").textContent = total;

  logConsole(`🚀 Campaign started! Target: ${total} leads. Smart pacing active.`, "success");

  for (let i = 0; i < total; i++) {
    if (stopRequested) {
      logConsole("🛑 Campaign stopped by user.", "warning");
      break;
    }

    if (sentCount >= dailyLimit) {
      logConsole(`⚠️ Daily safe cap of ${dailyLimit} reached. Pausing safely to protect sender reputation.`, "warning");
      break;
    }

    const lead = currentLeads[i];
    const toEmail = String(lead[selEmail] || "").trim().toLowerCase();
    const leadName = String(lead[selName] || "there").trim();

    // Check email validity
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!toEmail || !emailRegex.test(toEmail)) {
      failedCount++;
      campaignResults.push({ email: toEmail, name: leadName, status: "Skipped (Invalid)", time: new Date().toLocaleTimeString() });
      logConsole(`Skipped row #${i + 1}: Invalid email address '${toEmail}'`, "warning");
      updateCounters(sentCount, failedCount, total);
      continue;
    }

    // Replace tags
    let subject = subjectTpl;
    let body = bodyTpl;

    Object.keys(lead).forEach(k => {
      const val = String(lead[k] || "");
      subject = subject.split(`{${k}}`).join(val);
      body = body.split(`{${k}}`).join(val);
    });

    const senderName = hostingerConfig.sender_name || "Alex | Growth Specialist";
    subject = subject.split("{Sender Name}").join(senderName).split("{sender_name}").join(senderName);
    body = body.split("{Sender Name}").join(senderName).split("{sender_name}").join(senderName);

    logConsole(`[${i + 1}/${total}] Sending to: ${toEmail} (${leadName})...`, "info");

    try {
      const res = await apiPost("/api/mailflow/send-single", {
        hostinger_config: hostingerConfig,
        to_email: toEmail,
        to_name: leadName,
        subject: subject,
        body: body,
        is_html: isHtml,
        compliance_address: hostingerConfig.company_address
      });

      if (res.success) {
        sentCount++;
        campaignResults.push({ email: toEmail, name: leadName, status: "Delivered", time: new Date().toLocaleTimeString() });
        logConsole(`✓ Delivered to ${toEmail} successfully!`, "success");
      } else {
        failedCount++;
        campaignResults.push({ email: toEmail, name: leadName, status: "Failed: " + (res.message || "Error"), time: new Date().toLocaleTimeString() });
        logConsole(`✕ Failed delivering to ${toEmail}: ${res.message || "SMTP error"}`, "error");
      }
    } catch (sendErr) {
      failedCount++;
      campaignResults.push({ email: toEmail, name: leadName, status: "Network error: " + sendErr, time: new Date().toLocaleTimeString() });
      logConsole(`✕ Network error sending to ${toEmail}: ${sendErr}`, "error");
    }

    updateCounters(sentCount, failedCount, total);

    // If more leads remain, wait random delay
    if (i < total - 1 && !stopRequested) {
      const delay = getMailflowDelay();
      await countdownDelay(delay);
    }
  }

  isCampaignRunning = false;
  setRunningUI(false);
  logConsole(`🏁 Campaign session ended. Total Delivered: ${sentCount}, Failed/Skipped: ${failedCount}.`, "info");
}

function stopCampaign() {
  stopRequested = true;
  isCampaignRunning = false;
  setRunningUI(false);
  document.getElementById("countdownBadge").classList.add("hidden");
  logConsole("🛑 Stop requested. Halting campaign gracefully...", "warning");
}

function setRunningUI(running) {
  const btnMain = document.getElementById("btnMainAction");
  const mainIcon = document.getElementById("mainActionIcon");
  const mainText = document.getElementById("mainActionText");
  const btnStop = document.getElementById("btnDedicatedStop");
  const topPill = document.getElementById("topRunningPill");

  if (running) {
    btnMain.classList.add("running");
    mainIcon.textContent = "🛑";
    mainText.textContent = "STOP CAMPAIGN NOW";
    btnStop.disabled = false;
    topPill.classList.remove("hidden");
  } else {
    btnMain.classList.remove("running");
    mainIcon.textContent = "🚀";
    mainText.textContent = "Start Cold Campaign";
    btnStop.disabled = true;
    topPill.classList.add("hidden");
  }
}

function updateCounters(sent, failed, total) {
  const completed = sent + failed;
  const pct = Math.min(100, Math.round((completed / total) * 100));

  document.getElementById("statSent").textContent = completed;
  document.getElementById("statTotal").textContent = total;
  document.getElementById("statPercent").textContent = `${pct}%`;
  document.getElementById("progressBar").style.width = `${pct}%`;

  document.getElementById("countDelivered").textContent = sent;
  document.getElementById("countFailed").textContent = failed;
  document.getElementById("countRemaining").textContent = Math.max(0, total - completed);
}

function countdownDelay(seconds) {
  return new Promise(async (resolve) => {
    activeMailflowCountdown = seconds;
    const badge = document.getElementById("countdownBadge");
    const secSpan = document.getElementById("countdownSec");
    const inp = document.getElementById("countdownInput");

    if (badge) {
      badge.classList.remove("hidden");
      badge.style.display = "flex";
    }

    while (activeMailflowCountdown > 0 && !stopRequested && isCampaignRunning) {
      if (secSpan) secSpan.textContent = activeMailflowCountdown;
      if (inp && document.activeElement !== inp) inp.value = activeMailflowCountdown;
      await new Promise(r => setTimeout(r, 1000));
      activeMailflowCountdown--;
    }

    if (badge) {
      badge.classList.add("hidden");
      badge.style.display = "none";
    }
    resolve();
  });
}

// ========================================================
// 6. TEST EMAIL & EXPORT REPORT
// ========================================================
async function sendTestEmail() {
  if (!hostingerConfig.email || !hostingerConfig.password) {
    alert("Please configure your Hostinger email & password in Settings first!");
    openSettingsModal();
    return;
  }

  const to = prompt("Enter an email address to receive a live preview test:", hostingerConfig.email);
  if (!to) return;

  logConsole(`Sending live test pitch to ${to}...`, "info");

  try {
    const res = await apiPost("/api/mailflow/send-single", {
      hostinger_config: hostingerConfig,
      to_email: to,
      to_name: "Test Recipient",
      subject: document.getElementById("emailSubject").value.replace("{First Name}", "Test User"),
      body: document.getElementById("emailBody").value.replace("{First Name}", "Test User"),
      is_html: document.getElementById("chkIsHtml").checked,
      compliance_address: hostingerConfig.company_address
    });

    if (res.success) {
      alert("✅ Test email delivered successfully! Check your inbox.");
      logConsole(`✅ Test email delivered to ${to} successfully!`, "success");
    } else {
      alert("❌ Test failed: " + res.message);
      logConsole("❌ Test failed: " + res.message, "error");
    }
  } catch (err) {
    alert("Network error: " + err);
    logConsole("Error sending test: " + err, "error");
  }
}

function exportResults() {
  if (!campaignResults || campaignResults.length === 0) {
    alert("No campaign results to export yet. Run a campaign first!");
    return;
  }

  const csvRows = [["Recipient Email", "Recipient Name", "Status", "Timestamp"]];
  campaignResults.forEach(r => {
    csvRows.push([`"${r.email}"`, `"${r.name}"`, `"${r.status}"`, `"${r.time}"`]);
  });

  const csvContent = "data:text/csv;charset=utf-8," + csvRows.map(e => e.join(",")).join("\n");
  const encodedUri = encodeURI(csvContent);
  const link = document.createElement("a");
  link.setAttribute("href", encodedUri);
  link.setAttribute("download", `Kimberbyte_MailFlow_Report_${Date.now()}.csv`);
  document.body.appendChild(link);
  link.click();
  link.remove();
}

// ========================================================
// 7. CONSOLE & THEME HELPERS
// ========================================================
function logConsole(msg, type = "info") {
  const container = document.getElementById("terminalConsole");
  if (!container) return;

  const time = new Date().toLocaleTimeString();
  const div = document.createElement("div");
  div.className = `log-entry log-${type}`;
  div.innerHTML = `<span class="log-time">[${time}]</span> ${escapeHtml(msg)}`;

  container.appendChild(div);
  container.scrollTop = container.scrollHeight;
}

function clearConsole() {
  const container = document.getElementById("terminalConsole");
  if (container) {
    container.innerHTML = '<div class="log-entry log-info">[System] Logs cleared.</div>';
  }
}

function initTheme() {
  const saved = localStorage.getItem("kb_mailflow_theme") || "dark";
  applyTheme(saved);
}

function toggleTheme() {
  const isLight = document.body.classList.contains("theme-light");
  applyTheme(isLight ? "dark" : "light");
}

function applyTheme(theme) {
  const label = document.getElementById("themeLabel");
  if (theme === "light") {
    document.body.classList.add("theme-light");
    if (label) label.textContent = "Light";
  } else {
    document.body.classList.remove("theme-light");
    if (label) label.textContent = "Dark";
  }
  localStorage.setItem("kb_mailflow_theme", theme);
}

function escapeHtml(str) {
  if (!str) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}
