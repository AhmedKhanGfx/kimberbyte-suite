/**
 * Kimberbyte Enterprise Cryptographic License Shield v3.0
 * Hardware-Locked & Cryptographically Signed Anti-Piracy Controller
 * Protects Multi-Mail Pro 3x, Hostinger MailFlow, and WhatsApp Bot Pro.
 */

(function (window) {
  'use strict';

  if (window.__KIMBERBYTE_LICENSE_SHIELD__) return;
  window.__KIMBERBYTE_LICENSE_SHIELD__ = true;

  const KB_SECRET = "kb_enterprise_master_vault_key_2026_x99";
  const REVOCATION_URL = "https://raw.githubusercontent.com/AhmedKhanGfx/kimberbyte-suite/main/revocations.json";

  const storage = (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) ? chrome.storage.local : {
    get: (keys, cb) => {
      const res = {};
      keys.forEach(k => {
        const v = localStorage.getItem(k);
        if (v) { try { res[k] = JSON.parse(v); } catch(e) { res[k] = v; } }
      });
      cb(res);
    },
    set: (obj, cb) => {
      Object.keys(obj).forEach(k => {
        localStorage.setItem(k, typeof obj[k] === 'string' ? obj[k] : JSON.stringify(obj[k]));
      });
      if (cb) cb();
    }
  };

  // Pure JS SHA-256
  function sha256(ascii) {
    function rightRotate(value, amount) { return (value >>> amount) | (value << (32 - amount)); }
    const mathPow = Math.pow;
    const maxWord = mathPow(2, 32);
    let i, j, result = "";
    const words = [];
    const asciiBitLength = ascii.length * 8;
    let hash = [1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225];
    const k = [1116353495, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220582, 2821834349, 2952996808, 3210303673, 3351621020, 3550774125, 3726977931, 43930325, 432321453, 680338304, 911762404, 1324619475, 1461945468, 1636015830, 2004544895, 2116912754, 2443663013, 2615463055, 2737384013, 2820302411, 3175210134, 3226602751, 3362021179, 3614889275, 3879494473, 4087679399, 417249870, 712078646, 804652248, 883484777, 1475338833, 1697187994, 2011116292, 2261945899, 2645119093, 3030014760, 3191912119, 3279165249, 3451662194, 3751680931];
    const isComposite = {};
    for (let candidate = 2; words.length < 64; candidate++) {
      if (!isComposite[candidate]) {
        for (i = 0; i < 313; i += candidate) isComposite[i] = candidate;
        hash[words.length] = (mathPow(candidate, .5) * maxWord) | 0;
        k[words.length++] = (mathPow(candidate, 1 / 3) * maxWord) | 0;
      }
    }
    ascii += "\x80";
    while (ascii.length % 64 - 56) ascii += "\x00";
    for (i = 0; i < ascii.length; i++) {
      j = ascii.charCodeAt(i);
      if (j >> 8) return "";
      words[i >> 2] |= j << ((3 - i) % 4) * 8;
    }
    words[words.length] = ((asciiBitLength / maxWord) | 0);
    words[words.length] = asciiBitLength;
    for (j = 0; j < words.length;) {
      const w = words.slice(j, j += 16);
      const oldHash = hash;
      hash = hash.slice(0, 8);
      for (i = 0; i < 64; i++) {
        const i2 = i + j;
        const w15 = w[i - 15], w2 = w[i - 2];
        const a = hash[0], e = hash[4];
        const temp1 = hash[7] + (rightRotate(e, 6) ^ rightRotate(e, 11) ^ rightRotate(e, 25)) + ((e & hash[5]) ^ ((~e) & hash[6])) + k[i] + (w[i] = (i < 16) ? w[i] : (w[i - 16] + (rightRotate(w15, 7) ^ rightRotate(w15, 18) ^ (w15 >>> 3)) + w[i - 7] + (rightRotate(w2, 17) ^ rightRotate(w2, 19) ^ (w2 >>> 10))) | 0);
        const temp2 = (rightRotate(a, 2) ^ rightRotate(a, 13) ^ rightRotate(a, 22)) + ((a & hash[1]) ^ (a & hash[2]) ^ (hash[1] & hash[2]));
        hash = [(temp1 + temp2) | 0].concat(hash);
        hash[4] = (hash[4] + temp1) | 0;
      }
      for (i = 0; i < 8; i++) hash[i] = (hash[i] + oldHash[i]) | 0;
    }
    for (i = 0; i < 8; i++) {
      for (j = 3; j + 1; j--) {
        const b = (hash[i] >> (j * 8)) & 255;
        result += ((b < 16) ? 0 : "") + b.toString(16);
      }
    }
    return result;
  }

  // Pure JS HMAC-SHA256
  function hmacSha256(key, message) {
    let keyBytes = [];
    for (let i = 0; i < key.length; i++) keyBytes.push(key.charCodeAt(i));
    if (keyBytes.length > 64) {
      const h = sha256(key);
      keyBytes = [];
      for (let i = 0; i < h.length; i += 2) keyBytes.push(parseInt(h.substr(i, 2), 16));
    }
    while (keyBytes.length < 64) keyBytes.push(0);

    let oPad = "";
    let iPad = "";
    for (let i = 0; i < 64; i++) {
      oPad += String.fromCharCode(keyBytes[i] ^ 0x5c);
      iPad += String.fromCharCode(keyBytes[i] ^ 0x36);
    }

    const innerHashHex = sha256(iPad + message);
    let innerHashStr = "";
    for (let i = 0; i < innerHashHex.length; i += 2) {
      innerHashStr += String.fromCharCode(parseInt(innerHashHex.substr(i, 2), 16));
    }
    return sha256(oPad + innerHashStr);
  }

  // Unique Composite Hardware Fingerprint
  function getHardwareFingerprint() {
    try {
      let canvasData = "";
      try {
        const canvas = document.createElement("canvas");
        const ctx = canvas.getContext("2d");
        ctx.textBaseline = "top";
        ctx.font = "14px Arial";
        ctx.fillStyle = "#066652";
        ctx.fillRect(100, 1, 60, 20);
        ctx.fillStyle = "#ffffff";
        ctx.fillText("Kimberbyte-Shield-2026", 2, 15);
        canvasData = canvas.toDataURL().substring(0, 100);
      } catch (ce) {
        canvasData = "canvas_disabled";
      }

      const raw = [
        navigator.userAgent || "Desktop",
        navigator.hardwareConcurrency || 4,
        (window.screen ? `${window.screen.width}x${window.screen.height}` : "1920x1080"),
        (window.screen ? window.screen.colorDepth : 24),
        (Intl && Intl.DateTimeFormat ? Intl.DateTimeFormat().resolvedOptions().timeZone : "UTC"),
        navigator.language || "en",
        canvasData
      ].join("###");

      return sha256(raw).substring(0, 16);
    } catch (e) {
      return sha256(navigator.userAgent + "###fallback").substring(0, 16);
    }
  }

  // Verify License Key Cryptographic Signature & Expiry
  function verifyKeySignature(keyStr) {
    if (!keyStr || typeof keyStr !== "string") {
      return { valid: false, error: "Please enter a license key." };
    }
    const clean = keyStr.trim().toUpperCase();
    const parts = clean.split("-");

    if (parts.length !== 6 || parts[0] !== "KB") {
      return { valid: false, error: "Invalid Kimberbyte key format. Expected: KB-[NAME]-[EXPIRY]-[TOOLS]-[NONCE]-[SIG]" };
    }

    const [prefix, slug, expiryCode, tools, nonce, sig] = parts;
    const payload = `KB|${slug}|${expiryCode}|${tools}|${nonce}`.toUpperCase();
    const expectedSig = hmacSha256(KB_SECRET, payload).toUpperCase().substring(0, 8);

    if (sig !== expectedSig) {
      return { valid: false, error: "Tampered or invalid cryptographic key signature!" };
    }

    // Check expiration
    let isExpired = false;
    let expFormatted = "Lifetime Access";
    if (expiryCode !== "LIFETIME") {
      if (expiryCode.length !== 6) {
        return { valid: false, error: "Invalid expiry date code." };
      }
      const yy = 2000 + parseInt(expiryCode.substring(0, 2), 10);
      const mm = parseInt(expiryCode.substring(2, 4), 10) - 1;
      const dd = parseInt(expiryCode.substring(4, 6), 10);
      const expDate = new Date(yy, mm, dd, 23, 59, 59);
      expFormatted = expDate.toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric" });
      if (Date.now() > expDate.getTime()) {
        isExpired = true;
      }
    }

    if (isExpired) {
      return { valid: false, error: `This Kimberbyte license expired on ${expFormatted}. Please renew your subscription.`, expired: true };
    }

    return {
      valid: true,
      slug: slug,
      expiryCode: expiryCode,
      expiryDate: expFormatted,
      tools: tools,
      key: clean
    };
  }

  // Check Remote Revocation List (with 2s timeout & offline fallback)
  async function checkRemoteRevocation(keyStr) {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 2000);
      const res = await fetch(REVOCATION_URL + "?nocache=" + Date.now(), { signal: controller.signal });
      clearTimeout(timeoutId);
      if (res.ok) {
        const revokedList = await res.json();
        if (Array.isArray(revokedList)) {
          const upperKey = keyStr.trim().toUpperCase();
          if (revokedList.some(k => upperKey.includes(k.toUpperCase()))) {
            return { revoked: true, reason: "License revoked by Kimberbyte administration." };
          }
        }
      }
    } catch (e) {
      // Offline fallback: do not lock user out if offline/network timeout
    }
    return { revoked: false };
  }

  // Master License Check & Enforcer
  function ensureLicense(toolRequired, onSuccess) {
    storage.get(['kb_license_key', 'kb_license_fp', 'kb_license_data'], async (res) => {
      const storedKey = res.kb_license_key;
      const storedFp = res.kb_license_fp;
      const currentFp = getHardwareFingerprint();

      if (storedKey) {
        const ver = verifyKeySignature(storedKey);
        if (ver.valid) {
          // Check hardware lock
          if (storedFp && storedFp !== currentFp) {
            showLicenseModal("Machine Mismatch: This license is already bound to another device. Please contact Kimberbyte.", toolRequired, onSuccess);
            return;
          }

          // Tool permission check
          if (ver.tools !== "ALL" && ver.tools !== toolRequired) {
            showLicenseModal(`Your license only permits [${ver.tools}], but this tool requires [${toolRequired}].`, toolRequired, onSuccess);
            return;
          }

          // Remote revocation check
          const rev = await checkRemoteRevocation(storedKey);
          if (rev.revoked) {
            storage.set({ kb_license_key: null }, () => {
              showLicenseModal(rev.reason, toolRequired, onSuccess);
            });
            return;
          }

          // Fully authorized!
          if (typeof onSuccess === "function") {
            onSuccess(ver);
          }
          return;
        }
      }

      // No valid key stored -> Prompt for Activation
      showLicenseModal(null, toolRequired, onSuccess);
    });
  }

  // License Activation Modal Injection
  function showLicenseModal(errorMessage, toolRequired, onSuccess) {
    let modal = document.getElementById("kb-license-shield-modal");
    if (!modal) {
      modal = document.createElement("div");
      modal.id = "kb-license-shield-modal";
      modal.style.cssText = `
        position: fixed; top: 0; left: 0; width: 100vw; height: 100vh;
        background: rgba(4, 8, 16, 0.94); backdrop-filter: blur(10px);
        z-index: 2147483647; display: flex; align-items: center; justify-content: center;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      `;

      modal.innerHTML = `
        <div style="background: #0f172a; border: 1px solid #1e293b; border-radius: 16px; width: 100%; max-width: 480px; padding: 28px; box-shadow: 0 25px 50px rgba(0,0,0,0.8); text-align: center; color: #f8fafc;">
          <div style="width: 50px; height: 50px; background: linear-gradient(135deg, #2563eb, #38bdf8); border-radius: 12px; margin: 0 auto 16px; display: flex; align-items: center; justify-content: center; font-size: 24px; font-weight: 800; color: #fff; box-shadow: 0 6px 18px rgba(37, 99, 235, 0.4);">K</div>
          <h2 style="font-size: 19px; font-weight: 800; margin-bottom: 6px; color: #fff;">Kimberbyte Enterprise Activation</h2>
          <p style="font-size: 12px; color: #94a3b8; line-height: 1.5; margin-bottom: 20px;">
            This software suite is protected by Kimberbyte Hardware-Locked Shield. Enter your authorized client license key to unlock.
          </p>
          <div id="kb-license-error-box" style="display: none; padding: 10px 14px; background: rgba(239, 68, 68, 0.15); border: 1px solid rgba(239, 68, 68, 0.4); border-radius: 8px; color: #fca5a5; font-size: 12px; font-weight: 600; margin-bottom: 14px; text-align: left;"></div>
          <div style="margin-bottom: 18px; text-align: left;">
            <label style="display: block; font-size: 11.5px; font-weight: 700; color: #cbd5e1; margin-bottom: 6px;">Client License Key:</label>
            <input type="text" id="kb-input-license-key" placeholder="KB-CLIENT-261224-ALL-XXXX-XXXXXXXX" style="width: 100%; padding: 12px 14px; background: #080d1a; border: 1px solid #334155; border-radius: 8px; color: #38bdf8; font-family: monospace; font-size: 14px; font-weight: 700; outline: none; box-sizing: border-box;" />
          </div>
          <button type="button" id="kb-btn-activate-license" style="width: 100%; padding: 13px; background: linear-gradient(135deg, #2563eb, #1d4ed8); border: none; border-radius: 9px; color: #fff; font-size: 14.5px; font-weight: 700; cursor: pointer; box-shadow: 0 4px 14px rgba(37, 99, 235, 0.35); transition: all 0.2s;">
            🔓 Activate Kimberbyte Suite
          </button>
          <div style="font-size: 11px; color: #64748b; margin-top: 18px; line-height: 1.4;">
            Don't have a license key? Contact Kimberbyte Administration.<br>
            Protected by Cryptographic Hardware Binding.
          </div>
        </div>
      `;
      document.body.appendChild(modal);

      const btn = document.getElementById("kb-btn-activate-license");
      const inp = document.getElementById("kb-input-license-key");
      const errBox = document.getElementById("kb-license-error-box");

      btn.addEventListener("click", () => {
        const keyVal = inp.value.trim();
        const ver = verifyKeySignature(keyVal);
        if (!ver.valid) {
          errBox.textContent = ver.error;
          errBox.style.display = "block";
          return;
        }

        // Check tool permission
        if (ver.tools !== "ALL" && ver.tools !== toolRequired) {
          errBox.textContent = `This key is for [${ver.tools}], but this module requires [${toolRequired}].`;
          errBox.style.display = "block";
          return;
        }

        // Bind to machine hardware fingerprint
        const machineFp = getHardwareFingerprint();
        storage.set({
          kb_license_key: ver.key,
          kb_license_fp: machineFp,
          kb_license_data: ver
        }, () => {
          modal.remove();
          if (typeof onSuccess === "function") {
            onSuccess(ver);
          }
        });
      });
    }

    if (errorMessage) {
      const errBox = document.getElementById("kb-license-error-box");
      if (errBox) {
        errBox.textContent = errorMessage;
        errBox.style.display = "block";
      }
    }
  }

  // Export to window
  window.KimberbyteLicenseShield = Object.freeze({
    ensureLicense: ensureLicense,
    verifyKeySignature: verifyKeySignature,
    getHardwareFingerprint: getHardwareFingerprint
  });

})(typeof window !== 'undefined' ? window : this);
