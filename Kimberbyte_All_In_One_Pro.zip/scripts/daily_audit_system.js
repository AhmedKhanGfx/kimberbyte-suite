/**
 * Kimberbyte Suite - Unified Daily History, Audit Trail & Timeline Engine
 * Shared across Multi-Mail Pro, WhatsApp Bot Pro, and MailFlow Hostinger
 */

(function () {
  'use strict';

  const storage = (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) ? chrome.storage.local : {
    get: (keys, cb) => {
      const res = {};
      keys.forEach(k => {
        const v = localStorage.getItem(k);
        if (v) { try { res[k] = JSON.parse(v); } catch(e) { res[k] = v; } }
      });
      cb(res);
    },
    set: (obj, cb) => {
      Object.keys(obj).forEach(k => {
        localStorage.setItem(k, typeof obj[k] === 'string' ? obj[k] : JSON.stringify(obj[k]));
      });
      if (cb) cb();
    }
  };

  const STORAGE_KEYS = {
    multimail: "kb_multimail_audit_logs",
    wa: "kb_wa_audit_logs",
    hostinger: "kb_hostinger_audit_logs"
  };

  const TOOL_NAMES = {
    multimail: "Multi-Mail Pro (3x Parallel Engine)",
    wa: "WhatsApp Campaign Pro",
    hostinger: "MailFlow Hostinger Webmail"
  };

  function getTodayStr() {
    return new Date().toISOString().slice(0, 10);
  }

  function getYesterdayStr() {
    const d = new Date();
    d.setDate(d.getDate() - 1);
    return d.toISOString().slice(0, 10);
  }

  function getDayBeforeStr() {
    const d = new Date();
    d.setDate(d.getDate() - 2);
    return d.toISOString().slice(0, 10);
  }

  const DailyAuditSystem = {
    recordDispatch: function (tool, item, cb) {
      const key = STORAGE_KEYS[tool] || STORAGE_KEYS.multimail;
      storage.get([key], (res) => {
        const logs = (res && res[key] && typeof res[key] === 'object') ? res[key] : {};
        const today = getTodayStr();

        if (!logs[today]) {
          logs[today] = {
            date: today,
            sent: 0,
            failed: 0,
            total: 0,
            events: []
          };
        }

        const dayObj = logs[today];
        dayObj.total = (dayObj.total || 0) + 1;
        if (item.status === 'SENT') {
          dayObj.sent = (dayObj.sent || 0) + 1;
        } else {
          dayObj.failed = (dayObj.failed || 0) + 1;
        }

        dayObj.events.push({
          id: Date.now() + "_" + Math.random().toString(36).substring(2, 6),
          time: new Date().toLocaleTimeString(),
          recipient: String(item.recipient || ''),
          name: String(item.name || 'Lead'),
          status: item.status || 'SENT',
          reason: item.reason || '',
          inbox: item.inbox || '',
          delaySec: item.delaySec || 0
        });

        // Prune logs older than 60 days
        const dates = Object.keys(logs).sort().reverse();
        if (dates.length > 60) {
          dates.slice(60).forEach(d => delete logs[d]);
        }

        const saveObj = {};
        saveObj[key] = logs;
        storage.set(saveObj, () => {
          if (cb) cb(dayObj);
        });
      });
    },

    getLogs: function (tool, cb) {
      const key = STORAGE_KEYS[tool] || STORAGE_KEYS.multimail;
      storage.get([key], (res) => {
        const logs = (res && res[key] && typeof res[key] === 'object') ? res[key] : {};
        cb(logs);
      });
    },

    openModal: function (tool) {
      let modal = document.getElementById("kbDailyAuditModal");
      if (!modal) {
        modal = document.createElement("div");
        modal.id = "kbDailyAuditModal";
        modal.className = "kb-audit-modal-backdrop";
        document.body.appendChild(modal);
      }

      DailyAuditSystem.getLogs(tool, (logs) => {
        DailyAuditSystem.renderModalContent(modal, tool, logs, 'today');
        modal.style.display = "flex";
      });
    },

    closeModal: function () {
      const modal = document.getElementById("kbDailyAuditModal");
      if (modal) modal.style.display = "none";
    },

    renderModalContent: function (modal, tool, logs, activeTab) {
      const today = getTodayStr();
      const yesterday = getYesterdayStr();
      const dayBefore = getDayBeforeStr();

      let targetDates = [];
      let tabTitle = "";

      if (activeTab === 'today') {
        targetDates = [today];
        tabTitle = `Today's Activity (${today})`;
      } else if (activeTab === 'yesterday') {
        targetDates = [yesterday];
        tabTitle = `Yesterday's Activity (${yesterday})`;
      } else if (activeTab === 'daybefore') {
        targetDates = [dayBefore];
        tabTitle = `Day Before Yesterday (${dayBefore})`;
      } else if (activeTab === 'week') {
        const d = new Date();
        for (let i = 0; i < 7; i++) {
          const dt = new Date();
          dt.setDate(d.getDate() - i);
          targetDates.push(dt.toISOString().slice(0, 10));
        }
        tabTitle = "Past 7 Days Summary";
      } else if (activeTab === 'month') {
        const d = new Date();
        for (let i = 0; i < 30; i++) {
          const dt = new Date();
          dt.setDate(d.getDate() - i);
          targetDates.push(dt.toISOString().slice(0, 10));
        }
        tabTitle = "Past 30 Days Summary";
      } else {
        // all
        targetDates = Object.keys(logs).sort().reverse();
        tabTitle = "All Historical Logs";
      }

      // Aggregate events for target dates
      let totalSent = 0;
      let totalFailed = 0;
      let allEvents = [];
      let rejectedList = [];

      targetDates.forEach(dateStr => {
        const day = logs[dateStr];
        if (day) {
          totalSent += (day.sent || 0);
          totalFailed += (day.failed || 0);
          if (Array.isArray(day.events)) {
            day.events.forEach(ev => {
              const fullEv = { ...ev, date: dateStr };
              allEvents.push(fullEv);
              if (ev.status === 'REJECTED' || ev.status === 'FAILED') {
                rejectedList.push(fullEv);
              }
            });
          }
        }
      });

      const totalAttempted = totalSent + totalFailed;
      const successRate = totalAttempted > 0 ? Math.round((totalSent / totalAttempted) * 100) : 100;

      modal.innerHTML = `
        <div class="kb-audit-modal-dialog">
          <!-- MODAL HEADER -->
          <div class="kb-audit-modal-header">
            <div style="display:flex; align-items:center; gap:10px;">
              <span style="font-size:18px;">📊</span>
              <div>
                <div style="font-size:14px; font-weight:800; color:#f8fafc;">Daily History & Audit Trail</div>
                <div style="font-size:11px; color:#38bdf8; font-weight:600;">${TOOL_NAMES[tool] || 'Outreach Engine'}</div>
              </div>
            </div>
            <div style="display:flex; align-items:center; gap:8px;">
              <button type="button" class="kb-audit-btn-export" id="btnAuditExportCsv">📥 Export CSV</button>
              <button type="button" class="kb-audit-btn-close" id="btnAuditCloseModal">✕</button>
            </div>
          </div>

          <!-- DATE SELECTOR TABS -->
          <div class="kb-audit-tabs">
            <button type="button" class="kb-audit-tab ${activeTab === 'today' ? 'active' : ''}" data-tab="today">Today (Aaj)</button>
            <button type="button" class="kb-audit-tab ${activeTab === 'yesterday' ? 'active' : ''}" data-tab="yesterday">Yesterday (Kal)</button>
            <button type="button" class="kb-audit-tab ${activeTab === 'daybefore' ? 'active' : ''}" data-tab="daybefore">2 Days Ago (Perso)</button>
            <button type="button" class="kb-audit-tab ${activeTab === 'week' ? 'active' : ''}" data-tab="week">Past 7 Days</button>
            <button type="button" class="kb-audit-tab ${activeTab === 'month' ? 'active' : ''}" data-tab="month">Past 30 Days</button>
            <button type="button" class="kb-audit-tab ${activeTab === 'all' ? 'active' : ''}" data-tab="all">All Dates</button>
          </div>

          <!-- SUMMARY CARDS -->
          <div class="kb-audit-summary-grid">
            <div class="kb-audit-card">
              <div class="kb-audit-card-label">Total Delivered</div>
              <div class="kb-audit-card-val text-green">${totalSent}</div>
              <div class="kb-audit-card-sub">Successfully Sent</div>
            </div>
            <div class="kb-audit-card">
              <div class="kb-audit-card-label">Total Rejected</div>
              <div class="kb-audit-card-val text-red">${totalFailed}</div>
              <div class="kb-audit-card-sub">Failed / Invalid Leads</div>
            </div>
            <div class="kb-audit-card">
              <div class="kb-audit-card-label">Success Rate</div>
              <div class="kb-audit-card-val text-blue">${successRate}%</div>
              <div class="kb-audit-card-sub">${totalAttempted} Attempted</div>
            </div>
          </div>

          <!-- REJECTED LEADS SECTION (IF ANY) -->
          ${rejectedList.length > 0 ? `
            <div class="kb-audit-rejected-box">
              <div class="kb-audit-rejected-header">
                <span>❌</span>
                <b>Rejected / Failed Leads in this Period (${rejectedList.length}):</b>
              </div>
              <div class="kb-audit-rejected-list">
                ${rejectedList.map(item => `
                  <div class="kb-audit-rejected-item">
                    <div style="font-weight:700; color:#f87171;">${item.recipient} ${item.name ? `(${item.name})` : ''}</div>
                    <div style="font-size:10.5px; color:#94a3b8; display:flex; justify-content:space-between; margin-top:2px;">
                      <span>Reason: <b style="color:#ef4444;">${item.reason || 'Verification rejected'}</b></span>
                      <span>${item.date} at ${item.time}</span>
                    </div>
                  </div>
                `).join('')}
              </div>
            </div>
          ` : `
            <div class="kb-audit-clean-badge">
              <span>✓</span> Zero Rejected Leads in this period! 100% clean delivery.
            </div>
          `}

          <!-- STEP-BY-STEP DELIVERY TIMELINE -->
          <div class="kb-audit-timeline-title">
            <span>⏱️ Step-by-Step Delivery Timeline (${tabTitle})</span>
            <span style="font-size:10.5px; color:#64748b; font-weight:normal;">Anti-Spam Pacing Intervals Recorded</span>
          </div>

          <div class="kb-audit-timeline-feed">
            ${allEvents.length === 0 ? `
              <div class="kb-audit-empty">No outreach activity recorded for this period yet. Dispatched campaigns will automatically populate here.</div>
            ` : allEvents.map((ev, idx) => `
              <div class="kb-audit-timeline-item">
                <div class="kb-audit-timeline-marker ${ev.status === 'SENT' ? 'marker-green' : 'marker-red'}"></div>
                <div class="kb-audit-timeline-content">
                  <div class="kb-audit-timeline-row">
                    <span class="kb-audit-lead-name"><b>${ev.name || 'Lead'}</b> &lt;${ev.recipient}&gt;</span>
                    <span class="kb-audit-tag ${ev.status === 'SENT' ? 'tag-sent' : 'tag-failed'}">${ev.status}</span>
                  </div>
                  <div class="kb-audit-timeline-meta">
                    <span>${ev.date} at ${ev.time}</span>
                    ${ev.inbox ? `<span>Dispatched via: <code>${ev.inbox}</code></span>` : ''}
                  </div>
                  ${ev.delaySec > 0 && idx < allEvents.length - 1 ? `
                    <div class="kb-audit-timer-badge">
                      <span>⏳</span>
                      <span>Anti-Ban Safety Interval: <b>${ev.delaySec} seconds</b> pause before next lead</span>
                    </div>
                  ` : ''}
                </div>
              </div>
            `).join('')}

            <!-- UPCOMING BATCH TIMER -->
            <div class="kb-audit-upcoming-box">
              <div style="display:flex; align-items:center; gap:8px;">
                <span>📅</span>
                <b>Next Daily Auto-Scheduler Cycle:</b>
              </div>
              <span style="color:#38bdf8; font-weight:700;">Daily Schedule Active (Triggers automatically at configured time)</span>
            </div>
          </div>
        </div>
      `;

      // Bind Tab clicks
      modal.querySelectorAll(".kb-audit-tab").forEach(btn => {
        btn.addEventListener("click", () => {
          const tabKey = btn.getAttribute("data-tab");
          DailyAuditSystem.renderModalContent(modal, tool, logs, tabKey);
        });
      });

      // Bind Close button
      const btnClose = modal.querySelector("#btnAuditCloseModal");
      if (btnClose) btnClose.addEventListener("click", DailyAuditSystem.closeModal);

      // Close on backdrop click
      modal.onclick = (e) => {
        if (e.target === modal) DailyAuditSystem.closeModal();
      };

      // Bind CSV Export
      const btnExport = modal.querySelector("#btnAuditExportCsv");
      if (btnExport) {
        btnExport.addEventListener("click", () => {
          DailyAuditSystem.exportToCsv(tool, allEvents, activeTab);
        });
      }
    },

    exportToCsv: function (tool, events, periodLabel) {
      if (!events || events.length === 0) {
        alert("No records to export for this period!");
        return;
      }

      const headers = ["Date", "Time", "Recipient", "Name", "Status", "Reason", "Sender / Inbox", "Pacing Delay (sec)"];
      const rows = events.map(e => [
        `"${e.date || ''}"`,
        `"${e.time || ''}"`,
        `"${e.recipient || ''}"`,
        `"${(e.name || '').replace(/"/g, '""')}"`,
        `"${e.status || ''}"`,
        `"${(e.reason || '').replace(/"/g, '""')}"`,
        `"${e.inbox || ''}"`,
        e.delaySec || 0
      ]);

      const csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), ...rows.map(r => r.join(","))].join("\n");
      const encodedUri = encodeURI(csvContent);
      const link = document.createElement("a");
      link.setAttribute("href", encodedUri);
      link.setAttribute("download", `Kimberbyte_${tool}_Audit_Log_${periodLabel}_${getTodayStr()}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  window.DailyAuditSystem = DailyAuditSystem;
})();
