/**
 * Kimberbyte WhatsApp Bot Pro - Content Automation Engine
 * Autonomous In-App WhatsApp Campaign & Outreach Controller
 * 100% Unlocked Standalone Edition (Zero Server Dependency)
 * 
 * Features:
 * 1. Smart Dynamic Random Timer (Auto Human Delay 15s - 65s)
 * 2. Live Editable Countdown On-The-Fly (Adjust time or Send Now without stopping campaign)
 * 3. Pre-Campaign Duplicate Phone Detection & Choice Modal (Skip Duplicates vs Send All)
 * 4. Persistent Auto-Save for Templates & Settings (Restores on next launch)
 */

(function () {
  'use strict';

  // Prevent duplicate injections
  if (window.__KIMBERBYTE_WA_BOT_MOUNTED__) return;
  window.__KIMBERBYTE_WA_BOT_MOUNTED__ = true;

  console.log("[WhatsApp Bot Pro] Mounting 100% Standalone Autonomous Engine...");

  // Application State
  const state = {
    activeTab: 'sheet', // 'sheet', 'paste', 'direct'
    contacts: [],       // [{ name, phone, raw }]
    attachment: null,   // { file, name, size, type }
    campaign: {
      isRunning: false,
      isPaused: false,
      currentIndex: 0,
      sent: 0,
      failed: 0,
      results: [],
      activeCountdownRemaining: 0
    },
    settings: {
      smartTimer: true,
      minDelay: 15,
      maxDelay: 45,
      defaultCc: '92',
      antiBan: true
    }
  };

  const sleep = (ms) => new Promise(r => setTimeout(r, ms));

  // Storage helper
  const storage = (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) ? chrome.storage.local : {
    get: (keys, cb) => {
      const res = {};
      keys.forEach(k => {
        const v = localStorage.getItem(k);
        if (v) {
          try { res[k] = JSON.parse(v); } catch(e) { res[k] = v; }
        }
      });
      cb(res);
    },
    set: (obj, cb) => {
      Object.keys(obj).forEach(k => {
        localStorage.setItem(k, typeof obj[k] === "string" ? obj[k] : JSON.stringify(obj[k]));
      });
      if (cb) cb();
    }
  };

  // --- PHONE VALIDATOR & E.164 SANITIZER ---
  function validateAndCleanPhone(raw, defaultCc) {
    if (!raw) return { phone: '', isValid: false, reason: 'Empty phone value' };
    let digits = String(raw).replace(/\D/g, '');
    if (!digits) return { phone: '', isValid: false, reason: 'No digits found' };

    // Strip leading 00
    if (digits.startsWith('00')) digits = digits.substring(2);

    // If starts with 0 (e.g. 03001234567 in Pakistan), replace 0 with country code
    if (digits.startsWith('0') && defaultCc) {
      digits = defaultCc + digits.substring(1);
    } else if (!digits.startsWith('0') && defaultCc && digits.length <= 10) {
      digits = defaultCc + digits;
    }

    // Standard ITU-T E.164 length check (8 to 15 digits)
    if (digits.length < 8) {
      return { phone: digits, isValid: false, reason: 'Too short (min 8 digits)' };
    }
    if (digits.length > 15) {
      return { phone: digits, isValid: false, reason: 'Too long (max 15 digits)' };
    }

    // Reject repetitive dummy numbers (e.g. 00000000, 11111111)
    if (/^(\d)\1+$/.test(digits)) {
      return { phone: digits, isValid: false, reason: 'Repetitive test digits' };
    }

    return { phone: digits, isValid: true };
  }

  // Backward compatible cleanPhoneNumber wrapper
  function cleanPhoneNumber(raw, defaultCc) {
    const res = validateAndCleanPhone(raw, defaultCc);
    return res.phone;
  }

  // --- KIMBERBYTE SMART MEMORY (Lifetime Contact Database & Anti-Repeat Engine) ---
  const SmartMemory = {
    KEY: "kb_outreach_history_db",

    get: (cb) => {
      storage.get([SmartMemory.KEY], (res) => {
        let mem = res && res[SmartMemory.KEY];
        if (!mem || typeof mem !== "object") {
          mem = { numbers: {}, emails: {}, stats: { totalNumbers: 0, totalEmails: 0 } };
        }
        if (!mem.numbers) mem.numbers = {};
        if (!mem.emails) mem.emails = {};
        cb(mem);
      });
    },

    save: (mem, cb) => {
      mem.stats = {
        totalNumbers: Object.keys(mem.numbers || {}).length,
        totalEmails: Object.keys(mem.emails || {}).length,
        lastUpdated: new Date().toLocaleString()
      };
      const toSet = {};
      toSet[SmartMemory.KEY] = mem;
      storage.set(toSet, () => {
        updateMemoryBadge();
        if (cb) cb();
      });
    },

    recordWhatsApp: (phone, name, status, cb) => {
      SmartMemory.get((mem) => {
        const cleanP = String(phone).replace(/\D/g, "");
        if (!cleanP) return;
        const prev = mem.numbers[cleanP] || { count: 0 };
        mem.numbers[cleanP] = {
          name: name || prev.name || "Client",
          lastSent: new Date().toLocaleString(),
          count: (prev.count || 0) + 1,
          status: status || "DELIVERED",
          channel: "whatsapp"
        };
        SmartMemory.save(mem, cb);
      });
    },

    checkWhatsAppList: (contacts, cb) => {
      SmartMemory.get((mem) => {
        const seenInList = new Set();
        const listDuplicates = [];
        const historyDuplicates = [];
        const freshContacts = [];
        const uniqueContacts = [];

        contacts.forEach(c => {
          const p = String(c.phone).replace(/\D/g, "");
          const isHist = !!mem.numbers[p];
          const isListDup = seenInList.has(p);

          if (isListDup) {
            listDuplicates.push({ ...c, historyMeta: mem.numbers[p] });
          } else {
            seenInList.add(p);
            uniqueContacts.push(c);
            if (isHist) {
              historyDuplicates.push({ ...c, historyMeta: mem.numbers[p] });
            } else {
              freshContacts.push(c);
            }
          }
        });

        cb({
          listDuplicates,
          historyDuplicates,
          uniqueContacts,
          freshContacts,
          totalMemoryCount: Object.keys(mem.numbers || {}).length
        });
      });
    },

    exportCSV: () => {
      SmartMemory.get((mem) => {
        const numbers = mem.numbers || {};
        const keys = Object.keys(numbers);
        if (keys.length === 0) {
          alert("Smart Memory is currently empty! No past contacts recorded yet.");
          return;
        }
        let csv = "Phone,Name,Last Sent,Sent Count,Channel,Status\r\n";
        keys.forEach(k => {
          const item = numbers[k];
          csv += `"${k}","${(item.name || '').replace(/"/g, '""')}","${item.lastSent || ''}","${item.count || 1}","whatsapp","${item.status || 'DELIVERED'}"\r\n`;
        });
        const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `Kimberbyte_Smart_Memory_WhatsApp_${new Date().toISOString().slice(0,10)}.csv`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      });
    },

    clear: () => {
      if (confirm("Are you sure you want to clear your Smart Memory history? This will reset all previously contacted numbers.")) {
        SmartMemory.save({ numbers: {}, emails: {}, stats: { totalNumbers: 0, totalEmails: 0 } }, () => {
          alert("Smart Memory history reset successfully!");
        });
      }
    }
  };
  window.SmartMemory = SmartMemory;

  // --- SMART DAILY QUEUE & SCHEDULER ENGINE ---
  const QueueManager = {
    QUEUE_KEY: "kb_wa_daily_queue",
    SETTINGS_KEY: "kb_wa_queue_settings",

    getSettings: (cb) => {
      storage.get([QueueManager.SETTINGS_KEY], (res) => {
        const today = new Date().toISOString().slice(0, 10);
        let settings = res && res[QueueManager.SETTINGS_KEY];
        if (!settings || typeof settings !== "object") {
          settings = { enabled: false, scheduleTime: "10:00", dailyCap: 50, lastDate: today, sentToday: 0 };
        }
        if (settings.lastDate !== today) {
          settings.lastDate = today;
          settings.sentToday = 0;
          QueueManager.saveSettings(settings);
        }
        cb(settings);
      });
    },

    saveSettings: (settings, cb) => {
      const obj = {};
      obj[QueueManager.SETTINGS_KEY] = settings;
      storage.set(obj, cb);
    },

    getQueue: (cb) => {
      storage.get([QueueManager.QUEUE_KEY], (res) => {
        const queue = (res && Array.isArray(res[QueueManager.QUEUE_KEY])) ? res[QueueManager.QUEUE_KEY] : [];
        cb(queue);
      });
    },

    saveQueue: (queue, cb) => {
      const obj = {};
      obj[QueueManager.QUEUE_KEY] = queue;
      storage.set(obj, () => {
        QueueManager.updateUI();
        if (cb) cb();
      });
    },

    addToQueue: (contacts, cb) => {
      QueueManager.getQueue((existing) => {
        const existingPhones = new Set(existing.map(c => String(c.phone || "")));
        const toAdd = contacts.filter(c => {
          const p = String(c.phone || "");
          return p && !existingPhones.has(p);
        });
        const updated = [...existing, ...toAdd];
        QueueManager.saveQueue(updated, cb);
      });
    },

    recordSent: (cb) => {
      QueueManager.getSettings((settings) => {
        settings.sentToday = (settings.sentToday || 0) + 1;
        QueueManager.saveSettings(settings, () => {
          QueueManager.updateUI();
          if (cb) cb(settings);
        });
      });
    },

    updateUI: () => {
      QueueManager.getQueue((queue) => {
        QueueManager.getSettings((settings) => {
          const pendingEl = document.getElementById("kb-queue-pending-count");
          const todayEl = document.getElementById("kb-queue-today-count");
          const capInp = document.getElementById("kb-daily-cap");
          const timeInp = document.getElementById("kb-wa-schedule-time");
          const chk = document.getElementById("kb-wa-schedule-chk");
          const lbl = document.getElementById("kb-wa-schedule-lbl");

          if (pendingEl) pendingEl.textContent = queue.length;
          if (todayEl) todayEl.textContent = `${settings.sentToday || 0} / ${settings.dailyCap || 50}`;
          if (capInp && document.activeElement !== capInp) capInp.value = settings.dailyCap || 50;
          if (timeInp && document.activeElement !== timeInp) timeInp.value = settings.scheduleTime || "10:00";
          if (chk) chk.checked = Boolean(settings.enabled);
          if (lbl) {
            lbl.textContent = settings.enabled ? "Auto-Schedule ON" : "Auto-Schedule";
            lbl.style.color = settings.enabled ? "#10b981" : "var(--kb-muted)";
          }
        });
      });
    }
  };
  window.QueueManager = QueueManager;


  function updateMemoryBadge() {
    SmartMemory.get((mem) => {
      const count = Object.keys(mem.numbers || {}).length;
      const countEl = document.getElementById("kb-wa-mem-count");
      if (countEl) {
        countEl.textContent = `${count} lead${count === 1 ? '' : 's'} remembered`;
      }
    });
  }

  // --- UI CREATION SAFEGUARD ---
  function isWhatsAppReady() {
    // 1. If QR code or Login screen is visible
    if (document.querySelector('canvas, [data-ref], [data-testid="qrcode"], [data-testid="intro-title"]')) return true;

    // 2. If logged-in chat interface is ready
    if (document.getElementById("pane-side") || document.getElementById("main") || document.querySelector('[data-testid="chat-list"]')) return true;

    // 3. Check if initial startup splash is active
    const splash = document.getElementById("initial_startup") || document.querySelector('progress, [role="progressbar"]');
    if (splash) {
      const isVisible = splash.offsetParent !== null || window.getComputedStyle(splash).display !== "none";
      if (isVisible) return false;
    }

    return true;
  }

  // --- UI CREATION ---
  function initUI() {
    if (!isWhatsAppReady()) {
      return;
    }

    // 1. Floating Launch Trigger Button
    if (!document.getElementById("kb-wa-trigger-btn")) {
      const trigger = document.createElement("div");
      trigger.id = "kb-wa-trigger-btn";
      trigger.innerHTML = `
        <div class="kb-wa-trigger-icon">
          <svg viewBox="0 0 24 24" width="26" height="26" fill="currentColor">
            <path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91C2.13 13.66 2.59 15.36 3.45 16.86L2.05 22L7.3 20.62C8.75 21.41 10.38 21.83 12.04 21.83C17.5 21.83 21.95 17.38 21.95 11.92C21.95 9.27 20.92 6.78 19.05 4.91C17.18 3.04 14.69 2 12.04 2ZM12.04 20.15C10.56 20.15 9.11 19.76 7.85 19.01L7.55 18.83L4.43 19.65L5.26 16.61L5.06 16.29C4.24 14.99 3.8 13.47 3.8 11.91C3.8 7.37 7.5 3.67 12.05 3.67C14.25 3.67 16.31 4.53 17.87 6.09C19.42 7.65 20.28 9.72 20.28 11.92C20.28 16.46 16.58 20.15 12.04 20.15ZM16.57 14.39C16.32 14.27 15.1 13.67 14.87 13.59C14.64 13.5 14.48 13.46 14.31 13.71C14.15 13.95 13.68 14.51 13.54 14.67C13.4 14.83 13.25 14.85 13 14.73C12.75 14.61 11.95 14.35 11 13.5C10.26 12.84 9.76 12.03 9.61 11.78C9.47 11.53 9.6 11.4 9.72 11.28C9.83 11.17 9.97 11 10.09 10.86C10.22 10.72 10.26 10.62 10.34 10.45C10.42 10.29 10.38 10.14 10.32 10.02C10.26 9.9 9.77 8.7 9.56 8.21C9.36 7.73 9.16 7.79 9.01 7.79C8.87 7.78 8.71 7.78 8.54 7.78C8.38 7.78 8.11 7.84 7.88 8.09C7.66 8.33 7.03 8.92 7.03 10.13C7.03 11.34 7.91 12.51 8.03 12.67C8.16 12.84 9.77 15.31 12.23 16.37C12.81 16.62 13.27 16.77 13.62 16.89C14.21 17.07 14.74 17.05 15.17 16.98C15.65 16.91 16.64 16.38 16.85 15.8C17.05 15.21 17.05 14.71 16.99 14.6C16.93 14.49 16.81 14.43 16.57 14.39Z"/>
          </svg>
        </div>
        <span class="kb-wa-trigger-label">WhatsApp Bot Pro</span>
      `;
      trigger.addEventListener("click", toggleDrawer);
      document.body.appendChild(trigger);
    }

    // 2. Main Slide-out Panel
    if (!document.getElementById("kb-wa-panel")) {
      const panel = document.createElement("div");
      panel.id = "kb-wa-panel";
      panel.className = "kb-wa-hidden";

      panel.innerHTML = `
        <div class="kb-wa-header">
          <div>
            <div class="kb-wa-title">
              <span> WhatsApp Bot Pro</span>
              <span class="kb-wa-badge">● Standalone Ready</span>
            </div>
            <div class="kb-wa-subtitle">Autonomous Client Broadcast & Outreach Suite</div>
          </div>
          <button class="kb-wa-btn-close" id="kb-wa-btn-close" title="Close Panel">✕</button>
        </div>

        <div class="kb-wa-tabs">
          <button class="kb-wa-tab-btn kb-wa-active" data-tab="sheet">📁 Excel / CSV</button>
          <button class="kb-wa-tab-btn" data-tab="paste">📝 Quick Paste</button>
          <button class="kb-wa-tab-btn" data-tab="direct">💬 Direct Chat</button>
          <button type="button" id="kb-btn-wa-audit" style="color:#38bdf8; border:1px solid rgba(56,189,248,0.3); background:rgba(56,189,248,0.1); border-radius:5px; padding:3px 8px; font-size:11px; font-weight:700; margin-left:auto; cursor:pointer;" title="View Daily History & Logs">📊 History</button>
        </div>

        <div class="kb-wa-body">
          <!-- Step 1: Recipients Source Card -->
          <div class="kb-wa-card">
            <div class="kb-wa-card-header">
              <div class="kb-wa-card-title">
                <span>1. Recipients & Contact List</span>
              </div>
            </div>

            <!-- Tab 1: Sheet Upload -->
            <div id="kb-tab-sheet" class="kb-wa-tab-content">
              <div class="kb-wa-dropzone" id="kb-dropzone">
                <svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12"/>
                </svg>
                <div style="font-weight: 700; font-size: 13px; margin-top: 6px;">Click or Drag Excel / CSV File</div>
                <div style="font-size: 11px; color: var(--kb-muted); margin-top: 2px;">Supports .xlsx, .xls, .csv lead lists</div>
                <input type="file" id="kb-file-input" accept=".xlsx, .xls, .csv" style="display:none;" />
              </div>

              <div id="kb-sheet-meta" style="display:none; margin-top: 12px;">
                <div style="font-size: 12px; color: var(--kb-primary); font-weight:700; margin-bottom: 6px;" id="kb-file-summary">Leads Loaded: 0</div>
                <div style="display:flex; gap:10px;">
                  <div style="flex:1;">
                    <label class="kb-wa-label">Phone Column</label>
                    <select id="kb-phone-col" class="kb-wa-select"></select>
                  </div>
                  <div style="flex:1;">
                    <label class="kb-wa-label">Name Column</label>
                    <select id="kb-name-col" class="kb-wa-select"></select>
                  </div>
                </div>
              </div>
            </div>

            <!-- Tab 2: Quick Paste -->
            <div id="kb-tab-paste" class="kb-wa-tab-content" style="display:none;">
              <label class="kb-wa-label">Paste Numbers (One per line or comma separated)</label>
              <textarea id="kb-paste-input" class="kb-wa-textarea" rows="3" placeholder="+923001234567, Ali&#10;+923219876543, Sara&#10;03015554321"></textarea>
              <div style="display:flex; justify-content:space-between; align-items:center; margin-top:6px;">
                <span id="kb-paste-count" style="font-size: 11px; color: var(--kb-muted);">0 contacts detected</span>
                <button type="button" id="kb-btn-parse-paste" class="kb-wa-btn-sm">Process List</button>
              </div>
            </div>

            <!-- Tab 3: Direct Single Chat -->
            <!-- Validation & Quality Banner -->
            <div id="kb-wa-validation-banner" class="kb-wa-val-banner" style="display:none;">
              <div style="display:flex; align-items:center; gap:8px;">
                <span id="kb-wa-val-ok" style="color:#10b981; font-weight:700;"> 0 Valid</span>
                <span style="color:var(--kb-border);">|</span>
                <span id="kb-wa-val-err" style="color:#ef4444; font-weight:700;">⚠️ 0 Filtered</span>
              </div>
              <span id="kb-wa-val-badge" style="font-size:10px; color:#38bdf8; background:rgba(56,189,248,0.15); padding:2px 6px; border-radius:4px; font-weight:700;">ITU E.164 Checked</span>
            </div>

            <!-- Smart Memory / Anti-Repeat Shield Bar -->
            <div id="kb-wa-memory-status" class="kb-wa-mem-pill">
              <div>🧠 <b style="color:var(--kb-text);">Smart Memory:</b> <span id="kb-wa-mem-count" style="color:#34d399; font-weight:700;">0 leads remembered</span></div>
              <div style="display:flex; gap:6px;">
                <button type="button" id="kb-wa-btn-view-mem" class="kb-wa-mem-btn" title="View previously contacted leads">📊 View</button>
                <button type="button" id="kb-wa-btn-export-mem" class="kb-wa-mem-btn" title="Export lifetime outreach history as CSV">📥 Export</button>
                <button type="button" id="kb-wa-btn-clear-mem" class="kb-wa-mem-btn kb-wa-mem-btn-danger" title="Clear memory history">🧹 Clear</button>
              </div>
            </div>
            <div id="kb-tab-direct" class="kb-wa-tab-content" style="display:none;">
              <label class="kb-wa-label">Target Phone Number</label>
              <input type="text" id="kb-direct-phone" class="kb-wa-input" placeholder="e.g. 03001234567 or +923001234567" />
              <label class="kb-wa-label" style="margin-top:8px;">Instant Direct Message</label>
              <textarea id="kb-direct-msg" class="kb-wa-textarea" rows="3" placeholder="Hello! Reaching out regarding your inquiry..."></textarea>
              <button type="button" id="kb-btn-direct-send" class="kb-wa-btn-primary" style="margin-top:10px;">🚀 Open Chat & Send</button>
            </div>
          </div>

          <!-- Step 2: Message Template Card -->
          <div class="kb-wa-card">
            <div class="kb-wa-card-header">
              <div class="kb-wa-card-title">
                <span>2. Broadcast Message Template</span>
              </div>
              <div style="display:flex; align-items:center; gap:8px;">
                <span id="kb-save-indicator" class="kb-wa-save-indicator" style="opacity:0;">✓ Saved</span>
                <button type="button" id="kb-btn-save-settings" class="kb-wa-btn-sm" title="Save message & settings">💾 Save</button>
              </div>
            </div>
            <textarea id="kb-msg-template" class="kb-wa-textarea" rows="4" placeholder="Hello {name}! We noticed your business is expanding..."></textarea>
            <div style="margin-top: 8px;">
              <span class="kb-wa-label" style="margin-bottom: 4px;">Insert Dynamic Tags:</span>
              <div class="kb-wa-tags">
                <span class="kb-wa-tag" data-tag="{name}">+ {name}</span>
                <span class="kb-wa-tag" data-tag="{phone}">+ {phone}</span>
                <span class="kb-wa-tag" data-tag="{date}">+ {date}</span>
                <span class="kb-wa-tag" data-tag="{address}">+ {address}</span>
              </div>
            </div>

            <!-- Business / Physical Address Option (Requested: Directly below Picture 5) -->
            <div class="kb-wa-address-section" style="margin-top: 14px; padding-top: 12px; border-top: 1px dashed var(--kb-border);">
              <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                <label class="kb-wa-label" style="margin: 0; font-weight: 700; color: #f1f5f9;">🏢 Business / Office Address Footer:</label>
                <label class="kb-wa-toggle-wrap" title="Toggle appending address at end of messages">
                  <label class="kb-checkbox-wrap" title="Include address">
                    <input type="checkbox" id="kb-wa-include-address-chk" checked />
                    <span class="kb-checkbox-box">
                      <svg class="kb-check-icon" viewBox="0 0 12 10" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="1.5 5 4.5 8 10.5 2"></polyline></svg>
                    </span>
                  </label>
                  <span id="kb-wa-address-toggle-lbl" style="font-size: 11px; color: var(--kb-primary); font-weight: 700;">Include Address</span>
                </label>
              </div>
              <input type="text" id="kb-wa-address-input" class="kb-wa-input" placeholder="e.g. 123 Business Avenue, Suite 400, New York, NY 10001 / Commercial Area, Lahore" value="123 Business Avenue, Suite 400, New York, NY 10001" />
              <div style="font-size: 10px; color: var(--kb-muted); margin-top: 4px;">
                Jab toggle ON hoga, to WhatsApp message ke aakhir mein yeh address automatic attach ho jayega.
              </div>
            </div>

            <!-- Media & Document Attachment Section (User Requested) -->
            <div class="kb-wa-attachment-section" style="margin-top: 12px; padding-top: 12px; border-top: 1px dashed var(--kb-border);">
              <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                <label class="kb-wa-label" style="margin: 0; font-weight: 700; color: #f1f5f9;">📎 Media / Document Attachment:</label>
                <button type="button" id="kb-wa-btn-browse-file" class="kb-wa-btn-sm" style="background: rgba(56, 189, 248, 0.15); border: 1px solid rgba(56, 189, 248, 0.4); color: #38bdf8; font-size: 11px;">
                  + Add File
                </button>
                <input type="file" id="kb-wa-file-attachment" accept="image/*,video/*,.pdf,.doc,.docx,.xlsx,.txt" style="display:none;" />
              </div>

              <!-- Selected Attachment Preview Pill -->
              <div id="kb-wa-attach-pill" style="display: none; align-items: center; justify-content: space-between; background: #070d17; border: 1px solid #1e2e46; border-radius: 8px; padding: 7px 12px; margin-top: 6px;">
                <div style="display: flex; align-items: center; gap: 8px; overflow: hidden;">
                  <span id="kb-wa-attach-icon" style="font-size: 16px;">📎</span>
                  <div style="overflow: hidden;">
                    <div id="kb-wa-attach-name" style="font-size: 11.5px; font-weight: 700; color: #f8fafc; white-space: nowrap; text-overflow: ellipsis; overflow: hidden; max-width: 250px;">file_name.pdf</div>
                    <div id="kb-wa-attach-size" style="font-size: 10px; color: var(--kb-muted);">0 KB</div>
                  </div>
                </div>
                <button type="button" id="kb-wa-btn-remove-file" style="background: none; border: none; color: #ef4444; font-size: 14px; font-weight: 800; cursor: pointer; padding: 2px 6px;" title="Remove Attachment">✕</button>
              </div>

              <div id="kb-wa-attach-empty-note" style="font-size: 10px; color: var(--kb-muted); margin-top: 4px;">
                Optional: Attach an image, PDF or catalog. Message text will be sent along with the file.
              </div>
            </div>
          </div>

          <!-- Step 3: Pacing & Anti-Ban Delivery Card -->
          <div class="kb-wa-card">
            <div class="kb-wa-card-header">
              <div class="kb-wa-card-title">
                <span>3. Pacing & Anti-Ban Delivery</span>
              </div>
              <label class="kb-wa-toggle-wrap">
                <label class="kb-checkbox-wrap" title="Smart Dynamic Pacing">
                  <input type="checkbox" id="kb-smart-timer-chk" checked />
                  <span class="kb-checkbox-box">
                    <svg class="kb-check-icon" viewBox="0 0 12 10" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="1.5 5 4.5 8 10.5 2"></polyline></svg>
                  </span>
                </label>
                <span style="font-size:11.5px; color:var(--kb-primary); font-weight:700;">🎲 Smart Dynamic</span>
              </label>
            </div>

            <!-- Range Inputs: Always Visible so user chooses where random delay starts and ends (Picture 3) -->
            <div id="kb-manual-timer-inputs" style="display:flex; gap:10px; margin-bottom:10px;">
              <div style="flex:1;">
                <label class="kb-wa-label">Min Delay (s)</label>
                <input type="number" id="kb-delay-min" class="kb-wa-input" value="15" min="5" max="300" />
              </div>
              <div style="flex:1;">
                <label class="kb-wa-label">Max Delay (s)</label>
                <input type="number" id="kb-delay-max" class="kb-wa-input" value="45" min="8" max="600" />
              </div>
            </div>

            <!-- Live Dynamic Delay Explanation -->
            <div id="kb-smart-timer-info" class="kb-wa-info-pill">
               <b>Smart Dynamic Active:</b> Emulates authentic human typing with random delay intervals between <b>15s</b> and <b>45s</b>.
            </div>

            <div style="margin-top: 10px;">
              <label class="kb-wa-label">Default Country Code (if missing from numbers)</label>
              <input type="text" id="kb-default-cc" class="kb-wa-input" value="92" placeholder="e.g. 92, 1, 44" />
            </div>

            <!-- Smart Daily Queue & Scheduler Box -->
            <div class="kb-wa-queue-box">
              <div class="kb-wa-queue-header">
                <div style="display:flex; align-items:center; gap:6px;">
                  <span>📅</span>
                  <span style="font-weight:700; color:#f8fafc;">Daily Queue & Auto-Scheduler</span>
                </div>
                <label class="kb-wa-toggle-wrap">
                  <label class="kb-checkbox-wrap" title="Auto-Schedule Daily Limit">
                    <input type="checkbox" id="kb-wa-schedule-chk" />
                    <span class="kb-checkbox-box">
                      <svg class="kb-check-icon" viewBox="0 0 12 10" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="1.5 5 4.5 8 10.5 2"></polyline></svg>
                    </span>
                  </label>
                  <span id="kb-wa-schedule-lbl" style="font-size:11px; color:var(--kb-primary); font-weight:700;">Auto-Schedule</span>
                </label>
              </div>

              <div style="display:flex; gap:10px; margin-top:8px;">
                <div style="flex:1;">
                  <label class="kb-wa-label">Daily Send Limit (per day)</label>
                  <input type="number" id="kb-daily-cap" class="kb-wa-input" value="50" min="1" max="1000" />
                </div>
                <div style="flex:1;">
                  <label class="kb-wa-label">Schedule Time (Daily)</label>
                  <input type="time" id="kb-wa-schedule-time" class="kb-wa-input" value="10:00" />
                </div>
              </div>

              <div class="kb-wa-queue-status-bar" id="kb-wa-queue-status">
                <div>
                  <span style="color:#94a3b8;">Pending in Queue:</span> <b style="color:#38bdf8;" id="kb-queue-pending-count">0</b>
                  <span style="margin: 0 6px; color:#334155;">|</span>
                  <span style="color:#94a3b8;">Today:</span> <b style="color:#10b981;" id="kb-queue-today-count">0 / 50</b>
                </div>
                <button type="button" id="kb-btn-clear-queue" class="kb-wa-mem-btn kb-wa-mem-btn-danger" style="font-size:10px; padding:2px 6px;" title="Clear pending queue">Clear Queue</button>
              </div>
            </div>
          </div>

          <!-- Live Countdown Box (ONLY visible during active delay between sends) -->
          <div id="kb-wa-countdown-box" class="kb-wa-countdown-box">
            <div class="kb-wa-cd-header">
              <span style="display:flex; align-items:center; gap:6px;">
                <span style="display:inline-block; width:8px; height:8px; border-radius:50%; background:#10b981;"></span>
                <span>Next Message Countdown:</span>
              </span>
              <span id="kb-wa-cd-seconds" class="kb-wa-cd-time">--s</span>
            </div>
            <div class="kb-wa-cd-controls">
              <span style="font-size:11px; color:var(--kb-muted);">Edit live:</span>
              <input type="number" id="kb-wa-cd-input" class="kb-wa-cd-input" min="0" max="600" title="Change seconds directly without stopping campaign" />
              <button type="button" id="kb-wa-cd-btn-sub5" class="kb-wa-cd-btn" title="Decrease remaining delay by 5 seconds">-5s</button>
              <button type="button" id="kb-wa-cd-btn-add10" class="kb-wa-cd-btn" title="Increase remaining delay by 10 seconds">+10s</button>
              <button type="button" id="kb-wa-cd-btn-skip" class="kb-wa-cd-btn kb-wa-cd-btn-skip" title="Send Next Message Right Now">⏩ Send Now</button>
            </div>
          </div>

          <!-- Step 4: Campaign Monitor & Progress Card -->
          <div class="kb-wa-card">
            <div class="kb-wa-card-header">
              <div class="kb-wa-card-title">
                <span>4. Live Campaign Monitor</span>
              </div>
              <span id="kb-wa-status-badge" style="font-size:10.5px; color:var(--kb-muted); font-weight:700;">IDLE</span>
            </div>

            <div class="kb-wa-stats-grid">
              <div class="kb-wa-stat-card">
                <div class="kb-wa-stat-val" style="color:#f8fafc;" id="kb-stat-total">0</div>
                <div class="kb-wa-stat-lbl">Recipients</div>
              </div>
              <div class="kb-wa-stat-card">
                <div class="kb-wa-stat-val" style="color:#10b981;" id="kb-stat-sent">0</div>
                <div class="kb-wa-stat-lbl">Sent</div>
              </div>
              <div class="kb-wa-stat-card">
                <div class="kb-wa-stat-val" style="color:#ef4444;" id="kb-stat-failed">0</div>
                <div class="kb-wa-stat-lbl">Failed</div>
              </div>
              <div class="kb-wa-stat-card">
                <div class="kb-wa-stat-val" style="color:#38bdf8;" id="kb-stat-remaining">0</div>
                <div class="kb-wa-stat-lbl">Remaining</div>
              </div>
            </div>

            <div class="kb-wa-progress-track">
              <div class="kb-wa-progress-bar" id="kb-progress-bar" style="width: 0%;"></div>
            </div>

            <div class="kb-wa-log" id="kb-log-box">
              <div class="kb-wa-log-entry" style="color:var(--kb-muted);">[Ready] Standalone WhatsApp Bot initialized.</div>
            </div>
          </div>
        </div>

        <!-- Panel Fixed Footer -->
        <div class="kb-wa-footer">
          <button type="button" id="kb-btn-start" class="kb-wa-btn-primary">
            <span>🚀 Start WhatsApp Campaign</span>
          </button>
          
          <div id="kb-btn-actions" style="display:none; gap:8px; width:100%;">
            <button type="button" id="kb-btn-pause" class="kb-wa-btn-secondary" style="flex:1;">⏸ Pause</button>
            <button type="button" id="kb-btn-stop" class="kb-wa-btn-danger" style="flex:1;">🛑 Stop</button>
          </div>

          <button type="button" id="kb-btn-export" class="kb-wa-btn-secondary">
              <span>📥 Download Results Report (CSV)</span>
            </button>
            <button type="button" id="kb-btn-export-followup" class="kb-wa-btn-secondary" style="margin-top: 6px; background: rgba(239, 68, 68, 0.15); border: 1px solid rgba(239, 68, 68, 0.4); color: #fca5a5;" title="Export only the failed/unregistered WhatsApp leads preserving all original spreadsheet columns for subsequent follow-up">
              <span>📥 Export Followup Sheet (Failed Contacts)</span>
            </button>
        </div>

        <!-- Memory Viewer Modal -->
        <div id="kb-wa-mem-modal" class="kb-wa-modal-overlay" style="display:none;">
          <div class="kb-wa-modal-card" style="max-width: 440px;">
            <div class="kb-wa-modal-title" style="color:#10b981; display:flex; justify-content:space-between; align-items:center;">
              <span>🧠 Smart Memory Vault</span>
              <span style="font-size:11px; color:var(--kb-muted); font-weight:normal;">100% Offline Local Storage</span>
            </div>
            <div style="font-size:11.5px; color:var(--kb-muted); margin-bottom:10px;">
              These leads were contacted in previous campaigns and will be shielded from unwanted repeat messages.
            </div>
            <div id="kb-wa-mem-list" style="max-height:220px; overflow-y:auto; background:var(--kb-surface); border:1px solid var(--kb-border); border-radius:8px; padding:6px; margin-bottom:12px;">
              <!-- Dynamic Rows -->
            </div>
            <div style="display:flex; gap:8px;">
              <button type="button" id="kb-wa-close-mem-modal" class="kb-wa-modal-btn kb-wa-modal-btn-sec">Close Vault</button>
            </div>
          </div>
        </div>

        <!-- Pre-Campaign Duplicate & Smart Memory Shield Modal -->
        <div id="kb-wa-dup-modal" class="kb-wa-modal-overlay" style="display:none;">
          <div class="kb-wa-modal-card">
            <div class="kb-wa-modal-title">
              <span>⚠️ Duplicate Numbers Detected</span>
            </div>
            <div id="kb-wa-dup-desc" class="kb-wa-modal-desc">
              Found duplicate contacts in your list. Would you like to filter them out and send once per number, or send to all?
            </div>
            <div class="kb-wa-modal-actions">
              <button type="button" id="kb-wa-dup-skip" class="kb-wa-modal-btn kb-wa-modal-btn-primary">
                🛡️ Skip Duplicates (Send Once Only - Recommended)
              </button>
              <button type="button" id="kb-wa-dup-sendall" class="kb-wa-modal-btn kb-wa-modal-btn-sec">
                🔁 Send to All (Include Duplicates)
              </button>
              <button type="button" id="kb-wa-dup-cancel" class="kb-wa-modal-btn kb-wa-modal-btn-cancel">
                ✕ Cancel / Review List
              </button>
            </div>
          </div>
        </div>
      `;

      document.body.appendChild(panel);
      bindEvents();
      loadSavedSettings();
    }
  }

  function toggleDrawer() {
    const panel = document.getElementById("kb-wa-panel");
    if (!panel) return;
    panel.classList.toggle("kb-wa-hidden");
  }

  function logMsg(text, color = null) {
    const box = document.getElementById("kb-log-box");
    if (!box) return;
    const entry = document.createElement("div");
    entry.className = "kb-wa-log-entry";
    if (color) entry.style.color = color;
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    entry.textContent = `[${time}] ${text}`;
    box.appendChild(entry);
    box.scrollTop = box.scrollHeight;
  }

  // --- SAVE & RESTORE SETTINGS ---
  function saveSettings(showIndicator = true) {
    const template = document.getElementById("kb-msg-template")?.value || "";
    const smartTimer = document.getElementById("kb-smart-timer-chk")?.checked ?? true;
    const minDelay = parseInt(document.getElementById("kb-delay-min")?.value) || 15;
    const maxDelay = parseInt(document.getElementById("kb-delay-max")?.value) || 45;
    const defaultCc = document.getElementById("kb-default-cc")?.value || "92";
    const address = document.getElementById("kb-wa-address-input")?.value || "";
    const includeAddress = document.getElementById("kb-wa-include-address-chk")?.checked ?? true;

    state.settings.smartTimer = smartTimer;
    state.settings.minDelay = minDelay;
    state.settings.maxDelay = maxDelay;
    state.settings.defaultCc = defaultCc;
    state.settings.address = address;
    state.settings.includeAddress = includeAddress;

    const dataToSave = {
      kb_wa_template: template,
      kb_wa_smart_timer: smartTimer,
      kb_wa_min_delay: minDelay,
      kb_wa_max_delay: maxDelay,
      kb_wa_default_cc: defaultCc,
      kb_wa_address: address,
      kb_wa_include_address: includeAddress
    };

    storage.set(dataToSave, () => {
      if (showIndicator) {
        const ind = document.getElementById("kb-save-indicator");
        if (ind) {
          ind.style.opacity = "1";
          setTimeout(() => { ind.style.opacity = "0"; }, 2000);
        }
      }
    });
  }

  function loadSavedSettings() {
    storage.get([
      "kb_wa_template",
      "kb_wa_smart_timer",
      "kb_wa_min_delay",
      "kb_wa_max_delay",
      "kb_wa_default_cc",
      "kb_wa_address",
      "kb_wa_include_address"
    ], (res) => {
      if (!res) return;

      const tplInput = document.getElementById("kb-msg-template");
      if (tplInput && res.kb_wa_template) {
        tplInput.value = res.kb_wa_template;
      } else if (tplInput && !tplInput.value) {
        tplInput.value = "Hello {name}!\n\nI noticed your business is expanding and wanted to reach out regarding our automated solutions.\n\nWould you have 5 minutes for a quick chat this week?\n\nBest regards,\nKimberbyte Outreach";
      }

      const smartChk = document.getElementById("kb-smart-timer-chk");
      if (smartChk && typeof res.kb_wa_smart_timer !== "undefined") {
        smartChk.checked = res.kb_wa_smart_timer;
        state.settings.smartTimer = res.kb_wa_smart_timer;
      }

      const minInput = document.getElementById("kb-delay-min");
      if (minInput && res.kb_wa_min_delay) {
        minInput.value = res.kb_wa_min_delay;
        state.settings.minDelay = parseInt(res.kb_wa_min_delay);
      }

      const maxInput = document.getElementById("kb-delay-max");
      if (maxInput && res.kb_wa_max_delay) {
        maxInput.value = res.kb_wa_max_delay;
        state.settings.maxDelay = parseInt(res.kb_wa_max_delay);
      }

      const ccInput = document.getElementById("kb-default-cc");
      if (ccInput && res.kb_wa_default_cc) {
        ccInput.value = res.kb_wa_default_cc;
        state.settings.defaultCc = res.kb_wa_default_cc;
      }

      const addrInput = document.getElementById("kb-wa-address-input");
      if (addrInput && typeof res.kb_wa_address !== "undefined") {
        addrInput.value = res.kb_wa_address;
        state.settings.address = res.kb_wa_address;
      }

      const addrChk = document.getElementById("kb-wa-include-address-chk");
      const addrLbl = document.getElementById("kb-wa-address-toggle-lbl");
      if (addrChk && typeof res.kb_wa_include_address !== "undefined") {
        addrChk.checked = res.kb_wa_include_address;
        state.settings.includeAddress = res.kb_wa_include_address;
        if (addrLbl) {
          addrLbl.textContent = addrChk.checked ? "Include Address" : "Omit Address";
          addrLbl.style.color = addrChk.checked ? "var(--kb-primary)" : "var(--kb-muted)";
        }
      }

      toggleSmartTimerUI(state.settings.smartTimer);
    });
  }

  function toggleSmartTimerUI(isSmart) {
    const infoBox = document.getElementById("kb-smart-timer-info");
    const min = parseInt(document.getElementById("kb-delay-min")?.value) || 15;
    const max = parseInt(document.getElementById("kb-delay-max")?.value) || 45;
    if (infoBox) {
      if (isSmart) {
        infoBox.innerHTML = ` <b>Smart Dynamic Active:</b> Emulates authentic human typing with random delay intervals between <b>${min}s</b> and <b>${max}s</b>.`;
        infoBox.style.color = "var(--kb-muted)";
      } else {
        infoBox.innerHTML = `⏱️ <b>Fixed Delay Active:</b> Messages will send with steady delay of <b>${min}s</b>.`;
        infoBox.style.color = "var(--kb-blue)";
      }
    }
  }

  // Calculate next delay: random interval between user's min and max with natural variance
  function getNextDelay() {
    const min = Math.max(5, state.settings.minDelay || 15);
    const max = Math.max(min, state.settings.maxDelay || 45);
    if (state.settings.smartTimer) {
      const base = Math.floor(Math.random() * (max - min + 1)) + min;
      const microJitter = Math.floor(Math.random() * 5) - 2;
      return Math.max(min, Math.min(max, base + microJitter));
    } else {
      return min;
    }
  }

  // --- EVENT BINDINGS ---
  function bindEvents() {
    // Close Drawer
    const btnClose = document.getElementById("kb-wa-btn-close");
    if (btnClose) btnClose.addEventListener("click", toggleDrawer);

    const btnWaAudit = document.getElementById("kb-btn-wa-audit");
    if (btnWaAudit) {
      btnWaAudit.addEventListener("click", () => {
        if (window.DailyAuditSystem) window.DailyAuditSystem.openModal("wa");
      });
    }

    // Tab Navigation
    document.querySelectorAll(".kb-wa-tab-btn").forEach(btn => {
      btn.addEventListener("click", (e) => {
        document.querySelectorAll(".kb-wa-tab-btn").forEach(b => b.classList.remove("kb-wa-active"));
        document.querySelectorAll(".kb-wa-tab-content").forEach(c => c.style.display = "none");

        btn.classList.add("kb-wa-active");
        const tab = btn.dataset.tab;
        state.activeTab = tab;
        const target = document.getElementById(`kb-tab-${tab}`);
        if (target) target.style.display = "block";
      });
    });

    // File Drag & Drop
    const dropzone = document.getElementById("kb-dropzone");
    const fileInput = document.getElementById("kb-file-input");
    if (dropzone && fileInput) {
      dropzone.addEventListener("click", () => fileInput.click());
      fileInput.addEventListener("change", handleFileSelect);

      dropzone.addEventListener("dragover", (e) => {
        e.preventDefault();
        dropzone.style.borderColor = "var(--kb-primary)";
      });
      dropzone.addEventListener("dragleave", (e) => {
        e.preventDefault();
        dropzone.style.borderColor = "var(--kb-border)";
      });
      dropzone.addEventListener("drop", (e) => {
        e.preventDefault();
        dropzone.style.borderColor = "var(--kb-border)";
        if (e.dataTransfer.files.length) {
          fileInput.files = e.dataTransfer.files;
          handleFileSelect({ target: fileInput });
        }
      });
    }

    // Column Selectors
    const phoneCol = document.getElementById("kb-phone-col");
    const nameCol = document.getElementById("kb-name-col");
    if (phoneCol) phoneCol.addEventListener("change", updateContactsFromSheet);
    if (nameCol) nameCol.addEventListener("change", updateContactsFromSheet);

    // Quick Paste Count & Parse
    const pasteInput = document.getElementById("kb-paste-input");
    const btnParsePaste = document.getElementById("kb-btn-parse-paste");
    if (pasteInput) {
      pasteInput.addEventListener("input", () => {
        const lines = pasteInput.value.trim().split("\n").filter(l => l.trim().length > 0);
        document.getElementById("kb-paste-count").textContent = `${lines.length} lines detected`;
      });
    }
    if (btnParsePaste) {
      btnParsePaste.addEventListener("click", () => {
        updateContactsFromPaste();
        alert(`Parsed ${state.contacts.length} valid contacts from text!`);
      });
    }

    // Tag Insertion
    document.querySelectorAll(".kb-wa-tag").forEach(tag => {
      tag.addEventListener("click", () => {
        const tpl = document.getElementById("kb-msg-template");
        if (!tpl) return;
        const insertText = tag.dataset.tag;
        const start = tpl.selectionStart;
        const end = tpl.selectionEnd;
        tpl.value = tpl.value.substring(0, start) + insertText + tpl.value.substring(end);
        tpl.focus();
        tpl.selectionStart = tpl.selectionEnd = start + insertText.length;
        saveSettings(false);
      });
    });

    // Save Settings Button & Auto-Save
    const btnSave = document.getElementById("kb-btn-save-settings");
    if (btnSave) {
      btnSave.addEventListener("click", () => saveSettings(true));
    }
    const tplArea = document.getElementById("kb-msg-template");
    if (tplArea) {
      tplArea.addEventListener("blur", () => saveSettings(false));
    }

    // Smart Timer Checkbox Toggle
    const smartChk = document.getElementById("kb-smart-timer-chk");
    if (smartChk) {
      smartChk.addEventListener("change", () => {
        state.settings.smartTimer = smartChk.checked;
        toggleSmartTimerUI(smartChk.checked);
        saveSettings(false);
      });
    }

    // Delay inputs change with live explanation update
    const minInput = document.getElementById("kb-delay-min");
    const maxInput = document.getElementById("kb-delay-max");
    const ccInput = document.getElementById("kb-default-cc");
    if (minInput) {
      minInput.addEventListener("input", () => {
        state.settings.minDelay = parseInt(minInput.value) || 15;
        toggleSmartTimerUI(state.settings.smartTimer);
        saveSettings(false);
      });
    }
    if (maxInput) {
      maxInput.addEventListener("input", () => {
        state.settings.maxDelay = parseInt(maxInput.value) || 45;
        toggleSmartTimerUI(state.settings.smartTimer);
        saveSettings(false);
      });
    }
    if (ccInput) ccInput.addEventListener("change", () => saveSettings(false));

    // Address input and toggle bindings
    const addrInput = document.getElementById("kb-wa-address-input");
    const addrChk = document.getElementById("kb-wa-include-address-chk");
    if (addrInput) {
      addrInput.addEventListener("input", () => {
        state.settings.address = addrInput.value;
        saveSettings(false);
      });
    }
    if (addrChk) {
      addrChk.addEventListener("change", () => {
        state.settings.includeAddress = addrChk.checked;
        const lbl = document.getElementById("kb-wa-address-toggle-lbl");
        if (lbl) {
          lbl.textContent = addrChk.checked ? "Include Address" : "Omit Address";
          lbl.style.color = addrChk.checked ? "var(--kb-primary)" : "var(--kb-muted)";
        }
        saveSettings(false);
      });
    }

    // Attachment File Upload & Remove Handlers
    const btnBrowseFile = document.getElementById("kb-wa-btn-browse-file");
    const fileAttachInput = document.getElementById("kb-wa-file-attachment");
    const attachPill = document.getElementById("kb-wa-attach-pill");
    const attachName = document.getElementById("kb-wa-attach-name");
    const attachSize = document.getElementById("kb-wa-attach-size");
    const attachIcon = document.getElementById("kb-wa-attach-icon");
    const btnRemoveFile = document.getElementById("kb-wa-btn-remove-file");
    const emptyNote = document.getElementById("kb-wa-attach-empty-note");

    if (btnBrowseFile && fileAttachInput) {
      btnBrowseFile.addEventListener("click", () => fileAttachInput.click());
      fileAttachInput.addEventListener("change", (e) => {
        const file = e.target.files && e.target.files[0];
        if (file) {
          state.attachment = {
            file: file,
            name: file.name,
            size: (file.size / 1024).toFixed(1) + " KB",
            type: file.type
          };
          if (attachName) attachName.textContent = file.name;
          if (attachSize) attachSize.textContent = state.attachment.size;
          if (attachIcon) {
            if (file.type.startsWith("image/")) attachIcon.textContent = "🖼️";
            else if (file.type.includes("pdf")) attachIcon.textContent = "📄";
            else if (file.type.startsWith("video/")) attachIcon.textContent = "🎬";
            else attachIcon.textContent = "📎";
          }
          if (attachPill) attachPill.style.display = "flex";
          if (emptyNote) emptyNote.textContent = "✅ Attachment ready. Will be dispatched with message.";
          btnBrowseFile.textContent = "Change File";
          logMsg(`📎 File attached: ${file.name} (${state.attachment.size})`, "#38bdf8");
        }
      });
    }

    if (btnRemoveFile) {
      btnRemoveFile.addEventListener("click", () => {
        state.attachment = null;
        if (fileAttachInput) fileAttachInput.value = "";
        if (attachPill) attachPill.style.display = "none";
        if (emptyNote) emptyNote.textContent = "Optional: Attach an image, PDF or catalog. Message text will be sent along with the file.";
        if (btnBrowseFile) btnBrowseFile.textContent = "+ Add File";
        logMsg("Attachment removed.", "#f59e0b");
      });
    }

    // Live Countdown Inline Controls
    const cdInput = document.getElementById("kb-wa-cd-input");
    if (cdInput) {
      cdInput.addEventListener("change", () => {
        const val = parseInt(cdInput.value);
        if (!isNaN(val) && val >= 0) {
          state.campaign.activeCountdownRemaining = val;
          const cdSecondsEl = document.getElementById("kb-wa-cd-seconds");
          if (cdSecondsEl) cdSecondsEl.textContent = `${val}s`;
          logMsg(`⏱️ Countdown delay manually set to ${val}s.`, "#38bdf8");
        }
      });
    }

    const btnSub5 = document.getElementById("kb-wa-cd-btn-sub5");
    if (btnSub5) {
      btnSub5.addEventListener("click", () => {
        state.campaign.activeCountdownRemaining = Math.max(0, state.campaign.activeCountdownRemaining - 5);
        const cdSecondsEl = document.getElementById("kb-wa-cd-seconds");
        if (cdSecondsEl) cdSecondsEl.textContent = `${state.campaign.activeCountdownRemaining}s`;
        if (cdInput) cdInput.value = state.campaign.activeCountdownRemaining;
      });
    }

    const btnAdd10 = document.getElementById("kb-wa-cd-btn-add10");
    if (btnAdd10) {
      btnAdd10.addEventListener("click", () => {
        state.campaign.activeCountdownRemaining += 10;
        const cdSecondsEl = document.getElementById("kb-wa-cd-seconds");
        if (cdSecondsEl) cdSecondsEl.textContent = `${state.campaign.activeCountdownRemaining}s`;
        if (cdInput) cdInput.value = state.campaign.activeCountdownRemaining;
      });
    }

    const btnSkip = document.getElementById("kb-wa-cd-btn-skip");
    if (btnSkip) {
      btnSkip.addEventListener("click", () => {
        state.campaign.activeCountdownRemaining = 0;
        const cdSecondsEl = document.getElementById("kb-wa-cd-seconds");
        if (cdSecondsEl) cdSecondsEl.textContent = "0s";
        logMsg("⏩ Delay skipped. Sending next message immediately!", "#38bdf8");
      });
    }

    // Direct Chat Send
    const btnDirect = document.getElementById("kb-btn-direct-send");
    if (btnDirect) {
      btnDirect.addEventListener("click", async () => {
        const phoneInput = document.getElementById("kb-direct-phone").value.trim();
        const msg = document.getElementById("kb-direct-msg").value.trim();
        const cc = document.getElementById("kb-default-cc").value.trim() || '92';

        if (!phoneInput) return alert("Please enter a target phone number!");
        if (!msg) return alert("Please type a message!");

        const clean = cleanPhoneNumber(phoneInput, cc);
        btnDirect.disabled = true;
        btnDirect.textContent = "⏳ Opening WhatsApp Chat...";
        logMsg(`Opening direct chat with +${clean}...`);

        let finalDirect = msg;
        const addr = (state.settings.address || "").trim();
        const shouldAttach = state.settings.includeAddress ?? true;
        if (finalDirect.includes("{address}")) {
          finalDirect = finalDirect.replace(/\{address\}/gi, addr);
        } else if (shouldAttach && addr) {
          finalDirect += `\n\n📍 Office Address:\n${addr}`;
        }

        const success = await dispatchMessage(clean, finalDirect, { phone: clean });
        btnDirect.disabled = false;
        btnDirect.textContent = "🚀 Open Chat & Send";

        if (success) {
          logMsg(`Direct message sent to +${clean}!`, "#10b981");
          alert("Message dispatched successfully!");
        } else {
          logMsg(`Failed to send to +${clean} (Number may be invalid or not on WhatsApp).`, "#ef4444");
          alert("Could not send message. Please verify the phone number.");
        }
      });
    }

    // Start Campaign Button
    const btnStart = document.getElementById("kb-btn-start");
    if (btnStart) btnStart.addEventListener("click", startCampaign);

    // Pause / Resume
    const btnPause = document.getElementById("kb-btn-pause");
    if (btnPause) {
      btnPause.addEventListener("click", () => {
        if (!state.campaign.isRunning) return;
        state.campaign.isPaused = !state.campaign.isPaused;
        btnPause.textContent = state.campaign.isPaused ? "▶ Resume" : "⏸ Pause";
        logMsg(state.campaign.isPaused ? "Campaign PAUSED." : "Campaign RESUMED.", "#f59e0b");
      });
    }

    // Stop Campaign
    const btnStop = document.getElementById("kb-btn-stop");
    if (btnStop) {
      btnStop.addEventListener("click", () => {
        if (confirm("Are you sure you want to stop the campaign?")) {
          state.campaign.isRunning = false;
          state.campaign.isPaused = false;
          resetControls();
          logMsg("Campaign STOPPED by user.", "#ef4444");
        }
      });
    }

    // Export CSV
    const btnExport = document.getElementById("kb-btn-export");
    if (btnExport) btnExport.addEventListener("click", exportResultsCSV);
    const btnExpFollow = document.getElementById("kb-btn-export-followup");
    if (btnExpFollow) btnExpFollow.addEventListener("click", exportFollowupSheet);

    // Smart Memory Actions
    const btnViewMem = document.getElementById("kb-wa-btn-view-mem");
    const btnExportMem = document.getElementById("kb-wa-btn-export-mem");
    const btnClearMem = document.getElementById("kb-wa-btn-clear-mem");
    const memModal = document.getElementById("kb-wa-mem-modal");
    const memCloseBtn = document.getElementById("kb-wa-close-mem-modal");

    if (btnViewMem && memModal) {
      btnViewMem.addEventListener("click", () => {
        SmartMemory.get((mem) => {
          const listEl = document.getElementById("kb-wa-mem-list");
          if (!listEl) return;
          const numbers = mem.numbers || {};
          const keys = Object.keys(numbers);
          if (keys.length === 0) {
            listEl.innerHTML = '<div style="padding:12px; text-align:center; color:var(--kb-muted);">No contacts stored in memory yet. Run a campaign to start remembering leads.</div>';
          } else {
            let html = '';
            keys.slice(-50).reverse().forEach(k => {
              const item = numbers[k];
              html += `<div class="kb-mem-item">
                <div>
                  <b style="color:var(--kb-text);">+${k}</b>
                  <span style="color:var(--kb-muted); margin-left:6px;">${item.name || 'Client'}</span>
                </div>
                <div style="font-size:10px; color:#10b981;">
                  Sent (${item.count || 1}x) • ${item.lastSent ? item.lastSent.split(',')[0] : ''}
                </div>
              </div>`;
            });
            listEl.innerHTML = html;
          }
          memModal.classList.add("kb-show");
          memModal.style.display = "flex";
        });
      });
    }

    if (memCloseBtn && memModal) {
      memCloseBtn.addEventListener("click", () => {
        memModal.classList.remove("kb-show");
        memModal.style.display = "none";
      });
    }

    if (btnExportMem) btnExportMem.addEventListener("click", SmartMemory.exportCSV);
    if (btnClearMem) btnClearMem.addEventListener("click", SmartMemory.clear);

    // Initial badge update
    updateMemoryBadge();
  }

  // --- FILE HANDLING ---
  let rawSheetData = [];
  function handleFileSelect(e) {
    const file = e.target.files && e.target.files[0];
    if (!file) return;

    if (typeof XLSX === "undefined") {
      alert("SheetJS engine loading... please retry in a second.");
      return;
    }

    const reader = new FileReader();
    reader.onload = function (evt) {
      try {
        const data = new Uint8Array(evt.target.result);
        const workbook = XLSX.read(data, { type: 'array' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        const json = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

        if (!json || json.length < 2) {
          alert("The file seems empty or lacks data rows!");
          return;
        }

        const headers = json[0];
        rawSheetData = json.slice(1);

        const phoneSelect = document.getElementById("kb-phone-col");
        const nameSelect = document.getElementById("kb-name-col");
        phoneSelect.innerHTML = "";
        nameSelect.innerHTML = "";

        headers.forEach((h, idx) => {
          const opt1 = document.createElement("option");
          opt1.value = idx;
          opt1.textContent = h || `Column ${idx + 1}`;
          phoneSelect.appendChild(opt1);

          const opt2 = document.createElement("option");
          opt2.value = idx;
          opt2.textContent = h || `Column ${idx + 1}`;
          nameSelect.appendChild(opt2);
        });

        // Auto select best guesses
        headers.forEach((h, idx) => {
          const lower = String(h).toLowerCase();
          if (lower.includes("phone") || lower.includes("mobile") || lower.includes("num") || lower.includes("contact") || lower.includes("whatsapp")) {
            phoneSelect.value = idx;
          }
          if (lower.includes("name") || lower.includes("first") || lower.includes("client") || lower.includes("lead")) {
            nameSelect.value = idx;
          }
        });

        document.getElementById("kb-sheet-meta").style.display = "block";
        updateContactsFromSheet();
        logMsg(`Loaded spreadsheet with ${rawSheetData.length} records.`, "#10b981");
      } catch (err) {
        alert("Failed to parse sheet: " + err.message);
      }
    };
    reader.readAsArrayBuffer(file);
  }

  function updateValidationBanner(valid, invalid) {
    const banner = document.getElementById("kb-wa-validation-banner");
    const okEl = document.getElementById("kb-wa-val-ok");
    const errEl = document.getElementById("kb-wa-val-err");
    if (!banner || !okEl || !errEl) return;

    if (valid > 0 || invalid > 0) {
      banner.style.display = "flex";
      okEl.textContent = ` ${valid} Valid Format`;
      errEl.textContent = `⚠️ ${invalid} Filtered`;
      if (invalid > 0) {
        logMsg(`🛡️ Phone Validator: Automatically filtered ${invalid} invalid / malformed numbers. ${valid} valid numbers ready.`, "#f59e0b");
      }
    } else {
      banner.style.display = "none";
    }
  }

  function updateContactsFromSheet() {
    if (!rawSheetData || rawSheetData.length === 0) return;
    const phoneColIdx = parseInt(document.getElementById("kb-phone-col").value);
    const nameColIdx = parseInt(document.getElementById("kb-name-col").value);
    const cc = document.getElementById("kb-default-cc").value.trim() || '92';

    const list = [];
    let validCount = 0;
    let invalidCount = 0;

    rawSheetData.forEach(row => {
      const rawPhone = row[phoneColIdx];
      const rawName = row[nameColIdx] || 'Client';
      const val = validateAndCleanPhone(rawPhone, cc);
      if (val.isValid) {
        validCount++;
        list.push({ name: String(rawName).trim(), phone: val.phone, raw: rawPhone, isValid: true, rawRow: row, rowHeaders: headers });
      } else if (val.phone) {
        invalidCount++;
      }
    });

    state.contacts = list;
    document.getElementById("kb-file-summary").textContent = `Valid Contacts Loaded: ${list.length}`;
    updateStatsTotal(list.length);
    updateValidationBanner(validCount, invalidCount);
  }

  function updateContactsFromPaste() {
    const raw = document.getElementById("kb-paste-input").value;
    const cc = document.getElementById("kb-default-cc").value.trim() || '92';
    const lines = raw.split("\n");
    const list = [];
    let validCount = 0;
    let invalidCount = 0;

    lines.forEach(l => {
      const parts = l.split(/[,;\t]/);
      if (parts.length > 0 && parts[0].trim()) {
        const val = validateAndCleanPhone(parts[0], cc);
        const name = parts[1] ? parts[1].trim() : 'Client';
        if (val.isValid) {
          validCount++;
          list.push({ name, phone: val.phone, raw: parts[0], isValid: true });
        } else if (val.phone) {
          invalidCount++;
        }
      }
    });

    state.contacts = list;
    const countEl = document.getElementById("kb-paste-count");
    if (countEl) countEl.textContent = `${validCount} valid contacts detected`;
    updateStatsTotal(list.length);
    updateValidationBanner(validCount, invalidCount);
  }

  function updateContactsFromActiveTab() {
    if (state.activeTab === 'sheet') {
      updateContactsFromSheet();
    } else if (state.activeTab === 'paste') {
      updateContactsFromPaste();
    }
  }

  function updateStatsTotal(total) {
    const totalEl = document.getElementById("kb-stat-total");
    const remEl = document.getElementById("kb-stat-remaining");
    if (totalEl) totalEl.textContent = total;
    if (remEl) remEl.textContent = total;
  }

  // --- DISPATCH MESSAGE TO WHATSAPP DOM ---
  
  // --- REAL HUMAN KEYSTROKE TYPING SIMULATION (ANTI-BAN EVASION) ---
  async function simulateHumanKeyboardTyping(targetEl, text) {
    if (!targetEl || !text) return;
    try {
      targetEl.focus();
      document.execCommand("selectAll", false, null);
      document.execCommand("delete", false, null);
    } catch (e) {}

    for (let i = 0; i < text.length; i++) {
      const ch = text[i];
      if (ch === "\n") {
        try {
          targetEl.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", code: "Enter", keyCode: 13, which: 13, shiftKey: true, bubbles: true }));
          document.execCommand("insertLineBreak");
          targetEl.dispatchEvent(new KeyboardEvent("keyup", { key: "Enter", code: "Enter", keyCode: 13, which: 13, shiftKey: true, bubbles: true }));
        } catch (e) {}
        await new Promise(r => setTimeout(r, 100 + Math.random() * 80));
        continue;
      }

      const keyOpts = { key: ch, bubbles: true, cancelable: true };
      try { targetEl.dispatchEvent(new KeyboardEvent("keydown", keyOpts)); } catch (e) {}
      try {
        targetEl.dispatchEvent(new InputEvent("beforeinput", { bubbles: true, cancelable: true, inputType: "insertText", data: ch }));
      } catch (e) {}

      document.execCommand("insertText", false, ch);

      try {
        targetEl.dispatchEvent(new InputEvent("input", { bubbles: true, cancelable: true, inputType: "insertText", data: ch }));
      } catch (e) {}
      try { targetEl.dispatchEvent(new KeyboardEvent("keyup", keyOpts)); } catch (e) {}

      // Human keystroke micro-delay (35ms - 85ms) with thinking pauses on spaces & punctuation
      let delay = 35 + Math.floor(Math.random() * 50);
      if ([".", ",", "!", "?", ";", ":"].includes(ch)) {
        delay += 140 + Math.floor(Math.random() * 120);
      } else if (ch === " ") {
        delay += 40 + Math.floor(Math.random() * 50);
      }
      await new Promise(r => setTimeout(r, delay));
    }
  }

  function trackFailedContact(rawContact, phone, reason) {
    if (!state.campaign.rejectedContacts) {
      state.campaign.rejectedContacts = [];
    }
    let rowObj = {};
    if (rawContact && rawContact.rawRow && rawContact.rowHeaders) {
      rawContact.rowHeaders.forEach((h, idx) => {
        rowObj[h || `Col_${idx+1}`] = rawContact.rawRow[idx] !== undefined ? rawContact.rawRow[idx] : "";
      });
    } else if (rawContact && typeof rawContact === "object") {
      rowObj = { ...rawContact };
    } else {
      rowObj = { Phone: phone };
    }
    rowObj["Rejection Reason"] = reason;
    rowObj["Rejected At"] = new Date().toLocaleString();
    state.campaign.rejectedContacts.push(rowObj);
  }

  function exportFollowupSheet() {
    const rejected = state.campaign.rejectedContacts || [];
    if (rejected.length === 0) {
      alert("Zero failed contacts! All messages were delivered successfully without any rejections.");
      return;
    }

    if (typeof XLSX !== "undefined") {
      const ws = XLSX.utils.json_to_sheet(rejected);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "Followup_Leads");
      XLSX.writeFile(wb, `WhatsApp_Followup_Leads_${new Date().toISOString().slice(0, 10)}.xlsx`);
    } else {
      const headers = Object.keys(rejected[0]);
      let csv = "\uFEFF" + headers.join(",") + "\n";
      rejected.forEach(r => {
        const row = headers.map(h => `"${String(r[h] || "").replace(/"/g, '""')}"`);
        csv += row.join(",") + "\n";
      });
      const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.download = `WhatsApp_Followup_Leads_${new Date().toISOString().slice(0, 10)}.csv`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  }

  async function dispatchMessage(phone, messageText, rawContact = null) {
    return new Promise(async (resolve) => {
      try {
        // ANTI-BAN EVASION: Navigate ONLY to phone. Text is typed letter-by-letter via keyboard events.
        const url = `https://web.whatsapp.com/send?phone=${phone}`;

        let iframe = document.getElementById("kb-wa-worker-link");
        if (!iframe) {
          iframe = document.createElement("a");
          iframe.id = "kb-wa-worker-link";
          iframe.style.display = "none";
          document.body.appendChild(iframe);
        }

        iframe.href = url;
        iframe.click();

        let elapsed = 0;
        let attachmentInjected = false;
        let inputWokenUp = false;

        const interval = setInterval(() => {
          elapsed++;

          // 1. Check for "Phone number shared via url is invalid" popup
          const invalidPopup = document.querySelector('[data-testid="popup-contents"], [data-animate-modal-popup="true"]');
          if (invalidPopup && invalidPopup.innerText.toLowerCase().includes("phone number shared via url is invalid")) {
            const okBtn = invalidPopup.querySelector('button, [role="button"]');
            if (okBtn) okBtn.click();
            clearInterval(interval);
            resolve(false);
            return;
          }

          // 2. Locate Main Chat Input Box
          const mainInput = document.querySelector(
            'div[contenteditable="true"][data-tab="10"], div[contenteditable="true"][data-tab="6"], div[contenteditable="true"][role="textbox"], #main footer div[contenteditable="true"], div[data-testid="conversation-compose-box-input"]'
          );

          // 3. Genuine Human Keystroke Emulation (Letter-by-Letter via Keyboard)
          if (mainInput && !inputWokenUp && elapsed >= 2) {
            inputWokenUp = true;
            logMsg(`⌨️ Simulating human keyboard typing to +${phone}...`, "#38bdf8");
            try {
              await simulateHumanKeyboardTyping(mainInput, messageText);
              attachmentInjected = true; // typing complete
              logMsg(` Human typing complete for +${phone}. Dispatched via keyboard Enter.`, "#10b981");
            } catch (e) {
              console.error("Keyboard typing error:", e);
            }
          }

          // 4. Handle Attachment Injection if selected
          if (state.attachment && state.attachment.file && !attachmentInjected) {
            const fileInputs = document.querySelectorAll('input[type="file"]');
            let attachInput = null;
            for (const inp of fileInputs) {
              const accept = inp.getAttribute("accept") || "";
              if (accept.includes("image") || accept.includes("video") || accept.includes("*") || accept.includes("pdf")) {
                attachInput = inp;
                break;
              }
            }

            if (attachInput) {
              try {
                const dt = new DataTransfer();
                dt.items.add(state.attachment.file);
                attachInput.files = dt.files;
                attachInput.dispatchEvent(new Event("change", { bubbles: true }));
                attachmentInjected = true;
                logMsg(`📎 Attachment attached to message: ${state.attachment.name}`, "#38bdf8");
              } catch (e) {}
            } else {
              const clipBtn = document.querySelector('button[aria-label="Attach"], span[data-icon="plus"], span[data-icon="clip"], [data-testid="attach-menu-plus"]');
              if (clipBtn && elapsed >= 2 && elapsed <= 4) {
                clipBtn.click();
              }
            }
          }

          // 5. Look for Send Button with comprehensive multi-lingual & SVG selectors
          const sendBtn = document.querySelector(
            'button[data-testid="compose-btn-send"], button[aria-label="Send"], button[aria-label="بھیجیں"], button[aria-label*="Send"], span[data-icon="send"], [data-icon="wds-ic-send-filled"], button[data-tab="11"], footer button:has(span[data-icon="send"])'
          );

          if (sendBtn) {
            clearInterval(interval);
            setTimeout(() => {
              const clickTarget = sendBtn.closest("button") || sendBtn;
              clickTarget.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true }));
              clickTarget.dispatchEvent(new MouseEvent("mouseup", { bubbles: true, cancelable: true }));
              clickTarget.click();

              // Safety check: After 1.5s, if text is still in input box, fire Keyboard Enter fallback!
              setTimeout(() => {
                if (mainInput && (mainInput.innerText || "").trim().length > 0) {
                  mainInput.focus();
                  mainInput.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true }));
                  mainInput.dispatchEvent(new KeyboardEvent("keyup", { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true }));
                }
                resolve(true);
              }, 1500);
            }, 600);
            return;
          }

          // 6. KEYBOARD ENTER FALLBACK (If send button was missing/delayed after 5 seconds of active input)
          if (mainInput && elapsed >= 5 && (mainInput.innerText || "").trim().length > 0) {
            clearInterval(interval);
            mainInput.focus();
            const enterDown = new KeyboardEvent("keydown", {
              key: "Enter",
              code: "Enter",
              keyCode: 13,
              which: 13,
              bubbles: true,
              cancelable: true
            });
            const enterUp = new KeyboardEvent("keyup", {
              key: "Enter",
              code: "Enter",
              keyCode: 13,
              which: 13,
              bubbles: true,
              cancelable: true
            });
            mainInput.dispatchEvent(enterDown);
            mainInput.dispatchEvent(enterUp);

            logMsg(" Smart Enter key dispatched directly to chat box.", "#10b981");
            setTimeout(() => resolve(true), 2000);
            return;
          }

          // 7. Timeout after 40 seconds
          if (elapsed > 40) {
            clearInterval(interval);
            resolve(false);
          }
        }, 1000);
      } catch (e) {
        console.error(e);
        resolve(false);
      }
    });
  }

  // --- PRE-CAMPAIGN AI MEMORY & REPEAT DETECTION CONTROLLER ---
  function startCampaign() {
    updateContactsFromActiveTab();

    // Queue & Scheduler Listeners
    const chkSched = document.getElementById("kb-wa-schedule-chk");
    const timeSched = document.getElementById("kb-wa-schedule-time");
    const capSched = document.getElementById("kb-daily-cap");
    const btnClearQ = document.getElementById("kb-btn-clear-queue");

    if (chkSched) {
      chkSched.addEventListener("change", () => {
        QueueManager.getSettings((s) => {
          s.enabled = chkSched.checked;
          QueueManager.saveSettings(s, () => QueueManager.updateUI());
        });
      });
    }

    if (timeSched) {
      timeSched.addEventListener("change", () => {
        QueueManager.getSettings((s) => {
          s.scheduleTime = timeSched.value;
          QueueManager.saveSettings(s, () => QueueManager.updateUI());
        });
      });
    }

    if (capSched) {
      capSched.addEventListener("change", () => {
        QueueManager.getSettings((s) => {
          s.dailyCap = parseInt(capSched.value, 10) || 50;
          QueueManager.saveSettings(s, () => QueueManager.updateUI());
        });
      });
    }

    if (btnClearQ) {
      btnClearQ.addEventListener("click", () => {
        if (confirm("Are you sure you want to clear the pending daily queue?")) {
          QueueManager.saveQueue([], () => logMsg("🧹 Daily Queue cleared.", "#f59e0b"));
        }
      });
    }

    // Auto-Add imported contacts to Queue
    if (state.contacts && state.contacts.length > 0) {
      QueueManager.addToQueue(state.contacts);
    }
    QueueManager.updateUI();

    // Schedule Watcher & Catch-Up on Launch
    QueueManager.getSettings((settings) => {
      if (settings.enabled) {
        const now = new Date();
        const curTime = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
        if (curTime >= (settings.scheduleTime || "10:00") && (settings.sentToday || 0) < (settings.dailyCap || 50)) {
          QueueManager.getQueue((q) => {
            if (q.length > 0 && !state.campaign.isRunning) {
              logMsg(`⏰ Auto-Scheduler Activated: Today's pending quota will begin in 5 seconds...`, "#38bdf8");
              setTimeout(() => {
                if (!state.campaign.isRunning) {
                  state.contacts = q;
                  startCampaign();
                }
              }, 5000);
            }
          });
        }
      }
    });

    // Runtime message listener for background alarm trigger
    if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.onMessage) {
      chrome.runtime.onMessage.addListener((msg) => {
        if (msg.action === "KB_TRIGGER_DAILY_BATCH") {
          QueueManager.getSettings((settings) => {
            if (settings.enabled && !state.campaign.isRunning) {
              QueueManager.getQueue((q) => {
                if (q.length > 0) {
                  logMsg("⏰ Background Alarm Triggered Daily Batch!", "#38bdf8");
                  state.contacts = q;
                  startCampaign();
                }
              });
            }
          });
        }
      });
    }

    if (!state.contacts || state.contacts.length === 0) {
      alert("No contacts found! Please import an Excel/CSV file or paste phone numbers first.");
      return;
    }

    const template = document.getElementById("kb-msg-template").value.trim();
    if (!template) {
      alert("Please compose a message template!");
      return;
    }

    // Auto-save current template & settings before starting
    saveSettings(false);

    // AI Memory & Repeat Detection Check
    SmartMemory.checkWhatsAppList(state.contacts, ({ listDuplicates, historyDuplicates, uniqueContacts, freshContacts }) => {
      const hasListDups = listDuplicates.length > 0;
      const hasHistDups = historyDuplicates.length > 0;

      if (hasListDups || hasHistDups) {
        // Show Upgraded AI Memory & Repeat Modal
        const modal = document.getElementById("kb-wa-dup-modal");
        const desc = document.getElementById("kb-wa-dup-desc");
        if (modal && desc) {
          const sample = (historyDuplicates[0] || listDuplicates[0]);
          desc.innerHTML = `
            <div style="font-size:12px; color:var(--kb-text); line-height:1.5;">
              Kimberbyte Smart Memory scanned <b>${state.contacts.length} leads</b> and detected repeat contacts:
            </div>
            <div style="margin:10px 0; background:rgba(245,158,11,0.08); border:1px solid rgba(245,158,11,0.25); border-radius:8px; padding:10px 12px; font-size:11.5px; text-align:left;">
              <div style="margin-bottom:5px;">🔄 <b>${listDuplicates.length} List Duplicates:</b> Repeated inside current upload.</div>
              <div>🛡️ <b>${historyDuplicates.length} Already Contacted Leads:</b> Previously messaged in past campaigns${sample ? ` (e.g. <code>+${sample.phone}</code>)` : ''}.</div>
            </div>
            <div style="font-size:11px; color:var(--kb-muted); text-align:left;">
              Repeatedly sending messages to the same numbers risks spam reports and WhatsApp ban. What would you like to do?
            </div>
          `;
          modal.classList.add("kb-show");
          modal.style.display = "flex";

          const btnSkip = document.getElementById("kb-wa-dup-skip");
          const btnSendAll = document.getElementById("kb-wa-dup-sendall");
          const btnCancel = document.getElementById("kb-wa-dup-cancel");

          const newSkip = btnSkip.cloneNode(true);
          const newSendAll = btnSendAll.cloneNode(true);
          const newCancel = btnCancel.cloneNode(true);
          btnSkip.parentNode.replaceChild(newSkip, btnSkip);
          btnSendAll.parentNode.replaceChild(newSendAll, btnSendAll);
          btnCancel.parentNode.replaceChild(newCancel, btnCancel);

          newSkip.addEventListener("click", () => {
            modal.classList.remove("kb-show");
            modal.style.display = "none";
            state.contacts = freshContacts.length > 0 ? freshContacts : uniqueContacts;
            updateStatsTotal(state.contacts.length);
            logMsg(`🛡️ Smart Memory filtered repeats: proceeding with ${state.contacts.length} fresh unique leads.`, "#10b981");
            executeCampaign();
          });

          newSendAll.addEventListener("click", () => {
            modal.classList.remove("kb-show");
            modal.style.display = "none";
            logMsg(`Proceeding with all ${state.contacts.length} entries (including repeats).`, "#f59e0b");
            executeCampaign();
          });

          newCancel.addEventListener("click", () => {
            modal.classList.remove("kb-show");
            modal.style.display = "none";
            logMsg("Campaign startup cancelled for list review.", "#ef4444");
          });

          return;
        }
      }

      // No repeats -> proceed directly
      executeCampaign();
    });
  }

  async function executeCampaign() {
    const template = document.getElementById("kb-msg-template").value.trim();

    state.campaign.isRunning = true;
    state.campaign.isPaused = false;
    state.campaign.currentIndex = 0;
    state.campaign.sent = 0;
    state.campaign.failed = 0;
    state.campaign.results = [];

    document.getElementById("kb-btn-start").style.display = "none";
    document.getElementById("kb-btn-actions").style.display = "flex";
    document.getElementById("kb-btn-pause").textContent = "⏸ Pause";

    logMsg(`🚀 Starting WhatsApp Campaign for ${state.contacts.length} recipients...`, "#10b981");

    for (let i = 0; i < state.contacts.length; i++) {
      if (!state.campaign.isRunning) break;

      while (state.campaign.isPaused) {
        await sleep(500);
        if (!state.campaign.isRunning) break;
      }
      if (!state.campaign.isRunning) break;

      const dailyCap = parseInt(document.getElementById("kb-daily-cap")?.value, 10) || 50;
      let sentTodayCount = 0;
      await new Promise(r => QueueManager.getSettings(s => { sentTodayCount = s.sentToday || 0; r(); }));

      if (sentTodayCount >= dailyCap) {
        logMsg(`🛡️ [Daily Safe Cap] Sent today's limit of ${dailyCap} messages! Safe pause to protect WhatsApp account. Remaining contacts saved in queue for tomorrow.`, "#10b981");
        alert(`📅 Daily Safe Limit Hit:\n\nSent ${dailyCap} messages today.\nRemaining contacts are saved in your Queue and scheduled for tomorrow.`);
        break;
      }

      const c = state.contacts[i];
      state.campaign.currentIndex = i + 1;

      // Personalize message
      let msg = template
        .replace(/\{name\}/gi, c.name || "Client")
        .replace(/\{phone\}/gi, c.phone)
        .replace(/\{date\}/gi, new Date().toLocaleDateString());

      const addr = (state.settings.address || "").trim();
      const shouldAttach = state.settings.includeAddress ?? true;
      if (template.includes("{address}")) {
        msg = msg.replace(/\{address\}/gi, addr);
      } else if (shouldAttach && addr) {
        msg += `\n\n📍 Office Address:\n${addr}`;
      }

      logMsg(`[${i + 1}/${state.contacts.length}] Sending to ${c.name} (+${c.phone})...`);

      const success = await dispatchMessage(c.phone, msg, c);
      const timestamp = new Date().toLocaleString();

      if (success) {
        state.campaign.sent++;
        state.campaign.results.push({ name: c.name, phone: c.phone, status: "SENT", time: timestamp });
        logMsg(`✅ Sent successfully to +${c.phone}`, "#10b981");
        SmartMemory.recordWhatsApp(c.phone, c.name, "SENT");
        QueueManager.recordSent();
        QueueManager.getQueue((q) => {
          if (q.length > 0) {
            q.shift();
            QueueManager.saveQueue(q);
          }
        });
      } else {
        state.campaign.failed++;
        state.campaign.results.push({ name: c.name, phone: c.phone, status: "FAILED / INVALID", time: timestamp });
        logMsg(`Failed / Not on WhatsApp: +${c.phone}`, "#ef4444");
        if (window.DailyAuditSystem) {
          window.DailyAuditSystem.recordDispatch("wa", {
            recipient: `+${c.phone}`,
            name: c.name,
            status: "REJECTED",
            reason: "Not on WhatsApp / Chat load timeout",
            delaySec: activeWaCountdown || 25
          });
        }
      }

      // Update counters & progress
      const sentEl = document.getElementById("kb-stat-sent");
      const failedEl = document.getElementById("kb-stat-failed");
      const remEl = document.getElementById("kb-stat-remaining");
      const barEl = document.getElementById("kb-progress-bar");

      if (sentEl) sentEl.textContent = state.campaign.sent;
      if (failedEl) failedEl.textContent = state.campaign.failed;
      if (remEl) remEl.textContent = state.contacts.length - (i + 1);
      if (barEl) barEl.style.width = `${Math.round(((i + 1) / state.contacts.length) * 100)}%`;

      // Safe Anti-Ban Delay with Live Editable Countdown
      if (i < state.contacts.length - 1 && state.campaign.isRunning) {
        const nextDelaySeconds = getNextDelay();
        state.campaign.activeCountdownRemaining = nextDelaySeconds;

        const cdBox = document.getElementById("kb-wa-countdown-box");
        const cdSecondsEl = document.getElementById("kb-wa-cd-seconds");
        const cdInput = document.getElementById("kb-wa-cd-input");

        if (cdBox) {
          cdBox.classList.add("kb-show");
          cdBox.style.display = "flex";
        }
        logMsg(`⏳ Anti-Ban pacing: next message in ${nextDelaySeconds}s...`, "#f59e0b");

        while (state.campaign.activeCountdownRemaining > 0 && state.campaign.isRunning) {
          while (state.campaign.isPaused) {
            await sleep(500);
            if (!state.campaign.isRunning) break;
          }
          if (!state.campaign.isRunning) break;

          if (cdSecondsEl) cdSecondsEl.textContent = `${state.campaign.activeCountdownRemaining}s`;
          if (cdInput && document.activeElement !== cdInput) {
            cdInput.value = state.campaign.activeCountdownRemaining;
          }

          await sleep(1000);
          state.campaign.activeCountdownRemaining--;
        }

        if (cdBox) {
          cdBox.classList.remove("kb-show");
          cdBox.style.display = "none";
        }
      }
    }

    state.campaign.isRunning = false;
    resetControls();
    logMsg(`🎉 Campaign completed! Total Sent: ${state.campaign.sent}, Failed: ${state.campaign.failed}`, "#10b981");
    alert(`Campaign Complete!\n\nSent: ${state.campaign.sent}\nFailed/Invalid: ${state.campaign.failed}`);
  }

  function resetControls() {
    const cdBox = document.getElementById("kb-wa-countdown-box");
    if (cdBox) {
      cdBox.classList.remove("kb-show");
      cdBox.style.display = "none";
    }
    document.getElementById("kb-btn-start").style.display = "flex";
    document.getElementById("kb-btn-actions").style.display = "none";
  }

  function exportResultsCSV() {
    if (!state.campaign.results || state.campaign.results.length === 0) {
      alert("No campaign results to export yet!");
      return;
    }
    let csv = "data:text/csv;charset=utf-8,Name,Phone,Status,Timestamp\n";
    state.campaign.results.forEach(r => {
      csv += `"${r.name}","${r.phone}","${r.status}","${r.time}"\n`;
    });
    const encoded = encodeURI(csv);
    const link = document.createElement("a");
    link.setAttribute("href", encoded);
    link.setAttribute("download", `WhatsApp_Bot_Report_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  // License-Protected Boot Controller
  let isWaBooted = false;
  function startProtectedWhatsAppBot() {
    if (isWaBooted) return;
    isWaBooted = true;
    initUI();
    setInterval(() => {
      initUI();
    }, 2000);
  }

  function launchWhatsAppBot() {
    if (window.KimberbyteLicenseShield) {
      window.KimberbyteLicenseShield.ensureLicense("WA", () => {
        startProtectedWhatsAppBot();
      });
    } else {
      startProtectedWhatsAppBot();
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => setTimeout(launchWhatsAppBot, 1200));
  } else {
    setTimeout(launchWhatsAppBot, 1200);
  }
})();
