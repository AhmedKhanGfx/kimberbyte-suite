/**
 * Kimberbyte All-In-One Pro - Background Service Worker
 * Standalone Edition with Smart Daily Alarm Scheduler
 */

// Setup 1-minute recurring alarm for accurate daily schedule triggers
chrome.runtime.onInstalled.addListener(() => {
  console.log("[Kimberbyte Suite] Extension mounted successfully. Initializing Daily Alarms...");
  chrome.alarms.create("kb_daily_scheduler", { periodInMinutes: 1 });
});

chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create("kb_daily_scheduler", { periodInMinutes: 1 });
});

// Periodic Alarm Checker (Fires every minute)
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name !== "kb_daily_scheduler") return;

  const now = new Date();
  const todayStr = now.toISOString().slice(0, 10);
  const currentHours = String(now.getHours()).padStart(2, "0");
  const currentMinutes = String(now.getMinutes()).padStart(2, "0");
  const currentTimeStr = `${currentHours}:${currentMinutes}`;

  chrome.storage.local.get([
    "kb_wa_queue_settings",
    "kb_wa_daily_queue",
    "kb_hostinger_queue_settings",
    "kb_hostinger_daily_queue",
    "kb_multimail_queue_settings",
    "kb_multimail_daily_queue"
  ], (res) => {
    if (!res) return;

    // 1. WhatsApp Scheduler Check
    const waSettings = res.kb_wa_queue_settings;
    const waQueue = res.kb_wa_daily_queue || [];
    if (waSettings && waSettings.enabled && waQueue.length > 0) {
      const lastDate = waSettings.lastDate || "";
      const sentToday = (lastDate === todayStr) ? (waSettings.sentToday || 0) : 0;
      const dailyCap = waSettings.dailyCap || 50;

      if (sentToday < dailyCap && currentTimeStr >= (waSettings.scheduleTime || "10:00")) {
        // Find existing WhatsApp Web tab or notify
        chrome.tabs.query({ url: "https://web.whatsapp.com/*" }, (tabs) => {
          if (tabs && tabs.length > 0) {
            chrome.tabs.sendMessage(tabs[0].id, { action: "KB_TRIGGER_DAILY_BATCH" }).catch(() => {});
          }
        });
      }
    }

    // 2. Hostinger Scheduler Check
    const mfSettings = res.kb_hostinger_queue_settings;
    const mfQueue = res.kb_hostinger_daily_queue || [];
    if (mfSettings && mfSettings.enabled && mfQueue.length > 0) {
      const lastDate = mfSettings.lastDate || "";
      const sentToday = (lastDate === todayStr) ? (mfSettings.sentToday || 0) : 0;
      const dailyCap = mfSettings.dailyCap || 50;

      if (sentToday < dailyCap && currentTimeStr >= (mfSettings.scheduleTime || "10:00")) {
        chrome.tabs.query({ url: "*://*.hostinger.com/*" }, (tabs) => {
          if (tabs && tabs.length > 0) {
            chrome.tabs.sendMessage(tabs[0].id, { action: "KB_TRIGGER_DAILY_BATCH" }).catch(() => {});
          }
        });
      }
    }

    // 3. Multi-Mail Scheduler Check
    const mmSettings = res.kb_multimail_queue_settings;
    const mmQueue = res.kb_multimail_daily_queue || [];
    if (mmSettings && mmSettings.enabled && mmQueue.length > 0) {
      const lastDate = mmSettings.lastDate || "";
      const sentToday = (lastDate === todayStr) ? (mmSettings.sentToday || 0) : 0;
      const dailyCap = mmSettings.dailyCap || 100;

      if (sentToday < dailyCap && currentTimeStr >= (mmSettings.scheduleTime || "10:00")) {
        chrome.tabs.query({}, (tabs) => {
          tabs.forEach(t => {
            if (t.url && t.url.includes("dashboard.html")) {
              chrome.tabs.sendMessage(t.id, { action: "KB_TRIGGER_DAILY_BATCH" }).catch(() => {});
            }
          });
        });
      }
    }
  });
});
