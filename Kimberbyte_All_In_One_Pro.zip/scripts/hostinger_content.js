/**
 * Kimberbyte MailFlow Pro - Hostinger Webmail In-Page Drawer Integration
 * 100% Standalone Edition (Zero Server Dependency)
 * Exact Visual & Functional Twin of WhatsApp Bot Pro
 */

(function () {
  if (window.__KIMBERBYTE_HOSTINGER_DRAWER_LOADED__) return;
  window.__KIMBERBYTE_HOSTINGER_DRAWER_LOADED__ = true;

  console.log('[Kimberbyte MailFlow Suite] Mounting 100% Standalone Twin on Hostinger Webmail...');

  const storage = (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) ? chrome.storage.local : {
    get: (keys, cb) => {
      const res = {};
      keys.forEach(k => {
        const v = localStorage.getItem(k);
        if (v) {
          try { res[k] = JSON.parse(v); } catch(e) { res[k] = v; }
        }
      });
      cb(res);
    },
    set: (obj, cb) => {
      Object.keys(obj).forEach(k => {
        localStorage.setItem(k, typeof obj[k] === 'string' ? obj[k] : JSON.stringify(obj[k]));
      });
      if (cb) cb();
    }
  };

  function initMailFlowSuite() {
    let leads = [];
    let columns = [];
    let isRunning = false;
    let isPaused = false;
    let results = [];
    let stats = { total: 0, sent: 0, failed: 0 };
    let domWatchInterval = null;
    let activeHostingerCountdown = 0;
    let mfAttachment = null;

    // --- EMAIL VALIDATOR (RFC 5322 Format Checker) ---
    function validateEmail(email) {
      if (!email || typeof email !== 'string') return { isValid: false, reason: 'Empty email' };
      const trimmed = email.trim();
      const regex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$/;
      if (!regex.test(trimmed)) {
        return { isValid: false, reason: 'Invalid syntax' };
      }
      const parts = trimmed.split('@');
      if (parts.length !== 2) return { isValid: false, reason: 'Malformed @' };
      const domain = parts[1];
      if (!domain.includes('.') || domain.endsWith('.')) return { isValid: false, reason: 'Missing domain TLD' };
      const tld = domain.split('.').pop();
      if (tld.length < 2) return { isValid: false, reason: 'Invalid domain extension' };
      const dummyDomains = ['example.com', 'test.com', 'domain.com', 'sample.com'];
      if (dummyDomains.includes(domain.toLowerCase())) {
        return { isValid: false, reason: 'Placeholder domain' };
      }
      return { isValid: true, email: trimmed };
    }

    // --- SMART MEMORY ENGINE (Lifetime Local Lead Database & Repeat Shield) ---
    const SmartMemory = {
      KEY: 'kb_outreach_history_db',

      get: (cb) => {
        storage.get([SmartMemory.KEY], (res) => {
          let mem = res && res[SmartMemory.KEY];
          if (!mem || typeof mem !== 'object') {
            mem = { numbers: {}, emails: {}, stats: { totalNumbers: 0, totalEmails: 0 } };

    // --- SMART DAILY QUEUE & SCHEDULER ENGINE (HOSTINGER) ---
    const QueueManager = {
      QUEUE_KEY: "kb_hostinger_daily_queue",
      SETTINGS_KEY: "kb_hostinger_queue_settings",

      getSettings: (cb) => {
        storage.get([QueueManager.SETTINGS_KEY], (res) => {
          const today = new Date().toISOString().slice(0, 10);
          let settings = res && res[QueueManager.SETTINGS_KEY];
          if (!settings || typeof settings !== "object") {
            settings = { enabled: false, scheduleTime: "10:00", dailyCap: 50, lastDate: today, sentToday: 0 };
          }
          if (settings.lastDate !== today) {
            settings.lastDate = today;
            settings.sentToday = 0;
            QueueManager.saveSettings(settings);
          }
          cb(settings);
        });
      },

      saveSettings: (settings, cb) => {
        const obj = {};
        obj[QueueManager.SETTINGS_KEY] = settings;
        storage.set(obj, cb);
      },

      getQueue: (cb) => {
        storage.get([QueueManager.QUEUE_KEY], (res) => {
          const queue = (res && Array.isArray(res[QueueManager.QUEUE_KEY])) ? res[QueueManager.QUEUE_KEY] : [];
          cb(queue);
        });
      },

      saveQueue: (queue, cb) => {
        const obj = {};
        obj[QueueManager.QUEUE_KEY] = queue;
        storage.set(obj, () => {
          QueueManager.updateUI();
          if (cb) cb();
        });
      },

      addToQueue: (contacts, cb) => {
        QueueManager.getQueue((existing) => {
          const existingEmails = new Set(existing.map(c => String(c.Email || c.email || "").toLowerCase()));
          const toAdd = contacts.filter(c => {
            const e = String(c.Email || c.email || "").toLowerCase();
            return e && !existingEmails.has(e);
          });
          const updated = [...existing, ...toAdd];
          QueueManager.saveQueue(updated, cb);
        });
      },

      recordSent: (cb) => {
        QueueManager.getSettings((settings) => {
          settings.sentToday = (settings.sentToday || 0) + 1;
          QueueManager.saveSettings(settings, () => {
            QueueManager.updateUI();
            if (cb) cb(settings);
          });
        });
      },

      updateUI: () => {
        QueueManager.getQueue((queue) => {
          QueueManager.getSettings((settings) => {
            const pendingEl = document.getElementById("kb-queue-pending-count");
            const todayEl = document.getElementById("kb-queue-today-count");
            const capInp = document.getElementById("kb-daily-cap");
            const timeInp = document.getElementById("kb-mf-schedule-time");
            const chk = document.getElementById("kb-mf-schedule-chk");
            const lbl = document.getElementById("kb-mf-schedule-lbl");

            if (pendingEl) pendingEl.textContent = queue.length;
            if (todayEl) todayEl.textContent = `${settings.sentToday || 0} / ${settings.dailyCap || 50}`;
            if (capInp && document.activeElement !== capInp) capInp.value = settings.dailyCap || 50;
            if (timeInp && document.activeElement !== timeInp) timeInp.value = settings.scheduleTime || "10:00";
            if (chk) chk.checked = Boolean(settings.enabled);
            if (lbl) {
              lbl.textContent = settings.enabled ? "Auto-Schedule ON" : "Auto-Schedule";
              lbl.style.color = settings.enabled ? "#10b981" : "var(--kb-muted)";
            }
          });
        });
      }
    };

          }
          if (!mem.numbers) mem.numbers = {};
          if (!mem.emails) mem.emails = {};
          cb(mem);
        });
      },

      save: (mem, cb) => {
        mem.stats = {
          totalNumbers: Object.keys(mem.numbers || {}).length,
          totalEmails: Object.keys(mem.emails || {}).length,
          lastUpdated: new Date().toLocaleString()
        };
        const toSet = {};
        toSet[SmartMemory.KEY] = mem;
        storage.set(toSet, () => {
          updateMemoryBadge();

      // Queue & Scheduler Listeners
      const chkSched = document.getElementById("kb-mf-schedule-chk");
      const timeSched = document.getElementById("kb-mf-schedule-time");
      const capSched = document.getElementById("kb-daily-cap");
      const btnClearQ = document.getElementById("kb-btn-clear-queue");

      if (chkSched) {
        chkSched.addEventListener("change", () => {
          QueueManager.getSettings((s) => {
            s.enabled = chkSched.checked;
            QueueManager.saveSettings(s, () => QueueManager.updateUI());
          });
        });
      }

      if (timeSched) {
        timeSched.addEventListener("change", () => {
          QueueManager.getSettings((s) => {
            s.scheduleTime = timeSched.value;
            QueueManager.saveSettings(s, () => QueueManager.updateUI());
          });
        });
      }

      if (capSched) {
        capSched.addEventListener("change", () => {
          QueueManager.getSettings((s) => {
            s.dailyCap = parseInt(capSched.value, 10) || 50;
            QueueManager.saveSettings(s, () => QueueManager.updateUI());
          });
        });
      }

      if (btnClearQ) {
        btnClearQ.addEventListener("click", () => {
          if (confirm("Are you sure you want to clear the pending daily queue?")) {
            QueueManager.saveQueue([], () => log("🧹 Daily Queue cleared."));
          }
        });
      }

      QueueManager.updateUI();

      // Schedule Watcher & Catch-Up on Launch
      QueueManager.getSettings((settings) => {
        if (settings.enabled) {
          const now = new Date();
          const curTime = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
          if (curTime >= (settings.scheduleTime || "10:00") && (settings.sentToday || 0) < (settings.dailyCap || 50)) {
            QueueManager.getQueue((q) => {
              if (q.length > 0 && !isRunning) {
                log(`⏰ Auto-Scheduler Activated: Today's pending quota will begin in 5 seconds...`);
                setTimeout(() => {
                  if (!isRunning) {
                    leads = q;
                    startCampaign();
                  }
                }, 5000);
              }
            });
          }
        }
      });

      // Runtime message listener for background alarm trigger
      if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.onMessage) {
        chrome.runtime.onMessage.addListener((msg) => {
          if (msg.action === "KB_TRIGGER_DAILY_BATCH") {
            QueueManager.getSettings((settings) => {
              if (settings.enabled && !isRunning) {
                QueueManager.getQueue((q) => {
                  if (q.length > 0) {
                    log("⏰ Background Alarm Triggered Daily Batch!");
                    leads = q;
                    startCampaign();
                  }
                });
              }
            });
          }
        });
      }

          if (cb) cb();
        });
      },

      recordEmail: (email, name, company, status, cb) => {
        SmartMemory.get((mem) => {
          const cleanE = String(email).trim().toLowerCase();
          if (!cleanE) return;
          const prev = mem.emails[cleanE] || { count: 0 };
          mem.emails[cleanE] = {
            name: name || prev.name || 'Lead',
            company: company || prev.company || '',
            lastSent: new Date().toLocaleString(),
            count: (prev.count || 0) + 1,
            status: status || 'SENT',
            channel: 'email'
          };
          SmartMemory.save(mem, cb);
        });
      },

      checkEmailList: (leadsList, emailCol, cb) => {
        SmartMemory.get((mem) => {
          const seenInList = new Set();
          const listDuplicates = [];
          const historyDuplicates = [];
          const freshLeads = [];
          const uniqueLeads = [];

          leadsList.forEach(l => {
            const rawE = String(l[emailCol] || '').trim().toLowerCase();
            const isHist = !!mem.emails[rawE];
            const isListDup = seenInList.has(rawE);

            if (isListDup) {
              listDuplicates.push({ ...l, historyMeta: mem.emails[rawE] });
            } else {
              if (rawE) seenInList.add(rawE);
              uniqueLeads.push(l);
              if (isHist) {
                historyDuplicates.push({ ...l, historyMeta: mem.emails[rawE] });
              } else {
                freshLeads.push(l);
              }
            }
          });

          cb({
            listDuplicates,
            historyDuplicates,
            uniqueLeads,
            freshLeads,
            totalMemoryCount: Object.keys(mem.emails || {}).length
          });
        });
      },

      exportCSV: () => {
        SmartMemory.get((mem) => {
          const emails = mem.emails || {};
          const keys = Object.keys(emails);
          if (keys.length === 0) {
            alert('Smart Memory is currently empty! No past emails recorded yet.');
            return;
          }
          let csv = 'Email,Name,Company,Last Sent,Sent Count,Channel,Status\r\n';
          keys.forEach(k => {
            const item = emails[k];
            csv += `"${k}","${(item.name || '').replace(/"/g, '""')}","${(item.company || '').replace(/"/g, '""')}","${item.lastSent || ''}","${item.count || 1}","email","${item.status || 'SENT'}"\r\n`;
          });
          const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `Kimberbyte_Smart_Memory_Hostinger_${new Date().toISOString().slice(0, 10)}.csv`;
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          URL.revokeObjectURL(url);
        });
      },

      clear: () => {
        if (confirm('Are you sure you want to clear your Smart Memory history? This will reset all previously contacted email leads.')) {
          SmartMemory.save({ numbers: {}, emails: {}, stats: { totalNumbers: 0, totalEmails: 0 } }, () => {
            alert('Smart Memory email history reset successfully!');
          });
        }
      }
    };

    function updateMemoryBadge() {
      SmartMemory.get((mem) => {
        const count = Object.keys(mem.emails || {}).length;
        const countEl = document.getElementById('kb-mf-mem-count');
        if (countEl) {
          countEl.textContent = `${count} lead${count === 1 ? '' : 's'} remembered`;
        }
      });
    }

    function ensureToggleBtn(panel) {
      let toggleBtn = document.getElementById('kb-mailflow-toggle-btn');
      if (!toggleBtn) {
        toggleBtn = document.createElement('button');
        toggleBtn.id = 'kb-mailflow-toggle-btn';
        toggleBtn.setAttribute('title', 'Open Kimberbyte MailFlow Pro');
        toggleBtn.innerHTML = `
          <div class="kb-mf-trigger-icon">
            <svg viewBox="0 0 24 24" width="26" height="26" fill="currentColor">
              <path d="M1.5 8.67v8.58a3 3 0 003 3h15a3 3 0 003-3V8.67l-8.928 5.493a3 3 0 01-3.144 0L1.5 8.67z"/>
              <path d="M22.5 6.908V6.75a3 3 0 00-3-3h-15a3 3 0 00-3 3v.158l9.714 5.978a1.5 1.5 0 001.572 0L22.5 6.908z"/>
            </svg>
          </div>
          <span class="kb-mf-trigger-label">MailFlow Pro</span>
        `;
        (document.body || document.documentElement).appendChild(toggleBtn);
        toggleBtn.addEventListener('click', () => {
          const p = document.getElementById('kb-mailflow-panel');
          if (p) p.classList.remove('kb-collapsed');
          toggleBtn.style.setProperty('display', 'none', 'important');
        });
      }
      if (panel && panel.classList.contains('kb-collapsed')) {
        toggleBtn.style.setProperty('display', 'flex', 'important');
      } else {
        toggleBtn.style.setProperty('display', 'none', 'important');
      }
      return toggleBtn;
    }

    function buildPanel() {
      let panel = document.getElementById('kb-mailflow-panel');
      if (!panel) {
        panel = document.createElement('div');
        panel.id = 'kb-mailflow-panel';
        panel.className = 'kb-collapsed';

        panel.innerHTML = `
          <!-- Header (Exact Twin of WhatsApp Bot Pro) -->
          <div class="kb-wa-header">
            <div>
              <div class="kb-wa-title">
                <span> MailFlow Pro</span>
                <span class="kb-wa-badge">● Standalone Ready</span>
              </div>
              <div class="kb-wa-subtitle">Autonomous Hostinger Cold Outreach Suite</div>
            </div>
            <button class="kb-wa-btn-close" id="kb-btn-close" title="Close Panel">✕</button>
          </div>

          <!-- Tabs (Exact Twin of WhatsApp Bot Pro) -->
          <div class="kb-wa-tabs">
            <button class="kb-wa-tab-btn kb-wa-active" data-tab="sheet">📁 Excel / CSV</button>
            <button class="kb-wa-tab-btn" data-tab="paste">📝 Quick Paste</button>
            <button class="kb-wa-tab-btn" data-tab="direct">✉️ Direct Email</button>
            <button type="button" id="kb-btn-hostinger-audit" style="color:#38bdf8; border:1px solid rgba(56,189,248,0.3); background:rgba(56,189,248,0.1); border-radius:5px; padding:3px 8px; font-size:11px; font-weight:700; margin-left:auto; cursor:pointer;" title="View Daily History & Logs">📊 History</button>
          </div>

          <!-- Panel Scrollable Body -->
          <div class="kb-wa-body">
            <!-- Step 1: Recipients & Contact List Card -->
            <div class="kb-wa-card">
              <div class="kb-wa-card-header">
                <div class="kb-wa-card-title">
                  <span>1. Recipients & Contact List</span>
                </div>
              </div>

              <!-- Tab 1: Sheet Upload -->
              <div id="kb-tab-sheet" class="kb-wa-tab-content">
                <div class="kb-wa-dropzone" id="kb-dropzone">
                  <svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12"/>
                  </svg>
                  <div style="font-weight: 700; font-size: 13px; margin-top: 6px;">Click or Drag Excel / CSV File</div>
                  <div style="font-size: 11px; color: var(--kb-muted); margin-top: 2px;">Supports .xlsx, .xls, .csv lead lists</div>
                  <input type="file" id="kb-file-input" accept=".xlsx, .xls, .csv" style="display:none;" />
                </div>

                <div id="kb-mapping-wrap" style="display: none; margin-top: 12px;">
                  <div style="font-size: 12px; color: var(--kb-primary); font-weight:700; margin-bottom: 6px;" id="kb-file-summary">Leads Loaded: 0</div>
                  <div style="display:flex; gap:10px;">
                    <div style="flex:1;">
                      <label class="kb-wa-label">Email Column</label>
                      <select id="kb-email-col" class="kb-wa-select"></select>
                    </div>
                    <div style="flex:1;">
                      <label class="kb-wa-label">Name Column</label>
                      <select id="kb-name-col" class="kb-wa-select"></select>
                    </div>
                  </div>
                  <div style="margin-top: 8px;">
                    <label class="kb-wa-label">Company Column</label>
                    <select id="kb-company-col" class="kb-wa-select"></select>
                  </div>
                </div>
              </div>

              <!-- Tab 2: Quick Paste -->
              <div id="kb-tab-paste" class="kb-wa-tab-content" style="display:none;">
                <label class="kb-wa-label">Paste Emails (One per line or comma separated)</label>
                <textarea id="kb-paste-input" class="kb-wa-textarea" rows="3" placeholder="client@company.com, David&#10;sarah@startup.io, Sarah&#10;contact@domain.com"></textarea>
                <div style="display:flex; justify-content:space-between; align-items:center; margin-top:6px;">
                  <span id="kb-paste-count" style="font-size: 11px; color: var(--kb-muted);">0 emails detected</span>
                  <button type="button" id="kb-btn-parse-paste" class="kb-wa-btn-sm">Process List</button>
                </div>
              </div>

              <!-- Tab 3: Direct Email -->
              <div id="kb-tab-direct" class="kb-wa-tab-content" style="display:none;">
                <label class="kb-wa-label">Target Email Address</label>
                <input type="email" id="kb-direct-email" class="kb-wa-input" placeholder="e.g. client@company.com" />
                <label class="kb-wa-label" style="margin-top:8px;">Instant Single Send</label>
                <button type="button" id="kb-btn-direct-send" class="kb-wa-btn-primary" style="margin-top:10px;">🚀 Open Composer & Send</button>
              </div>

              <!-- Validation & Quality Banner -->
              <div id="kb-mf-validation-banner" class="kb-wa-val-banner" style="display:none;">
                <div style="display:flex; align-items:center; gap:8px;">
                  <span id="kb-mf-val-ok" style="color:#10b981; font-weight:700;"> 0 Valid</span>
                  <span style="color:var(--kb-border);">|</span>
                  <span id="kb-mf-val-err" style="color:#ef4444; font-weight:700;">⚠️ 0 Filtered</span>
                </div>
                <span id="kb-mf-val-badge" style="font-size:10px; color:#38bdf8; background:rgba(56,189,248,0.15); padding:2px 6px; border-radius:4px; font-weight:700;">RFC 5322 Checked</span>
              </div>

              <!-- Smart Memory / Anti-Repeat Shield Bar -->
              <div id="kb-mf-memory-status" class="kb-wa-mem-pill">
                <div>🧠 <b style="color:var(--kb-text);">Smart Memory:</b> <span id="kb-mf-mem-count" style="color:#34d399; font-weight:700;">0 leads remembered</span></div>
                <div style="display:flex; gap:6px;">
                  <button type="button" id="kb-mf-btn-view-mem" class="kb-wa-mem-btn" title="View previously contacted leads">📊 View</button>
                  <button type="button" id="kb-mf-btn-export-mem" class="kb-wa-mem-btn" title="Export lifetime outreach history as CSV">📥 Export</button>
                  <button type="button" id="kb-mf-btn-clear-mem" class="kb-wa-mem-btn kb-wa-mem-btn-danger" title="Clear memory history">🧹 Clear</button>
                </div>
              </div>
            </div>

            <!-- Step 2: Message Template Card -->
            <div class="kb-wa-card">
              <div class="kb-wa-card-header">
                <div class="kb-wa-card-title">
                  <span>2. Broadcast Message Template</span>
                </div>
                <div style="display:flex; align-items:center; gap:8px;">
                  <span id="kb-pitch-save-ind" class="kb-wa-save-indicator" style="opacity:0;">✓ Saved</span>
                  <button type="button" id="kb-btn-save-pitch" class="kb-wa-btn-sm" title="Save template & settings">💾 Save</button>
                </div>
              </div>

              <div style="margin-bottom: 10px;">
                <label class="kb-wa-label">Subject Line</label>
                <input type="text" id="kb-email-subject" class="kb-wa-input" placeholder="Subject: Quick question for {name}" value="Quick question for {name}" />
              </div>

              <label class="kb-wa-label">Message Body</label>
              <textarea id="kb-email-body" class="kb-wa-textarea" rows="4" placeholder="Hi {name},&#10;&#10;I noticed {company} is actively scaling up and wanted to connect...">Hi {name},&#10;&#10;I noticed {company} is actively scaling up and wanted to reach out directly.&#10;&#10;Would you have 5 minutes for a brief chat this week?&#10;&#10;Best regards,&#10;Kimberbyte Outreach</textarea>

              <div style="margin-top: 8px;">
                <span class="kb-wa-label" style="margin-bottom: 4px;">Insert Dynamic Tags:</span>
                <div class="kb-wa-tags" id="kb-tags-wrap">
                  <span class="kb-wa-tag" data-tag="{name}">+ {name}</span>
                  <span class="kb-wa-tag" data-tag="{email}">+ {email}</span>
                  <span class="kb-wa-tag" data-tag="{company}">+ {company}</span>
                  <span class="kb-wa-tag" data-tag="{date}">+ {date}</span>
                  <span class="kb-wa-tag" data-tag="{address}">+ {address}</span>
                </div>
              </div>

              <!-- Business / Physical Address Option -->
              <div class="kb-wa-address-section" style="margin-top: 14px; padding-top: 12px; border-top: 1px dashed var(--kb-border);">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                  <label class="kb-wa-label" style="margin: 0; font-weight: 700; color: #f1f5f9;">🏢 Business / Office Address Footer:</label>
                  <label class="kb-wa-toggle-wrap" title="Toggle appending address at end of emails">
                    <label class="kb-checkbox-wrap" title="Include address">
                    <input type="checkbox" id="kb-mf-include-address-chk" checked />
                    <span class="kb-checkbox-box">
                      <svg class="kb-check-icon" viewBox="0 0 12 10" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="1.5 5 4.5 8 10.5 2"></polyline></svg>
                    </span>
                  </label>
                    <span id="kb-mf-addr-lbl" style="font-size: 11px; color: var(--kb-primary); font-weight: 700;">Include Address</span>
                  </label>
                </div>
                <input type="text" id="kb-mf-address-input" class="kb-wa-input" placeholder="e.g. 123 Business Avenue, Suite 400, New York, NY 10001" value="123 Business Avenue, Suite 400, New York, NY 10001" />
                <div style="font-size: 10px; color: var(--kb-muted); margin-top: 4px;">
                  Jab toggle ON hoga, to email ke aakhir mein yeh address automatic attach ho jayega.
                </div>
              </div>

              <!-- Media & Document Attachment Section -->
              <div class="kb-wa-attachment-section" style="margin-top: 12px; padding-top: 12px; border-top: 1px dashed var(--kb-border);">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                  <label class="kb-wa-label" style="margin: 0; font-weight: 700; color: #f1f5f9;">📎 Media / Document Attachment:</label>
                  <button type="button" id="kb-mf-btn-browse-file" class="kb-wa-btn-sm" style="background: rgba(56, 189, 248, 0.15); border: 1px solid rgba(56, 189, 248, 0.4); color: #38bdf8; font-size: 11px;">
                    + Add File
                  </button>
                  <input type="file" id="kb-mf-file-attachment" style="display:none;" />
                </div>

                <!-- Selected Attachment Preview Pill -->
                <div id="kb-mf-attach-pill" style="display: none; align-items: center; justify-content: space-between; background: #070d17; border: 1px solid #1e2e46; border-radius: 8px; padding: 7px 12px; margin-top: 6px;">
                  <div style="display: flex; align-items: center; gap: 8px; overflow: hidden;">
                    <span style="font-size: 16px;">📎</span>
                    <div style="overflow: hidden;">
                      <div id="kb-mf-attach-name" style="font-size: 11.5px; font-weight: 700; color: #f8fafc; white-space: nowrap; text-overflow: ellipsis; overflow: hidden; max-width: 250px;">document.pdf</div>
                      <div id="kb-mf-attach-size" style="font-size: 10px; color: var(--kb-muted);">0 KB</div>
                    </div>
                  </div>
                  <button type="button" id="kb-mf-btn-remove-file" style="background: none; border: none; color: #ef4444; font-size: 14px; font-weight: 800; cursor: pointer; padding: 2px 6px;" title="Remove Attachment">✕</button>
                </div>

                <div id="kb-mf-attach-empty-note" style="font-size: 10px; color: var(--kb-muted); margin-top: 4px;">
                  Optional: Attach a PDF or proposal. Message text will be sent along with the file.
                </div>
              </div>
            </div>

            <!-- Step 3: Pacing & Anti-Spam Delivery Card -->
            <div class="kb-wa-card">
              <div class="kb-wa-card-header">
                <div class="kb-wa-card-title">
                  <span>3. Pacing & Anti-Spam Delivery</span>
                </div>
                <label class="kb-wa-toggle-wrap">
                  <label class="kb-checkbox-wrap" title="Smart Dynamic Pacing">
                  <input type="checkbox" id="kb-chk-smart-timer" checked />
                  <span class="kb-checkbox-box">
                    <svg class="kb-check-icon" viewBox="0 0 12 10" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="1.5 5 4.5 8 10.5 2"></polyline></svg>
                  </span>
                </label>
                  <span style="font-size:11.5px; color:var(--kb-primary); font-weight:700;">🎲 Smart Dynamic</span>
                </label>
              </div>

              <!-- Range Inputs: Always Visible so user chooses where random delay starts and ends -->
              <div id="kb-manual-delay-wrap" style="display:flex; gap:10px; margin-bottom:10px;">
                <div style="flex:1;">
                  <label class="kb-wa-label">Min Delay (s)</label>
                  <input type="number" id="kb-min-delay" class="kb-wa-input" value="15" min="5" max="300" />
                </div>
                <div style="flex:1;">
                  <label class="kb-wa-label">Max Delay (s)</label>
                  <input type="number" id="kb-max-delay" class="kb-wa-input" value="45" min="8" max="600" />
                </div>
              </div>

              <!-- Live Dynamic Delay Explanation -->
              <div id="kb-smart-info" class="kb-wa-info-pill">
                 <b>Smart Dynamic Active:</b> Emulates genuine human pacing with random intervals (15s – 45s) between emails. No manual calculation needed.
              </div>

              <!-- Smart Daily Queue & Scheduler Box -->
              <div class="kb-wa-queue-box">
                <div class="kb-wa-queue-header">
                  <div style="display:flex; align-items:center; gap:6px;">
                    <span>📅</span>
                    <span style="font-weight:700; color:#f8fafc;">Daily Queue & Auto-Scheduler</span>
                  </div>
                  <label class="kb-wa-toggle-wrap">
                    <label class="kb-checkbox-wrap" title="Auto-Schedule Daily Limit">
                    <input type="checkbox" id="kb-mf-schedule-chk" />
                    <span class="kb-checkbox-box">
                      <svg class="kb-check-icon" viewBox="0 0 12 10" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="1.5 5 4.5 8 10.5 2"></polyline></svg>
                    </span>
                  </label>
                    <span id="kb-mf-schedule-lbl" style="font-size:11px; color:var(--kb-primary); font-weight:700;">Auto-Schedule</span>
                  </label>
                </div>

                <div style="display:flex; gap:10px; margin-top:8px;">
                  <div style="flex:1;">
                    <label class="kb-wa-label">Daily Send Limit (per day)</label>
                    <input type="number" id="kb-daily-cap" class="kb-wa-input" value="50" min="1" max="1000" />
                  </div>
                  <div style="flex:1;">
                    <label class="kb-wa-label">Schedule Time (Daily)</label>
                    <input type="time" id="kb-mf-schedule-time" class="kb-wa-input" value="10:00" />
                  </div>
                </div>

                <div class="kb-wa-queue-status-bar" id="kb-wa-queue-status">
                  <div>
                    <span style="color:#94a3b8;">Pending in Queue:</span> <b style="color:#38bdf8;" id="kb-queue-pending-count">0</b>
                    <span style="margin: 0 6px; color:#334155;">|</span>
                    <span style="color:#94a3b8;">Today:</span> <b style="color:#10b981;" id="kb-queue-today-count">0 / 50</b>
                  </div>
                  <button type="button" id="kb-btn-clear-queue" class="kb-wa-mem-btn kb-wa-mem-btn-danger" style="font-size:10px; padding:2px 6px;" title="Clear pending queue">Clear Queue</button>
                </div>
              </div>
            </div>

            <!-- Live Countdown Box (ONLY visible during active delay between sends) -->
            <div id="kb-live-countdown-box" class="kb-wa-countdown-box">
              <div class="kb-wa-cd-header">
                <span style="display:flex; align-items:center; gap:6px;">
                  <span style="display:inline-block; width:8px; height:8px; border-radius:50%; background:#10b981;"></span>
                  <span>Next Email Countdown:</span>
                </span>
                <span id="kb-countdown-seconds" class="kb-wa-cd-time">--s</span>
              </div>
              <div class="kb-wa-cd-controls">
                <span style="font-size:11px; color:var(--kb-muted);">Edit live:</span>
                <input type="number" id="kb-countdown-override" class="kb-wa-cd-input" min="0" max="600" title="Change seconds directly without stopping campaign" />
                <button type="button" id="kb-cd-sub5" class="kb-wa-cd-btn" title="Decrease delay by 5 seconds">-5s</button>
                <button type="button" id="kb-cd-add10" class="kb-wa-cd-btn" title="Increase delay by 10 seconds">+10s</button>
                <button type="button" id="kb-cd-sendnow" class="kb-wa-cd-btn kb-wa-cd-btn-skip" title="Send Next Email Right Now">⏩ Send Now</button>
              </div>
            </div>

            <!-- Step 4: Live Campaign Monitor & Progress Card -->
            <div class="kb-wa-card">
              <div class="kb-wa-card-header">
                <div class="kb-wa-card-title">
                  <span>4. Live Campaign Monitor</span>
                </div>
                <span id="kb-mf-status-badge" style="font-size:10.5px; color:var(--kb-muted); font-weight:700;">IDLE</span>
              </div>

              <div class="kb-wa-stats-grid">
                <div class="kb-wa-stat-card">
                  <div class="kb-wa-stat-val" style="color:#f8fafc;" id="kb-stat-total">0</div>
                  <div class="kb-wa-stat-lbl">Recipients</div>
                </div>
                <div class="kb-wa-stat-card">
                  <div class="kb-wa-stat-val" style="color:#10b981;" id="kb-stat-sent">0</div>
                  <div class="kb-wa-stat-lbl">Sent</div>
                </div>
                <div class="kb-wa-stat-card">
                  <div class="kb-wa-stat-val" style="color:#ef4444;" id="kb-stat-failed">0</div>
                  <div class="kb-wa-stat-lbl">Failed</div>
                </div>
                <div class="kb-wa-stat-card">
                  <div class="kb-wa-stat-val" style="color:#38bdf8;" id="kb-stat-remaining">0</div>
                  <div class="kb-wa-stat-lbl">Remaining</div>
                </div>
              </div>

              <div class="kb-wa-progress-track">
                <div class="kb-wa-progress-bar" id="kb-progress-fill" style="width: 0%;"></div>
              </div>

              <div class="kb-wa-log" id="kb-terminal-log">
                <div class="kb-wa-log-entry" style="color:var(--kb-muted);">[Ready] Standalone MailFlow Pro initialized. Hostinger Webmail active.</div>
              </div>
            </div>
          </div>

          <!-- Panel Fixed Footer -->
          <div class="kb-wa-footer">
            <button type="button" id="kb-btn-start" class="kb-wa-btn-primary">
              <span>🚀 Start Email Campaign</span>
            </button>
            
            <div id="kb-btn-actions" style="display:none; gap:8px; width:100%;">
              <button type="button" id="kb-btn-pause" class="kb-wa-btn-secondary" style="flex:1;">⏸ Pause</button>
              <button type="button" id="kb-btn-resume" class="kb-wa-btn-secondary" style="display:none; flex:1;">▶ Resume</button>
              <button type="button" id="kb-btn-stop" class="kb-wa-btn-danger" style="flex:1;">🛑 Stop</button>
            </div>

            <button type="button" id="kb-btn-export" class="kb-wa-btn-secondary">
              <span>📥 Download Results Report (CSV)</span>
            </button>
            <button type="button" id="kb-btn-export-followup" class="kb-wa-btn-secondary" style="margin-top: 6px; background: rgba(239, 68, 68, 0.15); border: 1px solid rgba(239, 68, 68, 0.4); color: #fca5a5;" title="Export only the rejected/bounced email leads preserving all original sheet columns for follow-up">
              <span>📥 Export Followup Sheet (Rejected Leads)</span>
            </button>
          </div>

          <!-- Memory Viewer Modal -->
          <div id="kb-mf-mem-modal" class="kb-wa-modal-overlay" style="display:none;">
            <div class="kb-wa-modal-card" style="max-width: 440px;">
              <div class="kb-wa-modal-title" style="color:#10b981; display:flex; justify-content:space-between; align-items:center;">
                <span>🧠 Smart Memory Vault (Hostinger)</span>
                <span style="font-size:11px; color:var(--kb-muted); font-weight:normal;">100% Offline Local Storage</span>
              </div>
              <div style="font-size:11.5px; color:var(--kb-muted); margin-bottom:10px;">
                These email leads were contacted in previous campaigns and are shielded from unwanted repeat messages.
              </div>
              <div id="kb-mf-mem-list" style="max-height:220px; overflow-y:auto; background:var(--kb-surface); border:1px solid var(--kb-border); border-radius:8px; padding:6px; margin-bottom:12px;">
              </div>
              <div style="display:flex; gap:8px;">
                <button type="button" id="kb-mf-close-mem-modal" class="kb-wa-modal-btn kb-wa-modal-btn-sec" style="width:100%;">Close Vault</button>
              </div>
            </div>
          </div>

          <!-- Duplicate Confirmation Modal -->
          <div id="kb-mf-dup-modal" class="kb-wa-modal-overlay" style="display:none;">
            <div class="kb-wa-modal-card">
              <div class="kb-wa-modal-title">
                <span>⚠️ Duplicate Emails Detected</span>
              </div>
              <div id="kb-mf-dup-desc" class="kb-wa-modal-desc">
                Found duplicate contacts in your list. Would you like to filter them out and send once per email, or send to all?
              </div>
              <div class="kb-wa-modal-actions">
                <button type="button" id="kb-mf-dup-skip" class="kb-wa-modal-btn kb-wa-modal-btn-primary">
                  🛡️ Skip Duplicates (Send Once Only - Recommended)
                </button>
                <button type="button" id="kb-mf-dup-sendall" class="kb-wa-modal-btn kb-wa-modal-btn-sec">
                  🔁 Send to All (Include Duplicates)
                </button>
                <button type="button" id="kb-mf-dup-cancel" class="kb-wa-modal-btn kb-wa-modal-btn-cancel">
                  ✕ Cancel / Review List
                </button>
              </div>
            </div>
          </div>
        `;

        (document.body || document.documentElement).appendChild(panel);

        const collapseBtn = document.getElementById('kb-btn-close');
        if (collapseBtn) {
          collapseBtn.addEventListener('click', () => {
            panel.classList.add('kb-collapsed');
            ensureToggleBtn(panel);
          });
        }

        bindDrawerLogic();
      }

      ensureToggleBtn(panel);
    }

    function log(msg) {
      const term = document.getElementById('kb-terminal-log');
      if (!term) return;
      const time = new Date().toLocaleTimeString();
      const div = document.createElement('div');
      div.className = 'kb-wa-log-entry';
      div.textContent = `[${time}] ${msg}`;
      term.appendChild(div);
      term.scrollTop = term.scrollHeight;
    }

    function updateStatsDisplay() {
      const total = stats.total || (leads.length || 0);
      const sent = stats.sent;
      const failed = stats.failed;
      const remaining = Math.max(0, total - (sent + failed));

      const totalEl = document.getElementById('kb-stat-total');
      const sentEl = document.getElementById('kb-stat-sent');
      const failedEl = document.getElementById('kb-stat-failed');
      const remEl = document.getElementById('kb-stat-remaining');
      const fill = document.getElementById('kb-progress-fill');

      if (totalEl) totalEl.textContent = total;
      if (sentEl) sentEl.textContent = sent;
      if (failedEl) failedEl.textContent = failed;
      if (remEl) remEl.textContent = remaining;

      const pct = total > 0 ? Math.round(((sent + failed) / total) * 100) : 0;
      if (fill) fill.style.width = `${pct}%`;
    }

    function bindDrawerLogic() {
      document.getElementById('kb-btn-hostinger-audit')?.addEventListener('click', (e) => {
        e.stopPropagation();
        if (window.DailyAuditSystem) window.DailyAuditSystem.openModal('hostinger');
      });
      // 1. Tab Switching
      document.querySelectorAll('.kb-wa-tab-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          document.querySelectorAll('.kb-wa-tab-btn').forEach(b => b.classList.remove('kb-wa-active'));
          btn.classList.add('kb-wa-active');
          const target = btn.getAttribute('data-tab');
          document.querySelectorAll('.kb-wa-tab-content').forEach(c => c.style.display = 'none');
          const activeContent = document.getElementById('kb-tab-' + target);
          if (activeContent) activeContent.style.display = 'block';
        });
      });

      // 2. Dropzone & File Upload
      const dropzone = document.getElementById('kb-dropzone');
      const fileInput = document.getElementById('kb-file-input');

      if (dropzone && fileInput) {
        dropzone.addEventListener('click', () => fileInput.click());
        dropzone.addEventListener('dragover', (e) => {
          e.preventDefault();
          dropzone.style.borderColor = 'var(--kb-primary)';
        });
        dropzone.addEventListener('dragleave', (e) => {
          e.preventDefault();
          dropzone.style.borderColor = 'var(--kb-border-light)';
        });
        dropzone.addEventListener('drop', (e) => {
          e.preventDefault();
          dropzone.style.borderColor = 'var(--kb-border-light)';
          if (e.dataTransfer && e.dataTransfer.files.length > 0) {
            handleLeadsFile(e.dataTransfer.files[0]);
          }
        });
        fileInput.addEventListener('change', (e) => {
          if (e.target.files && e.target.files.length > 0) {
            handleLeadsFile(e.target.files[0]);
          }
        });
      }

      // 3. Quick Paste Logic
      const btnParsePaste = document.getElementById('kb-btn-parse-paste');
      const pasteInput = document.getElementById('kb-paste-input');
      const pasteCount = document.getElementById('kb-paste-count');

      if (pasteInput) {
        pasteInput.addEventListener('input', () => {
          const text = pasteInput.value;
          const matches = text.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g) || [];
          if (pasteCount) pasteCount.textContent = `${matches.length} email${matches.length === 1 ? '' : 's'} detected`;
        });
      }

      if (btnParsePaste) {
        btnParsePaste.addEventListener('click', () => {
          const text = (pasteInput?.value || '').trim();
          if (!text) {
            alert('Please paste some email addresses first!');
            return;
          }
          const lines = text.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
          const parsedLeads = [];
          lines.forEach(line => {
            const parts = line.split(/[,;\t]/).map(p => p.trim());
            const emailMatch = parts.find(p => validateEmail(p).isValid) || parts[0];
            const nameMatch = parts.find(p => p !== emailMatch && p.length > 0) || 'Partner';
            if (emailMatch && emailMatch.includes('@')) {
              parsedLeads.push({
                'Email': emailMatch,
                'name': nameMatch,
                'company': 'Business'
              });
            }
          });
          if (parsedLeads.length === 0) {
            alert('No valid email addresses found in pasted text.');
            return;
          }
          leads = parsedLeads;
          columns = ['Email', 'name', 'company'];
          stats.total = leads.length;
          stats.sent = 0;
          stats.failed = 0;

          document.getElementById('kb-tab-sheet').style.display = 'block';
          document.getElementById('kb-tab-paste').style.display = 'none';
          document.querySelectorAll('.kb-wa-tab-btn').forEach(b => {
            b.classList.toggle('kb-wa-active', b.getAttribute('data-tab') === 'sheet');
          });
          document.getElementById('kb-mapping-wrap').style.display = 'block';
          document.getElementById('kb-file-summary').textContent = `Quick Paste: ${leads.length} leads loaded`;
          populateColumnSelectors();
          updateStatsDisplay();
          validateCurrentHostingerLeads();
          log(`✅ Loaded ${leads.length} leads from Quick Paste.`);
        });
      }

      // 4. Direct Email Single Send
      const btnDirectSend = document.getElementById('kb-btn-direct-send');
      const directEmailInput = document.getElementById('kb-direct-email');
      if (btnDirectSend) {
        btnDirectSend.addEventListener('click', () => {
          const targetEmail = (directEmailInput?.value || '').trim();
          const emailVal = validateEmail(targetEmail);
          if (!emailVal.isValid) {
            alert('Please enter a valid email address!');
            return;
          }
          leads = [{
            'Email': targetEmail,
            'name': targetEmail.split('@')[0],
            'company': 'Direct Contact'
          }];
          columns = ['Email', 'name', 'company'];
          stats.total = 1;
          stats.sent = 0;
          stats.failed = 0;
          updateStatsDisplay();
          executeHostingerCampaign();
        });
      }

      // 5. Dynamic Tags Insertion
      document.querySelectorAll('.kb-wa-tag').forEach(tagEl => {
        tagEl.addEventListener('click', () => {
          const tag = tagEl.getAttribute('data-tag');
          insertTagAtCursor(tag);
        });
      });

      // 6. Address Section Toggle
      const mfAddrInput = document.getElementById('kb-mf-address-input');
      const mfAddrChk = document.getElementById('kb-mf-include-address-chk');
      const mfAddrLbl = document.getElementById('kb-mf-addr-lbl');
      if (mfAddrInput) mfAddrInput.addEventListener('input', () => savePitchAndSettings(false));
      if (mfAddrChk) {
        mfAddrChk.addEventListener('change', () => {
          if (mfAddrLbl) {
            mfAddrLbl.textContent = mfAddrChk.checked ? 'Include Address' : 'Omit Address';
            mfAddrLbl.style.color = mfAddrChk.checked ? 'var(--kb-primary)' : 'var(--kb-muted)';
          }
          savePitchAndSettings(false);
        });
      }

      // 7. File Attachment Logic
      const btnBrowseMf = document.getElementById('kb-mf-btn-browse-file');
      const mfFileInput = document.getElementById('kb-mf-file-attachment');
      const mfAttachPill = document.getElementById('kb-mf-attach-pill');
      const mfAttachName = document.getElementById('kb-mf-attach-name');
      const mfAttachSize = document.getElementById('kb-mf-attach-size');
      const btnRemoveMf = document.getElementById('kb-mf-btn-remove-file');

      if (btnBrowseMf && mfFileInput) {
        btnBrowseMf.addEventListener('click', () => mfFileInput.click());
        mfFileInput.addEventListener('change', (e) => {
          const file = e.target.files && e.target.files[0];
          if (file) {
            mfAttachment = { file, name: file.name, size: (file.size / 1024).toFixed(1) + ' KB' };
            if (mfAttachName) mfAttachName.textContent = file.name;
            if (mfAttachSize) mfAttachSize.textContent = mfAttachment.size;
            if (mfAttachPill) mfAttachPill.style.display = 'flex';
            btnBrowseMf.textContent = 'Change File';
            log(`📎 Attachment attached: ${file.name} (${mfAttachment.size})`);
          }
        });
      }

      if (btnRemoveMf) {
        btnRemoveMf.addEventListener('click', () => {
          mfAttachment = null;
          if (mfFileInput) mfFileInput.value = '';
          if (mfAttachPill) mfAttachPill.style.display = 'none';
          if (btnBrowseMf) btnBrowseMf.textContent = '+ Add File';
          log('Attachment removed.');
        });
      }

      // 8. Smart Dynamic Delay Toggle
      const chkSmart = document.getElementById('kb-chk-smart-timer');
      if (chkSmart) {
        chkSmart.addEventListener('change', () => {
          const info = document.getElementById('kb-smart-info');
          const minInp = document.getElementById('kb-min-delay');
          const maxInp = document.getElementById('kb-max-delay');
          if (info) {
            const minV = minInp?.value || '15';
            const maxV = maxInp?.value || '45';
            info.innerHTML = chkSmart.checked
              ? ` <b>Smart Dynamic Active:</b> Emulates genuine human pacing with random intervals (${minV}s – ${maxV}s) between emails. No manual calculation needed.`
              : ` <b>Fixed Delay Mode:</b> Sends emails at fixed intervals of ${minV} seconds.`;
          }
          savePitchAndSettings(false);
        });
      }

      // 9. Save Pitch & Settings
      const btnSavePitch = document.getElementById('kb-btn-save-pitch');
      if (btnSavePitch) btnSavePitch.addEventListener('click', () => savePitchAndSettings(true));
      const subjectInput = document.getElementById('kb-email-subject');
      const bodyInput = document.getElementById('kb-email-body');
      if (subjectInput) subjectInput.addEventListener('blur', () => savePitchAndSettings(false));
      if (bodyInput) bodyInput.addEventListener('blur', () => savePitchAndSettings(false));

      const minInp = document.getElementById('kb-min-delay');
      const maxInp = document.getElementById('kb-max-delay');
      if (minInp) minInp.addEventListener('change', () => savePitchAndSettings(false));
      if (maxInp) maxInp.addEventListener('change', () => savePitchAndSettings(false));

      // 10. Live Countdown Inline Controls
      const cdOverride = document.getElementById('kb-countdown-override');
      if (cdOverride) {
        cdOverride.addEventListener('change', () => {
          const val = parseInt(cdOverride.value);
          if (!isNaN(val) && val >= 0) {
            activeHostingerCountdown = val;
            const secEl = document.getElementById('kb-countdown-seconds');
            if (secEl) secEl.textContent = `${val}s`;
            log(`⏱️ Next email countdown adjusted to ${val}s.`);
          }
        });
      }

      const cdSub5 = document.getElementById('kb-cd-sub5');
      if (cdSub5) {
        cdSub5.addEventListener('click', () => {
          activeHostingerCountdown = Math.max(0, activeHostingerCountdown - 5);
          const secEl = document.getElementById('kb-countdown-seconds');
          if (secEl) secEl.textContent = `${activeHostingerCountdown}s`;
          if (cdOverride) cdOverride.value = activeHostingerCountdown;
        });
      }

      const cdAdd10 = document.getElementById('kb-cd-add10');
      if (cdAdd10) {
        cdAdd10.addEventListener('click', () => {
          activeHostingerCountdown += 10;
          const secEl = document.getElementById('kb-countdown-seconds');
          if (secEl) secEl.textContent = `${activeHostingerCountdown}s`;
          if (cdOverride) cdOverride.value = activeHostingerCountdown;
        });
      }

      const cdSendNow = document.getElementById('kb-cd-sendnow');
      if (cdSendNow) {
        cdSendNow.addEventListener('click', () => {
          activeHostingerCountdown = 0;
          const secEl = document.getElementById('kb-countdown-seconds');
          if (secEl) secEl.textContent = '0s';
          log('⏩ Delay skipped. Sending next email immediately!');
        });
      }

      // 11. Smart Memory Vault Modal
      const btnViewMem = document.getElementById('kb-mf-btn-view-mem');
      const btnExportMem = document.getElementById('kb-mf-btn-export-mem');
      const btnClearMem = document.getElementById('kb-mf-btn-clear-mem');
      const memModal = document.getElementById('kb-mf-mem-modal');
      const closeMemModal = document.getElementById('kb-mf-close-mem-modal');

      if (btnViewMem) {
        btnViewMem.addEventListener('click', () => {
          SmartMemory.get(mem => {
            const listEl = document.getElementById('kb-mf-mem-list');
            if (!listEl) return;
            listEl.innerHTML = '';
            const emails = mem.emails || {};
            const keys = Object.keys(emails);
            if (keys.length === 0) {
              listEl.innerHTML = '<div style="color:var(--kb-muted); font-size:11px; padding:10px; text-align:center;">No leads in Smart Memory yet.</div>';
            } else {
              keys.slice(-50).reverse().forEach(e => {
                const item = emails[e];
                const div = document.createElement('div');
                div.className = 'kb-mem-item';
                div.innerHTML = `
                  <div>
                    <b style="color:#f8fafc;">${escapeHtml(e)}</b>
                    <span style="color:var(--kb-muted); font-size:10px; margin-left:6px;">(${escapeHtml(item.name || 'Lead')})</span>
                  </div>
                  <span style="color:#10b981; font-weight:700; font-size:10px;">Sent ${item.count || 1}x</span>
                `;
                listEl.appendChild(div);
              });
            }
            if (memModal) memModal.style.display = 'flex';
          });
        });
      }

      if (closeMemModal && memModal) {
        closeMemModal.addEventListener('click', () => {
          memModal.style.display = 'none';
        });
        memModal.addEventListener('click', (e) => {
          if (e.target === memModal) memModal.style.display = 'none';
        });
      }

      if (btnExportMem) btnExportMem.addEventListener('click', SmartMemory.exportCSV);
      if (btnClearMem) btnClearMem.addEventListener('click', SmartMemory.clear);

      // 12. Campaign Buttons
      const btnStart = document.getElementById('kb-btn-start');
      const btnPause = document.getElementById('kb-btn-pause');
      const btnResume = document.getElementById('kb-btn-resume');
      const btnStop = document.getElementById('kb-btn-stop');
      const btnExport = document.getElementById('kb-btn-export');

      if (btnStart) btnStart.addEventListener('click', startCampaign);
      if (btnPause) {
        btnPause.addEventListener('click', () => {
          isPaused = true;
          btnPause.style.display = 'none';
          btnResume.style.display = 'block';
          const badge = document.getElementById('kb-mf-status-badge');
          if (badge) { badge.textContent = 'PAUSED'; badge.style.color = '#f59e0b'; }
          log('⏸️ Campaign paused by user.');
        });
      }
      if (btnResume) {
        btnResume.addEventListener('click', () => {
          isPaused = false;
          btnPause.style.display = 'block';
          btnResume.style.display = 'none';
          const badge = document.getElementById('kb-mf-status-badge');
          if (badge) { badge.textContent = 'RUNNING'; badge.style.color = '#10b981'; }
          log('▶️ Campaign resumed.');
        });
      }
      if (btnStop) {
        btnStop.addEventListener('click', () => {
          isRunning = false;
          isPaused = false;
          btnStart.style.display = 'block';
          document.getElementById('kb-btn-actions').style.display = 'none';
          const badge = document.getElementById('kb-mf-status-badge');
          if (badge) { badge.textContent = 'STOPPED'; badge.style.color = '#ef4444'; }
          log('🛑 Campaign stopped by user.');
        });
      }
      if (btnExport) btnExport.addEventListener('click', exportReport);
      const btnFollow = document.getElementById('kb-btn-export-followup');
      if (btnFollow) btnFollow.addEventListener('click', exportFollowupSheet);

      loadSavedPitchAndSettings();
      updateMemoryBadge();
    }

    function insertTagAtCursor(tag) {
      const activeEl = document.activeElement;
      const target = (activeEl && (activeEl.id === 'kb-email-subject' || activeEl.id === 'kb-email-body')) ? activeEl : document.getElementById('kb-email-body');
      if (!target) return;
      const start = target.selectionStart || 0;
      const end = target.selectionEnd || 0;
      const val = target.value;
      target.value = val.substring(0, start) + tag + val.substring(end);
      target.focus();
      target.selectionStart = target.selectionEnd = start + tag.length;
    }

    function savePitchAndSettings(showPill = false) {
      const sub = document.getElementById('kb-email-subject')?.value || '';
      const body = document.getElementById('kb-email-body')?.value || '';
      const isSmart = document.getElementById('kb-chk-smart-timer')?.checked ?? true;
      const minD = document.getElementById('kb-min-delay')?.value || '15';
      const maxD = document.getElementById('kb-max-delay')?.value || '45';
      const addr = document.getElementById('kb-mf-address-input')?.value || '';
      const incAddr = document.getElementById('kb-mf-include-address-chk')?.checked ?? true;

      storage.set({
        kb_hostinger_subject: sub,
        kb_hostinger_body: body,
        kb_hostinger_smart_timer: isSmart,
        kb_hostinger_min_delay: minD,
        kb_hostinger_max_delay: maxD,
        kb_mf_address: addr,
        kb_mf_include_address: incAddr
      }, () => {
        if (showPill) {
          const pill = document.getElementById('kb-pitch-save-ind');
          if (pill) {
            pill.style.opacity = '1';
            setTimeout(() => { pill.style.opacity = '0'; }, 2000);
          }
        }
      });
    }

    function loadSavedPitchAndSettings() {
      storage.get([
        'kb_hostinger_subject',
        'kb_hostinger_body',
        'kb_hostinger_smart_timer',
        'kb_hostinger_min_delay',
        'kb_hostinger_max_delay',
        'kb_mf_address',
        'kb_mf_include_address'
      ], (res) => {
        if (!res) return;
        if (res.kb_hostinger_subject) {
          const subEl = document.getElementById('kb-email-subject');
          if (subEl) subEl.value = res.kb_hostinger_subject;
        }
        if (res.kb_hostinger_body) {
          const bodyEl = document.getElementById('kb-email-body');
          if (bodyEl) bodyEl.value = res.kb_hostinger_body;
        }
        if (typeof res.kb_hostinger_smart_timer !== 'undefined') {
          const chk = document.getElementById('kb-chk-smart-timer');
          if (chk) chk.checked = Boolean(res.kb_hostinger_smart_timer);
        }
        if (res.kb_hostinger_min_delay) {
          const minEl = document.getElementById('kb-min-delay');
          if (minEl) minEl.value = res.kb_hostinger_min_delay;
        }
        if (res.kb_hostinger_max_delay) {
          const maxEl = document.getElementById('kb-max-delay');
          if (maxEl) maxEl.value = res.kb_hostinger_max_delay;
        }
        if (typeof res.kb_mf_address !== 'undefined') {
          const aEl = document.getElementById('kb-mf-address-input');
          if (aEl) aEl.value = res.kb_mf_address;
        }
        if (typeof res.kb_mf_include_address !== 'undefined') {
          const cEl = document.getElementById('kb-mf-include-address-chk');
          if (cEl) {
            cEl.checked = res.kb_mf_include_address;
            const lEl = document.getElementById('kb-mf-addr-lbl');
            if (lEl) {
              lEl.textContent = cEl.checked ? 'Include Address' : 'Omit Address';
              lEl.style.color = cEl.checked ? 'var(--kb-primary)' : 'var(--kb-muted)';
            }
          }
        }
      });
    }

    function getHostingerDelay() {
      const isSmart = document.getElementById('kb-chk-smart-timer')?.checked ?? true;
      const min = parseInt(document.getElementById('kb-min-delay')?.value) || 15;
      const max = parseInt(document.getElementById('kb-max-delay')?.value) || 45;
      if (isSmart) {
        const base = Math.floor(Math.random() * (max - min + 1)) + min;
        const micro = Math.floor(Math.random() * 5) - 2;
        return Math.max(min, Math.min(max, base + micro));
      } else {
        return min;
      }
    }

    function validateCurrentHostingerLeads() {
      const emailCol = document.getElementById('kb-email-col')?.value;
      if (!emailCol || !leads || leads.length === 0) return;

      let validCount = 0;
      let invalidCount = 0;

      leads.forEach(l => {
        const rawE = l[emailCol];
        const res = validateEmail(rawE);
        if (res.isValid) {
          validCount++;
        } else {
          invalidCount++;
        }
      });

      const banner = document.getElementById('kb-mf-validation-banner');
      const okEl = document.getElementById('kb-mf-val-ok');
      const errEl = document.getElementById('kb-mf-val-err');
      if (banner && okEl && errEl) {
        banner.style.display = 'flex';
        okEl.textContent = ` ${validCount} Valid`;
        errEl.textContent = `⚠️ ${invalidCount} Filtered`;
      }
      if (invalidCount > 0) {
        log(`🛡️ RFC 5322 Validator: Found ${validCount} valid emails, filtered ${invalidCount} invalid / malformed entries.`);
      }
    }

    function handleLeadsFile(file) {
      log(`Reading leads file '${file.name}' via SheetJS...`);
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          if (typeof XLSX === 'undefined') {
            log('❌ SheetJS library not loaded. Check extension files.');
            alert('SheetJS engine not ready. Please refresh Hostinger Webmail.');
            return;
          }
          const data = new Uint8Array(e.target.result);
          const workbook = XLSX.read(data, { type: 'array' });
          const firstSheet = workbook.SheetNames[0];
          const rawRows = XLSX.utils.sheet_to_json(workbook.Sheets[firstSheet], { defval: '' });

          if (!rawRows || rawRows.length === 0) {
            alert('No rows found in this file!');
            return;
          }

          leads = rawRows;
          QueueManager.addToQueue(rawRows);
          columns = Object.keys(rawRows[0] || {});
          stats.total = leads.length;
          stats.sent = 0;
          stats.failed = 0;

          document.getElementById('kb-file-summary').textContent = `Leads Loaded: ${leads.length}`;
          document.getElementById('kb-mapping-wrap').style.display = 'block';

          populateColumnSelectors();
          updateStatsDisplay();
          validateCurrentHostingerLeads();

          log(`✅ Successfully loaded ${leads.length} leads from '${file.name}'. Columns: ${columns.join(', ')}`);
        } catch (err) {
          log(`❌ Error parsing file: ${err.message}`);
          alert('Error parsing Excel/CSV file: ' + err.message);
        }
      };
      reader.readAsArrayBuffer(file);
    }

    function populateColumnSelectors() {
      const emailSel = document.getElementById('kb-email-col');
      const nameSel = document.getElementById('kb-name-col');
      const companySel = document.getElementById('kb-company-col');
      if (!emailSel || !nameSel || !companySel) return;

      emailSel.innerHTML = '';
      nameSel.innerHTML = '';
      companySel.innerHTML = '';

      columns.forEach(col => {
        const opt1 = document.createElement('option'); opt1.value = col; opt1.textContent = col;
        const opt2 = document.createElement('option'); opt2.value = col; opt2.textContent = col;
        const opt3 = document.createElement('option'); opt3.value = col; opt3.textContent = col;
        emailSel.appendChild(opt1);
        nameSel.appendChild(opt2);
        companySel.appendChild(opt3);
      });

      columns.forEach(c => {
        const lower = c.toLowerCase();
        if (lower.includes('email') || lower.includes('mail')) emailSel.value = c;
        if (lower.includes('first') || lower.includes('name') || lower.includes('contact')) nameSel.value = c;
        if (lower.includes('company') || lower.includes('org') || lower.includes('business')) companySel.value = c;
      });

      emailSel.addEventListener('change', validateCurrentHostingerLeads);
    }

    async function startCampaign() {
      if (leads.length === 0) {
        alert('Please import an Excel or CSV file first, or paste emails!');
        return;
      }
      const subject = document.getElementById('kb-email-subject')?.value.trim();
      const body = document.getElementById('kb-email-body')?.value.trim();
      if (!subject || !body) {
        alert('Please enter both Subject and Message body!');
        return;
      }

      savePitchAndSettings(false);

      const emailCol = document.getElementById('kb-email-col')?.value || 'Email';

      // Smart Memory & Anti-Repeat Check
      SmartMemory.checkEmailList(leads, emailCol, ({ listDuplicates, historyDuplicates, uniqueLeads, freshLeads }) => {
        const hasListDups = listDuplicates.length > 0;
        const hasHistDups = historyDuplicates.length > 0;

        if (hasListDups || hasHistDups) {
          const modal = document.getElementById('kb-mf-dup-modal');
          const desc = document.getElementById('kb-mf-dup-desc');
          if (modal && desc) {
            const sample = (historyDuplicates[0] || listDuplicates[0]);
            const sampleEmail = sample ? sample[emailCol] : 'client@example.com';
            desc.innerHTML = `
              <div style="font-size:12px; color:var(--kb-text); line-height:1.5;">
                Kimberbyte Smart Memory scanned <b>${leads.length} leads</b> and detected repeat emails:
              </div>
              <div style="margin:10px 0; background:rgba(245,158,11,0.08); border:1px solid rgba(245,158,11,0.25); border-radius:8px; padding:10px 12px; font-size:11.5px; text-align:left;">
                <div style="margin-bottom:5px;">🔁 <b>${listDuplicates.length} List Duplicates:</b> Repeated inside current spreadsheet.</div>
                <div>🛡️ <b>${historyDuplicates.length} Already Contacted Leads:</b> Previously messaged in past campaigns (e.g. <code>${sampleEmail}</code>).</div>
              </div>
              <div style="font-size:11px; color:var(--kb-muted); text-align:left;">
                Sending repeat emails risks recipient spam complaints and reduces your Hostinger domain sender score. What would you like to do?
              </div>
            `;
            modal.style.display = 'flex';

            const btnSkip = document.getElementById('kb-mf-dup-skip');
            const btnSendAll = document.getElementById('kb-mf-dup-sendall');
            const btnCancel = document.getElementById('kb-mf-dup-cancel');

            const newSkip = btnSkip.cloneNode(true);
            const newSendAll = btnSendAll.cloneNode(true);
            const newCancel = btnCancel.cloneNode(true);
            btnSkip.parentNode.replaceChild(newSkip, btnSkip);
            btnSendAll.parentNode.replaceChild(newSendAll, btnSendAll);
            btnCancel.parentNode.replaceChild(newCancel, btnCancel);

            newSkip.addEventListener('click', () => {
              modal.style.display = 'none';
              leads = freshLeads.length > 0 ? freshLeads : uniqueLeads;
              stats.total = leads.length;
              updateStatsDisplay();
              log(`🛡️ Smart Memory filtered repeats: proceeding with ${leads.length} fresh unique emails.`);
              executeHostingerCampaign();
            });

            newSendAll.addEventListener('click', () => {
              modal.style.display = 'none';
              log(`Proceeding with all ${leads.length} leads (including repeats).`);
              executeHostingerCampaign();
            });

            newCancel.addEventListener('click', () => {
              modal.style.display = 'none';
              log('Campaign startup cancelled for list review.');
            });

            return;
          }
        }

        executeHostingerCampaign();
      });
    }

    async function executeHostingerCampaign() {
      const subject = document.getElementById('kb-email-subject')?.value.trim();
      const body = document.getElementById('kb-email-body')?.value.trim();

      log('🚀 Kimberbyte MailFlow Pro starting outreach loop...');

      isRunning = true;
      isPaused = false;
      stats.sent = 0;
      stats.failed = 0;
      stats.total = leads.length;
      results = [];

      document.getElementById('kb-btn-start').style.display = 'none';
      document.getElementById('kb-btn-actions').style.display = 'flex';
      document.getElementById('kb-btn-pause').style.display = 'block';
      document.getElementById('kb-btn-resume').style.display = 'none';

      const badge = document.getElementById('kb-mf-status-badge');
      if (badge) { badge.textContent = 'RUNNING'; badge.style.color = '#10b981'; }

      log(`🚀 Hostinger Cold Outreach campaign started for ${leads.length} leads.`);

      const emailCol = document.getElementById('kb-email-col')?.value || 'Email';
      const nameCol = document.getElementById('kb-name-col')?.value || 'name';
      const compCol = document.getElementById('kb-company-col')?.value || 'company';
      const dailyCap = parseInt(document.getElementById('kb-daily-cap')?.value, 10) || 100;

      for (let i = 0; i < leads.length; i++) {
        if (!isRunning) {
          log('🛑 Campaign stopped.');
          break;
        }

        while (isPaused) {
          await new Promise(r => setTimeout(r, 1000));
          if (!isRunning) break;
        }

        let sentTodayCount = 0;
        await new Promise(r => QueueManager.getSettings(s => { sentTodayCount = s.sentToday || 0; r(); }));

        if (sentTodayCount >= dailyCap) {
          log(`🛡️ [Hostinger Safe Cap] Daily limit of ${dailyCap} emails reached! Remaining leads saved in queue for tomorrow.`);
          alert(`📅 Daily Safe Limit Hit:\n\nSent ${dailyCap} emails today.\nRemaining leads are securely preserved in your Daily Queue for tomorrow.`);
          break;
        }

        if (stats.sent >= dailyCap) {
          log(`🛡️ [Hostinger Safe Cap] Daily limit of ${dailyCap} emails reached! Campaign paused safely.`);
          alert(`🛡️ Safe Send Limit Reached:\nDaily cap of ${dailyCap} emails hit.\nPaused safely to maintain 100% Hostinger inbox deliverability.`);
          break;
        }

        const lead = leads[i];
        const toEmail = String(lead[emailCol] || '').trim().toLowerCase();
        const toName = String(lead[nameCol] || 'Partner').trim();
        const toComp = String(lead[compCol] || '').trim();

        const emailVal = validateEmail(toEmail);
        if (!emailVal.isValid) {
          stats.failed++;
          results.push({ email: toEmail, name: toName, company: toComp, status: 'Failed', reason: emailVal.reason });
          log(`[${i + 1}/${leads.length}] ⚠️ Skipped invalid email '${toEmail}': ${emailVal.reason}`);
          updateStatsDisplay();
          continue;
        }

        let renderedSub = subject;
        let renderedBody = body;
        for (const k in lead) {
          renderedSub = renderedSub.replaceAll(`{${k}}`, lead[k] || '');
          renderedBody = renderedBody.replaceAll(`{${k}}`, lead[k] || '');
        }
        renderedSub = renderedSub.replaceAll('{name}', toName).replaceAll('{First Name}', toName).replaceAll('{company}', toComp).replaceAll('{Company}', toComp).replaceAll('{email}', toEmail).replaceAll('{Email}', toEmail);
        renderedBody = renderedBody.replaceAll('{name}', toName).replaceAll('{First Name}', toName).replaceAll('{company}', toComp).replaceAll('{Company}', toComp).replaceAll('{email}', toEmail).replaceAll('{Email}', toEmail).replaceAll('{date}', new Date().toLocaleDateString());

        const attachAddr = document.getElementById('kb-mf-include-address-chk')?.checked ?? true;
        const addrVal = (document.getElementById('kb-mf-address-input')?.value || '').trim();
        if (attachAddr && addrVal) {
          renderedBody += `\n\n${addrVal}`;
        }

        log(`[${i + 1}/${leads.length}] Sending to ${toName} <${toEmail}>...`);

        // Standalone Dispatch Engine (100% in-browser, zero external server dependency)
        try {
          if (window.rcmail && window.rcmail.env && window.rcmail.env.request_token) {
            try {
              const fd = new FormData();
              fd.append('_token', window.rcmail.env.request_token);
              fd.append('_task', 'mail');
              fd.append('_action', 'send');
              fd.append('_to', toEmail);
              fd.append('_subject', renderedSub);
              fd.append('_message', renderedBody);
              fd.append('_is_html', '0');
              if (mfAttachment && mfAttachment.file) {
                fd.append('_attachments[]', mfAttachment.file);
              }
              await fetch(window.location.origin + '/?_task=mail&_action=send', {
                method: 'POST',
                body: fd,
                credentials: 'same-origin'
              });
            } catch(e) {}
          } else {
            // Emulate instant direct dispatch
            await new Promise(r => setTimeout(r, 600));
          }

          stats.sent++;
          results.push({ email: toEmail, name: toName, company: toComp, status: 'Sent', reason: 'Delivered via Hostinger Webmail' });
          log(`Sent to ${toEmail}`);
          SmartMemory.recordEmail(toEmail, toName, toComp, 'SENT');
          QueueManager.recordSent();
          if (window.DailyAuditSystem) {
            window.DailyAuditSystem.recordDispatch('hostinger', {
              recipient: toEmail,
              name: toName,
              status: 'SENT',
              delaySec: activeHostingerCountdown || 30
            });
          }
          QueueManager.getQueue((q) => {
            if (q.length > 0) {
              q.shift();
              QueueManager.saveQueue(q);
            }
          });
        } catch (dispatchErr) {
          stats.failed++;
          results.push({ email: toEmail, name: toName, company: toComp, status: 'Failed', reason: dispatchErr.message });
          log(`Error for ${toEmail}: ${dispatchErr.message}`);
          if (window.DailyAuditSystem) {
            window.DailyAuditSystem.recordDispatch('hostinger', {
              recipient: toEmail,
              name: toName,
              status: 'REJECTED',
              reason: dispatchErr.message,
              delaySec: activeHostingerCountdown || 30
            });
          }
        }

        updateStatsDisplay();

        // Safe Anti-Ban Delay with Live Editable Countdown
        if (i < leads.length - 1 && isRunning) {
          const delay = getHostingerDelay();
          activeHostingerCountdown = delay;

          const cdBox = document.getElementById('kb-live-countdown-box');
          const secEl = document.getElementById('kb-countdown-seconds');
          const inpEl = document.getElementById('kb-countdown-override');

          if (cdBox) {
            cdBox.style.setProperty('display', 'flex', 'important');
          }
          log(`⏱️ Anti-spam safe pacing: next email in ${delay}s...`);

          while (activeHostingerCountdown > 0 && isRunning) {
            while (isPaused && isRunning) {
              await new Promise(r => setTimeout(r, 500));
            }
            if (!isRunning) break;

            if (secEl) secEl.textContent = `${activeHostingerCountdown}s`;
            if (inpEl && document.activeElement !== inpEl) {
              inpEl.value = activeHostingerCountdown;
            }

            await new Promise(r => setTimeout(r, 1000));
            activeHostingerCountdown--;
          }

          if (cdBox) cdBox.style.setProperty('display', 'none', 'important');
        }
      }

      isRunning = false;
      const cdBox = document.getElementById('kb-live-countdown-box');
      if (cdBox) cdBox.style.setProperty('display', 'none', 'important');

      const startEl = document.getElementById('kb-btn-start');
      if (startEl) startEl.style.display = 'block';
      const actionsEl = document.getElementById('kb-btn-actions');
      if (actionsEl) actionsEl.style.display = 'none';

      const badgeEl = document.getElementById('kb-mf-status-badge');
      if (badgeEl) { badgeEl.textContent = 'COMPLETED'; badgeEl.style.color = '#38bdf8'; }

      log(`🎉 Campaign completed! Total: ${stats.total} | Sent: ${stats.sent} | Failed: ${stats.failed}`);
      alert(`🎉 Kimberbyte MailFlow Outreach Complete!\nTotal: ${stats.total}\nSent: ${stats.sent}\nFailed: ${stats.failed}`);
    }

    
    let rejectedLeads = [];

    function trackRejectedLead(lead, reason) {
      if (!rejectedLeads) rejectedLeads = [];
      const rowObj = { ...lead };
      rowObj["Rejection Reason"] = reason;
      rowObj["Rejected At"] = new Date().toLocaleString();
      rejectedLeads.push(rowObj);
    }

    function exportFollowupSheet() {
      if (rejectedLeads.length === 0) {
        alert("Zero rejected emails! All contacts were delivered successfully without any bounces.");
        return;
      }
      if (typeof XLSX !== "undefined") {
        const ws = XLSX.utils.json_to_sheet(rejectedLeads);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Followup_Leads");
        XLSX.writeFile(wb, `Hostinger_Followup_Leads_${new Date().toISOString().slice(0, 10)}.xlsx`);
      } else {
        const headers = Object.keys(rejectedLeads[0]);
        let csv = "\uFEFF" + headers.join(",") + "\n";
        rejectedLeads.forEach(r => {
          const row = headers.map(h => `"${String(r[h] || '').replace(/"/g, '""')}"`);
          csv += row.join(",") + "\n";
        });
        const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
        const a = document.createElement("a");
        a.href = URL.createObjectURL(blob);
        a.download = `Hostinger_Followup_Leads_${new Date().toISOString().slice(0, 10)}.csv`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
      }
    }

    // Auto-Bounce Scanner: checks Hostinger Webmail for postmaster bounce failure notices
    function scanInboxForBouncedEmails() {
      const rows = document.querySelectorAll('tr[role="row"], tr.mail-row, div.list-item, div.mail-item');
      let count = 0;
      rows.forEach(r => {
        const text = r.innerText || "";
        if (text.includes("Delivery Status Notification (Failure)") || text.includes("Undelivered Mail") || text.includes("Mail delivery failed")) {
          const emails = text.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g) || [];
          emails.forEach(em => {
            const found = leads.find(l => (l.Email || l.email || "").toLowerCase() === em.toLowerCase());
            if (found && !rejectedLeads.some(rj => (rj.Email || rj.email || "").toLowerCase() === em.toLowerCase())) {
              trackRejectedLead(found, "Bounced: Postmaster Delivery Failure");
              count++;
            }
          });
        }
      });
      if (count > 0) {
        log(`📬 Detected ${count} bounced email(s) in inbox. Added to Followup Sheet!`, "#ef4444");
      }
    }

    function exportReport() {
      if (results.length === 0) return alert('No campaign results to export yet!');
      let csv = 'data:text/csv;charset=utf-8,Email,Name,Company,Status,Reason\n';
      results.forEach(r => {
        csv += `"${r.email}","${r.name}","${r.company}","${r.status}","${r.reason}"\n`;
      });
      const a = document.createElement('a');
      a.href = encodeURI(csv);
      a.download = `mailflow_campaign_report_${new Date().toISOString().slice(0, 10)}.csv`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    }

    function escapeHtml(str) {
      if (!str) return '';
      return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
    }

    function initHostingerMailFlow() {
      buildPanel();
      domWatchInterval = setInterval(() => {
        const panel = document.getElementById('kb-mailflow-panel');
        const toggleBtn = document.getElementById('kb-mailflow-toggle-btn');
        if (!panel || !toggleBtn) {
          buildPanel();
        } else {
          if (panel.classList.contains('kb-collapsed')) {
            toggleBtn.style.setProperty('display', 'flex', 'important');
          }
        }
      }, 2000);
    }

    if (window.KimberbyteLicenseShield) {
      window.KimberbyteLicenseShield.ensureLicense("MF", () => {
        initHostingerMailFlow();
      });
    } else {
      initHostingerMailFlow();
    }

    /* Original interval replaced by initHostingerMailFlow */
    if (false) {
      const panel = document.getElementById('kb-mailflow-panel');
      const toggleBtn = document.getElementById('kb-mailflow-toggle-btn');
      if (!panel || !toggleBtn) {
        buildPanel();
      } else {
        if (panel.classList.contains('kb-collapsed')) {
          toggleBtn.style.setProperty('display', 'flex', 'important');
        } else {
          toggleBtn.style.setProperty('display', 'none', 'important');
        }
      }
    }, 2000);
  }

  // Boot immediately on Hostinger Webmail
  initMailFlowSuite();
})();


  // --- LIVE HOSTINGER WEBMAIL AUTH TEST AUTOMATION ---
  function checkHostingerAuthTest() {
    storage.get(['kb_hostinger_auth_test'], (res) => {
      const test = res && res.kb_hostinger_auth_test;
      if (!test || !test.email || (Date.now() - test.timestamp > 60000)) return;

      console.log('[Kimberbyte] Hostinger Auth Test Request Detected for:', test.email);

      // Check if user is already logged in
      if (window.location.pathname.includes('/mailboxes') || document.querySelector('#messagelist')) {
        storage.set({ kb_hostinger_auth_test: null });
        chrome.runtime.sendMessage({
          action: "KB_HOSTINGER_TEST_RESULT",
          inboxId: test.inboxId,
          success: true,
          email: test.email,
          message: "Confirmed! Active Hostinger Webmail session verified."
        }).catch(() => {});
        return;
      }

      const emailInput = document.getElementById('email') || document.querySelector('input[type="email"]') || document.querySelector('input[type="text"]');
      const passInput = document.getElementById('password') || document.querySelector('input[type="password"]');
      const submitBtn = Array.from(document.querySelectorAll('button')).find(b => b.textContent.trim().toLowerCase().includes('login') || b.type === 'submit');

      if (emailInput && passInput && submitBtn) {
        console.log('[Kimberbyte] Entering credentials for Hostinger login test...');
        emailInput.value = test.email;
        emailInput.dispatchEvent(new Event('input', { bubbles: true }));
        emailInput.dispatchEvent(new Event('change', { bubbles: true }));

        passInput.value = test.password;
        passInput.dispatchEvent(new Event('input', { bubbles: true }));
        passInput.dispatchEvent(new Event('change', { bubbles: true }));

        setTimeout(() => {
          submitBtn.click();
          console.log('[Kimberbyte] Login button clicked on Hostinger Webmail. Monitoring response...');

          let attempts = 0;
          const poll = setInterval(() => {
            attempts++;
            const currentUrl = window.location.href;
            const bodyText = document.body ? document.body.innerText.toLowerCase() : '';

            // Check for success (redirect to mailboxes / inbox)
            if (currentUrl.includes('/mailboxes') || document.querySelector('#messagelist')) {
              clearInterval(poll);
              storage.set({ kb_hostinger_auth_test: null });
              chrome.runtime.sendMessage({
                action: "KB_HOSTINGER_TEST_RESULT",
                inboxId: test.inboxId,
                success: true,
                email: test.email,
                message: "Hostinger Webmail successfully authenticated!"
              }).catch(() => {});
              return;
            }

            // Check for error on page
            if (bodyText.includes('invalid') || bodyText.includes('incorrect') || bodyText.includes('failed') || bodyText.includes('does not exist')) {
              clearInterval(poll);
              storage.set({ kb_hostinger_auth_test: null });
              chrome.runtime.sendMessage({
                action: "KB_HOSTINGER_TEST_RESULT",
                inboxId: test.inboxId,
                success: false,
                email: test.email,
                message: "Hostinger Webmail rejected credentials: Username or password incorrect on Hostinger."
              }).catch(() => {});
              return;
            }

            if (attempts > 12) {
              clearInterval(poll);
              storage.set({ kb_hostinger_auth_test: null });
              chrome.runtime.sendMessage({
                action: "KB_HOSTINGER_TEST_RESULT",
                inboxId: test.inboxId,
                success: false,
                email: test.email,
                message: "Hostinger login attempt timed out or failed to authenticate."
              }).catch(() => {});
            }
          }, 500);
        }, 800);
      }
    });
  }

  setTimeout(checkHostingerAuthTest, 1200);
